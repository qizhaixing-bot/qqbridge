# QQBridge 实验版

QQ 通知 → DSH 手机桥 → 无障碍打开聊天 → setText → 点发送。

## 构建

### GitHub Actions
1. 新建 Public 仓库
2. 上传本压缩包（qqbridge-app.zip）到仓库根目录
3. 新建 `.github/workflows/android.yml`（内容见仓库里的 workflow）
4. Actions → android-build → Run workflow
5. 下载 `app-debug` artifact

### 本地
Android Studio 打开，或 `gradle assembleDebug`。

## 功能
- 多联系人 / 多群
- 每行：昵称/群名 + QQ号/群号 + 私聊/群聊切换
- 私聊：`chat_type=wpa`，资料页校验 QQ
- 群聊：群号 scheme 优先，失败搜群名
- 本地缓存最近 1–30 条上下文
- 管理员 QQ（仅私聊，搜管理员 QQ 号 + 聊天标题校验）
- 群 @ 触发、队列、冷却、每小时上限
- 表情截图识别（实验，静态图，默认关闭）
- 通知/无障碍/电池权限状态

## 限制
- 群免打扰/通知合并会漏消息
- 搜索依赖 QQ 界面，版本更新可能失效
- 截图走无障碍 takeScreenshot（Android 11+）
- 后台保活取决于系统白名单

---

## 本版修改（针对“跳不到 QQ / 空白聊天”）

- `AndroidManifest.xml` 增加 `<queries>`：声明 `com.tencent.mobileqq` 和 `mqqwpa` scheme。
  Android 11+（targetSdk 34）没有这段，`getLaunchIntentForPackage` 会返回 null，QQ 根本拉不起来。
- 搜索流程改为轮询等待：启动 QQ 后最多等约 8 秒找搜索入口，点开后再等约 4 秒找输入框，不再写死 1.4 秒。
- 搜索结果改为轮询查找（最多约 5 秒），不再只等 1.6 秒。
- 进入聊天后轮询等待输入框（scheme 打开也最多等约 6 秒），不再写死 2.6 秒。
- 发送前如果拿得到聊天标题，会校验是否包含目标昵称；明显不匹配就放弃发送，并在日志里写出当前标题。

## 目标配置（很重要）

每行必须带前缀：

```text
p:昵称=QQ号
g:群名=群号
```

- 群写成 `群名=群号`（没有 `g:`）会被当成私聊，用 `chat_type=wpa` 打开群号，表现就是**空白聊天**。
- 号码必须填真实 QQ 号/群号；留空会走昵称搜索，容易被“聊天记录”结果带偏。
- 不确定就先只配一个私聊目标测试。
