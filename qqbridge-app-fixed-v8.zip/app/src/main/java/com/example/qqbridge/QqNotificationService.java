package com.example.qqbridge;

import android.app.Notification;
import android.app.PendingIntent;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayDeque;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class QqNotificationService extends NotificationListenerService {
    private static final String TAG = "QQBridge";
    private static final String QQ = "com.tencent.mobileqq";

    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final ArrayDeque<Task> queue = new ArrayDeque<>();
    private boolean running = false;
    private final Map<String, Long> recent = new HashMap<>();
    private final Map<String, Long> lastReply = new HashMap<>();
    private final Map<String, long[]> hourly = new HashMap<>();
    private static final Pattern SENDER_RE = Pattern.compile("^([^:：\\n]{1,24})[:：]\\s*(.+)$");
    private static PendingIntent pendingFriendIntent;
    private final Map<String, PendingIntent> chatIntents = new HashMap<>();

    private static class Task {
        final String contact;
        final String uin;
        final String text;
        final String sender;
        final boolean group;
        final boolean direct;
        final CountDownLatch done = new CountDownLatch(1);
        Task(String contact, String uin, String text, String sender, boolean group) {
            this(contact, uin, text, sender, group, false);
        }
        Task(String contact, String uin, String text, String sender, boolean group, boolean direct) {
            this.contact = contact;
            this.uin = uin;
            this.text = text;
            this.sender = sender;
            this.group = group;
            this.direct = direct;
        }
    }

    @Override
    public void onListenerConnected() {
        super.onListenerConnected();
        AppLog.add("通知监听已连接");
        Log.d(TAG, "notification listener connected");
    }

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        if (sbn == null || !QQ.equals(sbn.getPackageName())) return;
        AppLog.add("通知 user=" + sbn.getUser());
        Bundle extras = sbn.getNotification().extras;
        if (extras == null) return;
        CharSequence titleCs = extras.getCharSequence(Notification.EXTRA_TITLE);
        CharSequence textCs = extras.getCharSequence(Notification.EXTRA_TEXT);
        String title = clean(titleCs == null ? "" : titleCs.toString());
        String text = textCs == null ? "" : textCs.toString().trim();
        CharSequence big = extras.getCharSequence(Notification.EXTRA_BIG_TEXT);
        CharSequence sub = extras.getCharSequence(Notification.EXTRA_SUB_TEXT);
        if (text.isEmpty() && big != null) text = big.toString().trim();
        if (text.isEmpty() && sub != null) text = sub.toString().trim();
        if (text.isEmpty()) {
            CharSequence[] lines = extras.getCharSequenceArray(Notification.EXTRA_TEXT_LINES);
            if (lines != null && lines.length > 0 && lines[0] != null) text = lines[0].toString().trim();
        }
        if (title.isEmpty() || text.isEmpty()) return;

        Context ctx = getApplicationContext();
        if (isFriendRequest(title, text)) {
            pendingFriendIntent = sbn.getNotification().contentIntent;
            forwardFriendRequest(ctx, title, text);
            return;
        }
        Config.Target groupMatch = null;
        Config.Target privateMatch = null;
        for (Config.Target t : Config.targets(ctx)) {
            if (title.equals(t.name) || title.contains(t.name)) {
                if (t.group) {
                    if (groupMatch == null || t.name.length() > groupMatch.name.length()) groupMatch = t;
                } else {
                    if (privateMatch == null || t.name.length() > privateMatch.name.length()) privateMatch = t;
                }
            }
        }
        Config.Target target;
        if (groupMatch != null && privateMatch != null) {
            // 私聊/群聊同名时，带“昵称: 内容”的按群聊处理。
            target = SENDER_RE.matcher(text).matches() ? groupMatch : privateMatch;
            AppLog.add("同名目标，按格式选 " + (target.group ? "群聊" : "私聊"));
        } else {
            target = groupMatch != null ? groupMatch : privateMatch;
        }
        if (target == null) {
            AppLog.add("未匹配联系人 " + title);
            return;
        }
        String contact = target.name;
        String uin = target.uin;
        boolean group = target.group;
        PendingIntent chatIntent = sbn.getNotification().contentIntent;
        if (chatIntent != null) chatIntents.put(contact, chatIntent);

        String sender = contact;
        if (group) {
            Matcher m = SENDER_RE.matcher(text);
            if (m.matches()) {
                sender = m.group(1).trim();
                text = m.group(2).trim();
            }
        }

        String key = title + "|" + sender + "|" + text;
        long now = System.currentTimeMillis();
        synchronized (recent) {
            Long last = recent.get(key);
            if (last != null && now - last < 120000) return;
            recent.put(key, now);
            if (recent.size() > 200) recent.clear();
        }

        String adminUin = Config.adminUin(ctx);
        if (group) {
            // 群聊：不管有没有 @，都进滚动缓存，满了顶掉最老的。
            MemoryStore.appendGroup(ctx, contact, sender, text, Config.groupCache(ctx));
        } else if (!adminUin.isEmpty() && adminUin.equals(uin)) {
            // 管理员私聊：自动长期记忆，不需要“记住”前缀。
            MemoryStore.appendAdmin(ctx, contact, sender, text);
        }
        MemoryStore.observe(ctx, contact, uin, group, title);

        if (group && !isAtMe(ctx, text)) {
            AppLog.add("群缓存 " + sender + "（未 @" + Config.botName(ctx) + "）");
            return;
        }

        AppLog.add("收到 " + title + " / " + sender + ": " + text);
        Log.d(TAG, "recv " + title + " / " + sender + ": " + text);
        enqueue(new Task(contact, uin, text, sender, group));
    }

    private boolean isFriendRequest(String title, String text) {
        return title.contains("好友申请") || title.contains("新朋友")
                || text.contains("请求添加你为好友") || text.contains("请求加你为好友")
                || text.contains("请求添加你为朋友");
    }

    private void forwardFriendRequest(Context ctx, String title, String text) {
        String admin = Config.adminUin(ctx);
        if (admin.isEmpty()) return;
        String key = "friend|" + title + "|" + text;
        long now = System.currentTimeMillis();
        synchronized (recent) {
            Long last = recent.get(key);
            if (last != null && now - last < 300000) return;
            recent.put(key, now);
        }
        String msg = "好友申请：" + title + "｜" + text
                + "\n同意请回复：同意好友 昵称 QQ号（只加白名单用：同意 昵称 QQ号）";
        for (Config.Target t : Config.targets(ctx)) {
            if (!t.group && admin.equals(t.uin)) {
                enqueue(new Task(t.name, t.uin, msg, t.name, false, true));
                return;
            }
        }
        // 管理员没在联系人里也直接发到管理员 QQ，不让申请被吞掉。
        QqAccessibilityService svc = QqAccessibilityService.get();
        if (svc != null) {
            AppLog.add("好友申请转发管理员 " + admin);
            svc.sendReply("", admin, msg, false);
        } else {
            AppLog.add("好友申请但无障碍未连接");
        }
    }

    private String handleAdminCommand(Context ctx, String text) {
        String t = text.trim();
        if (t.startsWith("/")) t = t.substring(1).trim();
        if (t.equals("帮助") || t.equals("命令") || t.equals("菜单")) {
            return "命令：\n"
                    + "发消息 昵称/QQ/群名 内容\n"
                    + "群发 群名 内容\n"
                    + "加好友 QQ号 [备注]\n"
                    + "同意好友 昵称 QQ号\n"
                    + "同意 昵称 QQ号\n"
                    + "禁止 QQ号（移出白名单，不再回复）\n"
                    + "移除 QQ号\n"
                    + "统计 / 记忆\n也可加 / 前缀";
        }
        if (t.equals("统计")) return MemoryStore.summary(ctx);
        if (t.equals("记忆")) return MemoryStore.dump(ctx);

        Matcher send = Pattern.compile("^(?:发消息|发到|群发)\\s+(.+)$").matcher(t);
        if (send.matches()) {
            boolean forceGroup = t.startsWith("群发");
            String rest = send.group(1).trim();
            Config.Target target = null;
            String content = "";
            for (Config.Target x : Config.targets(ctx)) {
                if (forceGroup && !x.group) continue;
                if (rest.startsWith(x.name)) {
                    String c = rest.substring(x.name.length()).trim();
                    if (!c.isEmpty() && (target == null || x.name.length() > target.name.length())) {
                        target = x;
                        content = c;
                    }
                }
            }
            if (target == null) {
                String[] p = rest.split("\\s+", 2);
                if (p.length == 2 && p[0].matches("\\d{5,12}")) {
                    target = new Config.Target("", p[0], forceGroup);
                    content = p[1].trim();
                }
            }
            if (target == null) return "没找到目标：先加白名单，或写成“发消息 QQ号 内容”";
            if (content.isEmpty()) return "内容不能为空";
            QqAccessibilityService svc = QqAccessibilityService.get();
            if (svc == null) return "无障碍未连接，发不了";
            svc.sendReply(target.name, target.uin, content, target.group);
            if (!target.name.isEmpty()) MemoryStore.markSent(ctx, target.name);
            // 等目标聊天发送完，再把确认发回管理员，避免两边抢前台。
            try { Thread.sleep(9000); } catch (InterruptedException ignored) {}
            return "已发送给 " + (target.name.isEmpty() ? target.uin : target.name) + "：" + content;
        }

        Matcher addFriend = Pattern.compile("^(?:加好友|添加好友)\\s+(\\d{5,12})(?:\\s+(.+))?$")
                .matcher(t);
        if (addFriend.matches()) {
            String qq = addFriend.group(1);
            String remark = addFriend.group(2) == null ? "" : addFriend.group(2).trim();
            QqAccessibilityService svc = QqAccessibilityService.get();
            if (svc == null) return "无障碍未连接，加不了";
            svc.addFriend(qq, remark, (ok, detail) -> AppLog.add(
                    "加好友 " + qq + "：" + (ok ? "成功 " : "失败 ") + detail));
            try { Thread.sleep(7000); } catch (InterruptedException ignored) {}
            return "已发起加好友：" + qq;
        }

        Matcher rm = Pattern.compile("^(?:移除|删除白名单|移出白名单|禁止)\\s+(\\d{5,12})$").matcher(t);
        if (rm.matches()) {
            String qq = rm.group(1);
            if (qq.equals(Config.adminUin(ctx))) return "不能移除管理员";
            return Config.removeByUin(ctx, qq)
                    ? "已移除白名单（不再回复）：" + qq
                    : "白名单里没有：" + qq;
        }

        Matcher af = Pattern.compile("^(?:同意好友|通过好友)\\s+(\\S+)\\s+(\\d{5,12})$").matcher(t);
        if (af.matches()) {
            String nick = af.group(1);
            String qq = af.group(2);
            QqAccessibilityService svc = QqAccessibilityService.get();
            if (svc == null) return "无障碍未连接，无法自动同意";
            boolean ok = svc.acceptFriendSync(pendingFriendIntent, nick, qq, 25000);
            if (ok) {
                Config.appendPrivate(ctx, nick, qq);
                return "已同意好友并加入白名单：" + nick + "（" + qq + "）";
            }
            return "未自动同意：页面/匹配/按钮校验未通过，请手动处理";
        }

        Matcher m = Pattern.compile("^(?:同意|通过|添加白名单|白名单)\\s+(\\S+)(?:\\s+(\\d{5,12}))?$")
                .matcher(t);
        if (!m.matches()) return null;
        String name = m.group(1);
        String qq = m.group(2);
        if (qq == null) return "请发送：同意 昵称 QQ号";
        if (Config.appendPrivate(ctx, name, qq)) return "已加入白名单：" + name + "（" + qq + "）";
        return "添加失败：名称已存在或号码无效";
    }

    private boolean isSticker(String text) {
        return text.contains("[表情]") || text.contains("[动画表情]")
                || text.contains("[图片]") || text.equals("表情")
                || text.equals("动画表情") || text.equals("图片");
    }

    private boolean isAtMe(Context ctx, String text) {
        String bot = Config.botName(ctx);
        if (bot.isEmpty()) bot = Config.DEFAULT_BOT_NAME;
        return text.contains("@" + bot)
                || (text.contains("@") && text.contains(bot))
                || text.contains("有人@我")
                || text.contains("@我");
    }

    private void enqueue(Task task) {
        synchronized (queue) {
            if (queue.size() >= 50) {
                Task removed = null;
                for (Task t : queue) {
                    if (t.group) { removed = t; break; }
                }
                if (removed != null) queue.remove(removed);
                else queue.removeFirst();
            }
            queue.addLast(task);
            if (!running) {
                running = true;
                worker.execute(this::drain);
            }
        }
    }

    private void drain() {
        try {
        while (true) {
            Task task;
            synchronized (queue) {
                if (queue.isEmpty()) {
                    running = false;
                    return;
                }
                task = queue.removeFirst();
            }
            Context ctx = getApplicationContext();
            {
                long now = System.currentTimeMillis();
                long cooldown = (task.group ? Config.groupCooldown(ctx)
                        : Config.privateCooldown(ctx)) * 1000L;
                Long last = lastReply.get(task.contact);
                if (last != null && now - last < cooldown) {
                    Log.d(TAG, "local cooldown skip " + task.contact);
                    continue;
                }
                long[] h = hourly.get(task.contact);
                if (h == null || now - h[0] > 3600000) {
                    h = new long[]{now, 0};
                    hourly.put(task.contact, h);
                }
                if (h[1] >= Config.hourlyLimit(ctx)) {
                    Log.d(TAG, "local hourly skip " + task.contact);
                    continue;
                }
                h[1]++;
                lastReply.put(task.contact, now);
            }
            if (task.direct) {
                try {
                    QqAccessibilityService svc = QqAccessibilityService.get();
                    if (svc != null) svc.sendReply(task.contact, task.uin, task.text, task.group);
                    Thread.sleep(12000);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    return;
                } finally {
                    task.done.countDown();
                }
                continue;
            }
            try {
                process(task);
                task.done.await(90, TimeUnit.SECONDS);
                Thread.sleep(1200);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return;
            } catch (Exception e) {
                Log.e(TAG, "process error", e);
                task.done.countDown();
            }
        }
        } finally {
            synchronized (queue) {
                running = false;
                if (!queue.isEmpty()) {
                    running = true;
                    worker.execute(this::drain);
                }
            }
        }
    }

    private void process(Task task) {
        AppLog.add("处理消息 " + task.contact);
        Context ctx = getApplicationContext();
        JSONArray history = loadHistory(ctx, task.contact);
        try {
            JSONObject user = new JSONObject();
            user.put("role", "user");
            user.put("name", task.sender);
            user.put("text", task.text);
            history.put(user);
            trim(history, Config.maxContext(ctx));
        } catch (Exception e) {
            Log.e(TAG, "build history", e);
        }
        saveHistory(ctx, task.contact, history);

        QqAccessibilityService svc = QqAccessibilityService.get();
        String admin = Config.adminUin(ctx);
        boolean privateChat = !task.group;

        if (svc != null && Config.stickerVision(ctx) && isSticker(task.text)) {
            final JSONArray h = history;
            svc.openChat(task.contact, task.uin, task.group, () -> ScreenCapture.capture(svc, (b64, mime) -> {
                if (b64 == null || b64.isEmpty()) {
                    Log.w(TAG, "sticker capture empty, fallback text");
                    new Thread(() -> finish(ctx, task.contact, task.uin, task.group, h, false, "", task.sender, task.done)).start();
                    return;
                }
                Log.d(TAG, "sticker screenshot " + b64.length() + " chars");
                new Thread(() -> finish(ctx, task.contact, task.uin, task.group, h, false,
                        "", task.sender, task.done, b64, mime)).start();
            }));
            return;
        }

        boolean isConfiguredAdmin = privateChat && !admin.isEmpty() && admin.equals(task.uin);
        boolean isCommand = isConfiguredAdmin && isCommandText(task.text);

        if (svc != null && isCommand) {
            final JSONArray h = history;
            svc.verifyAdminFromChat(chatIntents.get(task.contact), task.contact, admin, isAdmin -> {
                Log.d(TAG, "cmd admin verify=" + isAdmin);
                if (isAdmin) {
                    runPrivateTask(ctx, task, h, true, task.contact);
                } else {
                    AppLog.add("管理员校验失败，按普通消息处理");
                    finish(ctx, task.contact, task.uin, task.group, h, false, "", task.contact, task.done);
                }
            });
        } else if (isConfiguredAdmin) {
            finish(ctx, task.contact, task.uin, task.group, history, true, admin, task.contact, task.done);
        } else {
            finish(ctx, task.contact, task.uin, task.group, history, false, "", task.contact, task.done);
        }
    }

    private boolean isCommandText(String text) {
        String t = text == null ? "" : text.trim();
        if (t.startsWith("/")) t = t.substring(1).trim();
        return t.equals("帮助") || t.equals("命令") || t.equals("菜单")
                || t.equals("统计") || t.equals("记忆")
                || t.startsWith("发消息") || t.startsWith("发到") || t.startsWith("群发")
                || t.startsWith("加好友") || t.startsWith("添加好友")
                || t.startsWith("禁止")
                || t.startsWith("同意") || t.startsWith("通过")
                || t.startsWith("移除") || t.startsWith("删除白名单")
                || t.startsWith("移出白名单") || t.startsWith("白名单")
                || t.startsWith("添加白名单");
    }

    private void runPrivateTask(Context ctx, Task task, JSONArray history,
                                boolean isAdmin, String senderName) {
        String admin = Config.adminUin(ctx);
        new Thread(() -> {
            if (isAdmin) {
                String cmd = handleAdminCommand(ctx, task.text);
                if (cmd != null) {
                    Log.d(TAG, "admin cmd: " + cmd);
                    QqAccessibilityService svc = QqAccessibilityService.get();
                    if (svc != null) {
                        svc.sendReply(task.contact, task.uin, cmd, false);
                        MemoryStore.markSent(ctx, task.contact);
                    }
                    try { Thread.sleep(4000); } catch (InterruptedException ignored) {}
                    task.done.countDown();
                    return;
                }
            }
            finish(ctx, task.contact, task.uin, task.group, history, isAdmin,
                    isAdmin ? admin : "", senderName, task.done);
        }).start();
    }

    private void finish(Context ctx, String contact, String uin, boolean group, JSONArray history,
                        boolean admin, String senderQq, String senderName, CountDownLatch done) {
        finish(ctx, contact, uin, group, history, admin, senderQq, senderName, done, "", "");
    }

    private void finish(Context ctx, String contact, String uin, boolean group, JSONArray history,
                        boolean admin, String senderQq, String senderName, CountDownLatch done,
                        String imageBase64, String imageMime) {
        try {
        String pluginText = lastUserText(history);
        String pluginReply = pluginText == null ? null
                : PluginManager.tryReply(ctx, contact, senderName, pluginText, group);
        String reply;
        if (pluginReply != null) {
            AppLog.add("插件回复 " + contact);
            reply = pluginReply;
        } else {
            AppLog.add("请求 DSH " + contact);
            JSONArray payload;
            if (group) {
                payload = MemoryStore.groupPayload(ctx, contact, history);
                AppLog.add("群缓存上下文 " + payload.length() + " 条");
            } else if (admin) {
                payload = MemoryStore.adminPayload(ctx, contact, history);
                AppLog.add("管理员长期记忆上下文 " + payload.length() + " 条");
            } else {
                payload = history;
            }
            reply = BridgeClient.chat(ctx, contact, payload,
                    admin, senderQq, senderName, imageBase64, imageMime);
        }
        if (reply != null) {
            reply = PluginManager.afterReply(ctx, contact, senderName, pluginText, group, reply);
        }
        AppLog.add("回复 " + (reply == null ? "空" : reply.length() + " 字"));
        if (reply == null) {
            Log.w(TAG, "bridge empty");
            return;
        }
        Log.d(TAG, "reply: " + reply);
        try {
            JSONObject bot = new JSONObject();
            bot.put("role", "bot");
            bot.put("text", reply);
            history.put(bot);
            trim(history, Config.maxContext(ctx));
        } catch (Exception e) {
            Log.e(TAG, "build reply history", e);
        }
        saveHistory(ctx, contact, history);

        QqAccessibilityService svc = QqAccessibilityService.get();
        if (svc == null) {
            Log.w(TAG, "accessibility not connected");
            AppLog.add("无障碍未连接，无法发送");
            return;
        }
        svc.sendReply(contact, uin, reply, group, chatIntents.get(contact));
        MemoryStore.markSent(ctx, contact);
        try {
            Thread.sleep(12000);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        } finally {
            done.countDown();
        }
    }

    private String lastUserText(JSONArray history) {
        for (int i = history.length() - 1; i >= 0; i--) {
            JSONObject m = history.optJSONObject(i);
            if (m == null) continue;
            if (!"bot".equals(m.optString("role"))) {
                String t = m.optString("text", "");
                if (!t.isEmpty()) return t;
            }
        }
        return null;
    }

    private void remember(Context ctx, String contact, String sender, String text) {
        JSONArray history = loadHistory(ctx, contact);
        try {
            JSONObject user = new JSONObject();
            user.put("role", "user");
            user.put("name", sender);
            user.put("text", text);
            history.put(user);
            trim(history, Config.maxContext(ctx));
        } catch (Exception e) {
            Log.e(TAG, "remember", e);
        }
        saveHistory(ctx, contact, history);
    }

    private JSONArray loadHistory(Context ctx, String contact) {
        SharedPreferences sp = ctx.getSharedPreferences("qqbridge", Context.MODE_PRIVATE);
        String raw = sp.getString("hist_" + contact, "[]");
        try { return new JSONArray(raw); } catch (Exception e) { return new JSONArray(); }
    }

    private void saveHistory(Context ctx, String contact, JSONArray history) {
        ctx.getSharedPreferences("qqbridge", Context.MODE_PRIVATE)
                .edit().putString("hist_" + contact, history.toString()).apply();
    }

    private void trim(JSONArray a, int max) {
        while (a.length() > max) a.remove(0);
    }

    private String clean(String s) {
        return s.replaceAll("\\(\\d+条新消息\\)", "").replaceAll("\\[\\d+条\\]", "").trim();
    }
}
