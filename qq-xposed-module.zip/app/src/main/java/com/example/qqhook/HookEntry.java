package com.example.qqhook;

import android.util.Log;
import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/** 最基础版：只验证模块能否注入 QQ，并输出日志。不做任何收发/修改。 */
public class HookEntry implements IXposedHookLoadPackage {
    private static final String TAG = "QQHook";

    private static void log(String msg) {
        String line = "[QQHook] " + msg;
        XposedBridge.log(line);
        Log.i(TAG, msg);
    }

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lp) {
        log("handleLoadPackage pkg=" + lp.packageName + " proc=" + lp.processName
                + " sdk=" + android.os.Build.VERSION.SDK_INT);
        if (!"com.tencent.mobileqq".equals(lp.packageName)) return;

        log("QQ 进程命中，开始基础检查");
        log("classLoader=" + lp.classLoader);
        log("isFirstApplication=" + lp.isFirstApplication);

        try {
            Class<?> app = XposedHelpers.findClass("com.tencent.mobileqq.app.QQAppInterface", lp.classLoader);
            log("找到 QQAppInterface: " + app.getName());
            log("QQAppInterface 类加载器: " + app.getClassLoader());
        } catch (Throwable t) {
            log("找不到 QQAppInterface，可能类名已变: " + t);
        }

        try {
            Class<?> app2 = XposedHelpers.findClass("com.tencent.common.app.BaseApplicationImpl", lp.classLoader);
            log("找到 BaseApplicationImpl: " + app2.getName());
        } catch (Throwable t) {
            log("找不到 BaseApplicationImpl: " + t);
        }

        log("基础注入检查完成（未做任何 Hook）");
    }
}
