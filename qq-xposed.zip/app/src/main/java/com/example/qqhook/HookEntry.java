package com.example.qqhook;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/** 最小验证：确认 QQ 进程能加载模块。 */
public class HookEntry implements IXposedHookLoadPackage {
    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lp) {
        if (!"com.tencent.mobileqq".equals(lp.packageName)) return;
        XposedBridge.log("[QQHook] injected pkg=" + lp.packageName + " proc=" + lp.processName);
        try {
            Class<?> c = XposedHelpers.findClass("com.tencent.mobileqq.app.QQAppInterface", lp.classLoader);
            XposedBridge.log("[QQHook] found QQAppInterface: " + c);
        } catch (Throwable t) {
            XposedBridge.log("[QQHook] find failed: " + t);
        }
    }
}
