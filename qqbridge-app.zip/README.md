# QQBridge 实验版

最小可用：QQ 通知 → DSH 手机桥 → 无障碍打开聊天 → setText → 点发送。

## 构建

### GitHub Actions

1. 新建仓库，上传整个目录
2. Actions → android-build → Run workflow
3. 下载 Artifacts 里的 `app-debug.apk`

### 本地

Android Studio 打开，或：

```bash
gradle assembleDebug
```

## 安装后

1. 打开 QQBridge，填手机桥地址和 secret
2. 开启通知使用权
3. 开启无障碍
4. 保存配置
5. QQ 放后台，用另一个号发消息

## 限制

- 只处理配置里的那一个联系人
- 只发文字
- 免打扰群/QQ 前台时没有通知
- 手机桥地址默认 `127.0.0.1:3099`，适用于 DSH 与 QQ 同机
- debug 签名，仅测试用
