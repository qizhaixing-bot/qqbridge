# QQBridge 实验版

QQ 通知 → DSH 手机桥 → 无障碍打开聊天 → setText → 点发送。

## 构建

### GitHub Actions
1. 新建 Public 仓库
2. 上传本压缩包（qqbridge-app.zip）到仓库根目录
3. 新建 `.github/workflows/android.yml`（内容见仓库里的 workflow）
4. Actions → android-build → Run workflow
5. 下载 `app-debug` artifact

### 本地
Android Studio 打开，或 `gradle assembleDebug`。

## 功能
- 多联系人 / 多群
- 每行：昵称/群名 + QQ号/群号 + 私聊/群聊切换
- 私聊：`chat_type=wpa`，资料页校验 QQ
- 群聊：群号 scheme 优先，失败搜群名
- 本地缓存最近 1–30 条上下文
- 管理员 QQ（仅私聊，搜管理员 QQ 号 + 聊天标题校验）
- 群 @ 触发、队列、冷却、每小时上限
- 表情截图识别（实验，静态图，默认关闭）
- 通知/无障碍/电池权限状态

## 限制
- 群免打扰/通知合并会漏消息
- 搜索依赖 QQ 界面，版本更新可能失效
- 截图走无障碍 takeScreenshot（Android 11+）
- 后台保活取决于系统白名单
