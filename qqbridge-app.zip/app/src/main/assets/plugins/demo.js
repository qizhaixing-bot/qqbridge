// onMessage：返回文字直接抢答；返回 null 继续
// onPrompt：返回自定义提示词，交给内置 DeepSeek
// onReply：拿到 AI 回复后改写
function onMessage(msg) {
  if (msg.text === '签到') return '签到成功，经验 +1';
  return null;
}

function onPrompt(msg) {
  if (msg.text.indexOf('翻译') >= 0) {
    return '请把下面内容翻译成中文，只输出译文：\n' + msg.text;
  }
  return null;
}

function onReply(msg) {
  if (msg.reply && msg.reply.length > 120) {
    return msg.reply.slice(0, 120);
  }
  return null;
}
