package com.example.qqbridge;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** 轮询 DSH 的 /phone/actions，执行插件主动消息。 */
public final class PhoneActions {
    private static volatile boolean started = false;
    private static final Set<Integer> EXECUTED = new HashSet<>();

    private PhoneActions() {}

    public static void start(final Context ctx) {
        if (started) return;
        started = true;
        final Context app = ctx.getApplicationContext();
        new Thread(() -> {
            while (true) {
                try {
                    poll(app);
                    Thread.sleep(3000);
                } catch (InterruptedException e) {
                    return;
                } catch (Exception e) {
                    AppLog.add("主动队列异常 " + e);
                    try { Thread.sleep(5000); } catch (InterruptedException ignored) { return; }
                }
            }
        }, "phone-actions").start();
        AppLog.add("主动消息轮询已启动");
    }

    private static void poll(Context ctx) {
        String base = Config.url(ctx);
        int i = base.indexOf("/phone/chat");
        if (i > 0) base = base.substring(0, i);
        HttpURLConnection conn = null;
        try {
            conn = (HttpURLConnection) new URL(base + "/phone/actions").openConnection();
            conn.setRequestMethod("GET");
            conn.setConnectTimeout(5000);
            conn.setReadTimeout(10000);
            conn.setRequestProperty("x-phone-secret", Config.secret(ctx));
            int code = conn.getResponseCode();
            if (code != 200) return;
            String raw = read(conn.getInputStream());
            JSONObject obj = new JSONObject(raw);
            JSONArray arr = obj.optJSONArray("actions");
            if (arr == null || arr.length() == 0) return;

            QqAccessibilityService svc = QqAccessibilityService.get();
            if (svc == null) return;

            for (int k = 0; k < arr.length(); k++) {
                JSONObject a = arr.optJSONObject(k);
                if (a == null) continue;
                int id = a.optInt("id");
                synchronized (EXECUTED) {
                    if (EXECUTED.contains(id)) {
                        ack(ctx, base, id, true);
                        continue;
                    }
                    EXECUTED.add(id);
                    if (EXECUTED.size() > 500) EXECUTED.clear();
                }
                String contact = a.optString("contact", "");
                String uin = a.optString("uin", contact);
                String text = a.optString("text", "");
                boolean group = a.optBoolean("group", false);
                if (text.isEmpty()) { ack(ctx, base, id, false); continue; }
                if (!Config.proactivePluginPriority(ctx) && !SendGate.tryAcquire(ctx, contact, group)) {
                    AppLog.add("App 优先：主动消息被限流 " + contact);
                    ack(ctx, base, id, false);
                    continue;
                }
                AppLog.add("主动消息 " + contact + ": " + text);
                QqNotificationService.markSent(contact, text);
                svc.sendParts(contact, uin, group, split(text));
                ack(ctx, base, id, true);
            }
        } catch (Exception e) {
            AppLog.add("主动队列请求失败 " + e);
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    private static List<String> split(String text) {
        List<String> out = new ArrayList<>();
        for (String s : text.split("\\n+")) {
            if (!s.trim().isEmpty()) out.add(s.trim());
        }
        if (out.isEmpty()) out.add(text.trim());
        return out;
    }

    private static void ack(Context ctx, String base, int id, boolean ok) {
        HttpURLConnection conn = null;
        try {
            conn = (HttpURLConnection) new URL(base + "/phone/actions/result").openConnection();
            conn.setRequestMethod("POST");
            conn.setDoOutput(true);
            conn.setConnectTimeout(5000);
            conn.setReadTimeout(5000);
            conn.setRequestProperty("content-type", "application/json; charset=utf-8");
            conn.setRequestProperty("x-phone-secret", Config.secret(ctx));
            JSONObject body = new JSONObject();
            body.put("id", id);
            body.put("ok", ok);
            try (OutputStream os = conn.getOutputStream()) {
                os.write(body.toString().getBytes(StandardCharsets.UTF_8));
            }
            int code = conn.getResponseCode();
            if (code != 200) AppLog.add("主动 ack HTTP " + code + " id=" + id);
        } catch (Exception ignored) {
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    private static String read(InputStream is) throws Exception {
        StringBuilder sb = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8))) {
            String line;
            while ((line = br.readLine()) != null) sb.append(line);
        }
        return sb.toString();
    }
}
