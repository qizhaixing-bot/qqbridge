package com.example.qqbridge;

import android.content.Context;

import java.util.HashMap;
import java.util.Map;

/** App 优先模式下的主动消息限流。 */
public final class SendGate {
    private static final Map<String, Long> last = new HashMap<>();
    private static final Map<String, long[]> hourly = new HashMap<>();

    private SendGate() {}

    public static synchronized boolean tryAcquire(Context c, String contact, boolean group) {
        long now = System.currentTimeMillis();
        long cooldown = (group ? Config.groupCooldown(c) : Config.privateCooldown(c)) * 1000L;
        Long l = last.get(contact);
        if (l != null && now - l < cooldown) return false;
        long[] h = hourly.get(contact);
        if (h == null || now - h[0] > 3600000) {
            h = new long[]{now, 0};
            hourly.put(contact, h);
        }
        if (h[1] >= Config.hourlyLimit(c)) return false;
        h[1]++;
        last.put(contact, now);
        return true;
    }
}
