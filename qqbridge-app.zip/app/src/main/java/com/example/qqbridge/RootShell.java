package com.example.qqbridge;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;

/** 极简 root shell：用于 am start --user 999 打开分身 QQ。需要 KernelSU/root 授权。 */
public final class RootShell {
    private static Boolean rooted;

    private RootShell() {}

    public static synchronized boolean available() {
        if (rooted == null) {
            String out = run("id");
            rooted = out.contains("uid=0");
        }
        return rooted;
    }

    public static String run(String command) {
        Process process = null;
        try {
            process = new ProcessBuilder("su", "-c", command)
                    .redirectErrorStream(true)
                    .start();
            StringBuilder sb = new StringBuilder();
            try (BufferedReader br = new BufferedReader(
                    new InputStreamReader(process.getInputStream(), StandardCharsets.UTF_8))) {
                String line;
                while ((line = br.readLine()) != null) sb.append(line).append('\n');
            }
            if (!process.waitFor(10, java.util.concurrent.TimeUnit.SECONDS)) {
                process.destroy();
                return sb + "\n[timeout]";
            }
            return sb.toString().trim();
        } catch (Exception e) {
            return "error: " + e;
        } finally {
            if (process != null) process.destroy();
        }
    }
}
