package com.example.qqbridge;

import android.accessibilityservice.AccessibilityService;
import android.graphics.Bitmap;
import android.hardware.HardwareBuffer;
import android.os.Build;
import android.util.Base64;
import android.util.Log;
import android.view.Display;

import java.io.ByteArrayOutputStream;

public final class ScreenCapture {
    private static final String TAG = "QQBridge";

    public interface Callback {
        void onImage(String base64, String mime);
    }

    private ScreenCapture() {}

    public static void capture(AccessibilityService svc, Callback cb) {
        if (Build.VERSION.SDK_INT < 30) {
            cb.onImage("", "");
            return;
        }
        svc.takeScreenshot(Display.DEFAULT_DISPLAY, svc.getMainExecutor(),
                new AccessibilityService.TakeScreenshotCallback() {
                    @Override
                    public void onSuccess(AccessibilityService.ScreenshotResult result) {
                        HardwareBuffer buffer = result.getHardwareBuffer();
                        Bitmap hardware = Bitmap.wrapHardwareBuffer(buffer, result.getColorSpace());
                        Bitmap bitmap = hardware == null ? null
                                : hardware.copy(Bitmap.Config.ARGB_8888, false);
                        try { buffer.close(); } catch (Exception ignored) {}
                        if (bitmap == null) {
                            cb.onImage("", "");
                            return;
                        }
                        cb.onImage(compress(bitmap), "image/jpeg");
                    }

                    @Override
                    public void onFailure(int errorCode) {
                        Log.w(TAG, "capture failed " + errorCode);
                        cb.onImage("", "");
                    }
                });
    }

    private static String compress(Bitmap src) {
        int w = src.getWidth();
        int h = src.getHeight();
        int max = 1280;
        Bitmap out = src;
        if (w > max || h > max) {
            float scale = Math.min((float) max / w, (float) max / h);
            out = Bitmap.createScaledBitmap(src, Math.round(w * scale), Math.round(h * scale), true);
        }
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        out.compress(Bitmap.CompressFormat.JPEG, 70, bos);
        return Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP);
    }
}
