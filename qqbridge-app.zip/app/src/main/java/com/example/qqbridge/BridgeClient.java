package com.example.qqbridge;

import android.content.Context;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public final class BridgeClient {
    private static final String TAG = "QQBridge";
    private BridgeClient() {}

    public static String chat(Context context, String name, String text) {
        JSONArray messages = new JSONArray();
        try {
            JSONObject msg = new JSONObject();
            msg.put("role", "user");
            msg.put("name", name);
            msg.put("text", text);
            messages.put(msg);
        } catch (Exception e) {
            Log.e(TAG, "build message", e);
        }
        return chat(context, name, messages, false, "", "");
    }

    public static String chat(Context context, String name, JSONArray messages) {
        return chat(context, name, messages, false, "", "");
    }

    public static String chat(Context context, String name, JSONArray messages,
                              boolean admin, String senderQq, String senderName) {
        return chat(context, name, messages, admin, senderQq, senderName, "", "");
    }

    public static String chat(Context context, String name, JSONArray messages,
                              boolean admin, String senderQq, String senderName,
                              String imageBase64, String imageMime) {
        try {
            JSONObject body = new JSONObject();
            body.put("contact", name);
            body.put("name", name);
            body.put("messages", messages);
            body.put("admin", admin);
            body.put("senderQq", senderQq == null ? "" : senderQq);
            body.put("senderName", senderName == null ? "" : senderName);
            body.put("image", imageBase64 == null ? "" : imageBase64);
            body.put("imageMime", imageMime == null ? "image/jpeg" : imageMime);

            HttpURLConnection conn = (HttpURLConnection) new URL(Config.url(context)).openConnection();
            conn.setRequestMethod("POST");
            conn.setConnectTimeout(15000);
            conn.setReadTimeout(60000);
            conn.setDoOutput(true);
            conn.setRequestProperty("content-type", "application/json; charset=utf-8");
            conn.setRequestProperty("x-phone-secret", Config.secret(context));

            try (OutputStream os = conn.getOutputStream()) {
                os.write(body.toString().getBytes(StandardCharsets.UTF_8));
            }

            int code = conn.getResponseCode();
            InputStream is = code >= 400 ? conn.getErrorStream() : conn.getInputStream();
            StringBuilder sb = new StringBuilder();
            if (is != null) {
                try (BufferedReader br = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8))) {
                    String line;
                    while ((line = br.readLine()) != null) sb.append(line);
                }
            }
            String raw = sb.toString();
            Log.d(TAG, "bridge " + code + " " + raw);
            JSONObject obj = new JSONObject(raw);
            if (!obj.optBoolean("ok")) return null;
            String reply = obj.optString("reply", "").trim();
            return reply.isEmpty() ? null : reply;
        } catch (Exception e) {
            Log.e(TAG, "bridge error", e);
            return null;
        }
    }
}
