package com.example.qqbridge;

import android.app.Activity;
import android.content.pm.PackageManager;

import rikka.shizuku.Shizuku;

/** 通过 Shizuku/Shevery 弹出授权，让 QQBridge 拿到 shell 身份。 */
public final class ShizukuHelper {
    private ShizukuHelper() {}

    public static boolean granted() {
        try {
            return Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED;
        } catch (Throwable e) {
            return false;
        }
    }

    public static void request(Activity activity) {
        try {
            if (granted()) {
                AppLog.add("Shizuku 已授权");
                return;
            }
            Shizuku.addRequestPermissionResultListener((code, result) ->
                    AppLog.add("Shizuku 授权结果 " + (result == PackageManager.PERMISSION_GRANTED)));
            Shizuku.requestPermission(0);
            AppLog.add("已请求 Shizuku 授权");
        } catch (Throwable e) {
            AppLog.add("请求 Shizuku 失败：" + e);
        }
    }
}
