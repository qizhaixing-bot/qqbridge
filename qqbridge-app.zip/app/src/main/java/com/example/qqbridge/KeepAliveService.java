package com.example.qqbridge;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.os.IBinder;

public class KeepAliveService extends Service {
    private static final String CHANNEL = "qqbridge_keepalive";

    @Override
    public void onCreate() {
        super.onCreate();
        AppLog.add("前台保活服务启动 App user=" + android.os.Process.myUserHandle());
        startForeground(1, buildNotification());
        PhoneActions.start(this);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private Notification buildNotification() {
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (nm != null) {
            NotificationChannel ch = new NotificationChannel(
                    CHANNEL, "QQBridge 保活", NotificationManager.IMPORTANCE_LOW);
            ch.setDescription("保持通知监听和无障碍服务运行");
            nm.createNotificationChannel(ch);
        }
        return new Notification.Builder(this, CHANNEL)
                .setContentTitle("QQBridge 正在运行")
                .setContentText("通知监听 + 无障碍自动化")
                .setSmallIcon(android.R.drawable.stat_notify_sync)
                .setOngoing(true)
                .build();
    }
}
