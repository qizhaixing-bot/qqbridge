package com.example.qqbridge;

import org.mozilla.javascript.BaseFunction;
import org.mozilla.javascript.Context;
import org.mozilla.javascript.Function;
import org.mozilla.javascript.Scriptable;
import org.mozilla.javascript.ScriptableObject;
import org.mozilla.javascript.Undefined;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.Arrays;
import java.util.Comparator;

/**
 * 极简 JS 插件：
 *  onMessage(msg) -> 字符串：直接优先回复
 *  onPrompt(msg)  -> 字符串：替换发给 DeepSeek 的用户提示
 *  onReply(msg)   -> 字符串：改写 AI 回复（msg.reply 是原文）
 */
public final class PluginManager {
    private PluginManager() {}

    public static File dir(android.content.Context c) {
        File base = c.getExternalFilesDir(null);
        if (base == null) base = c.getFilesDir();
        File d = new File(base, "plugins");
        if (!d.exists()) d.mkdirs();
        return d;
    }

    public static int count(android.content.Context c) {
        File[] fs = dir(c).listFiles((d, n) -> n.endsWith(".js"));
        return fs == null ? 0 : fs.length;
    }

    public static void ensureSample(android.content.Context c) {
        File d = dir(c);
        try {
            String[] names = c.getAssets().list("plugins");
            if (names == null) return;
            for (String n : names) {
                if (!n.endsWith(".js")) continue;
                File out = new File(d, n);
                if (out.exists()) continue;
                try (InputStream in = c.getAssets().open("plugins/" + n);
                     FileOutputStream os = new FileOutputStream(out)) {
                    byte[] buf = new byte[8192];
                    int r;
                    while ((r = in.read(buf)) > 0) os.write(buf, 0, r);
                }
            }
        } catch (Exception e) {
            AppLog.add("内置插件释放失败: " + e.getMessage());
        }
    }

    private static File[] files(android.content.Context c) {
        File[] fs = dir(c).listFiles((d, n) -> n.endsWith(".js"));
        if (fs == null || fs.length == 0) return new File[0];
        Arrays.sort(fs, Comparator.comparing(File::getName));
        return fs;
    }

    /** 直接回复，第一个非空命中 */
    public static String tryReply(android.content.Context c, String contact, String sender, String text, boolean group) {
        for (File f : files(c)) {
            String r = runFn(f, "onMessage", contact, sender, text, group, null);
            if (r != null) {
                AppLog.add("插件命中 " + f.getName() + " -> " + r);
                return r;
            }
        }
        return null;
    }

    /** 自定义发给 DeepSeek 的提示，第一个非空命中 */
    public static String tryPrompt(android.content.Context c, String contact, String sender, String text, boolean group) {
        for (File f : files(c)) {
            String r = runFn(f, "onPrompt", contact, sender, text, group, null);
            if (r != null) {
                AppLog.add("插件提示词 " + f.getName());
                return r;
            }
        }
        return null;
    }

    /** 改写 AI 回复，按文件名顺序链式处理 */
    public static String afterReply(android.content.Context c, String contact, String sender, String text, boolean group, String reply) {
        String current = reply;
        for (File f : files(c)) {
            String r = runFn(f, "onReply", contact, sender, text, group, current);
            if (r != null) {
                AppLog.add("插件改写回复 " + f.getName());
                current = r;
            }
        }
        return current;
    }

    private static String runFn(File f, String fnName, String contact, String sender,
                                String text, boolean group, String reply) {
        String src;
        try {
            src = new String(Files.readAllBytes(f.toPath()), StandardCharsets.UTF_8);
        } catch (Exception e) {
            AppLog.add("插件读取失败 " + f.getName());
            return null;
        }
        Context cx = Context.enter();
        try {
            cx.setOptimizationLevel(-1);
            Scriptable scope = cx.initStandardObjects();
            Scriptable api = cx.newObject(scope);
            ScriptableObject.putProperty(api, "log", new BaseFunction() {
                @Override
                public Object call(Context c, Scriptable s, Scriptable t, Object[] args) {
                    AppLog.add("插件日志: " + (args.length > 0 ? Context.toString(args[0]) : ""));
                    return Undefined.instance;
                }
            });
            ScriptableObject.putProperty(scope, "api", api);
            cx.evaluateString(scope, src, f.getName(), 1, null);

            Object fn = scope.get(fnName, scope);
            if (!(fn instanceof Function)) return null;

            Scriptable msg = cx.newObject(scope);
            ScriptableObject.putProperty(msg, "text", text);
            ScriptableObject.putProperty(msg, "contact", contact);
            ScriptableObject.putProperty(msg, "sender", sender);
            ScriptableObject.putProperty(msg, "group", group);
            if (reply != null) ScriptableObject.putProperty(msg, "reply", reply);

            Object r = ((Function) fn).call(cx, scope, scope, new Object[]{msg});
            if (r == null || r == Undefined.instance) return null;
            String out = Context.toString(r).trim();
            return out.isEmpty() ? null : out;
        } catch (Exception e) {
            AppLog.add("插件异常 " + f.getName() + ": " + e.getMessage());
            return null;
        } finally {
            Context.exit();
        }
    }
}
