package com.example.qqbridge;

import android.content.Context;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public final class LocalLlm {
    private static final String TAG = "QQBridge";
    private static final String API = "https://api.deepseek.com/chat/completions";

    private LocalLlm() {}

    public static String chat(Context ctx, JSONArray history, String persona, String model, String apiKey) {
        JSONArray messages = new JSONArray();
        try {
            JSONObject sys = new JSONObject();
            sys.put("role", "system");
            sys.put("content", persona == null ? "" : persona);
            messages.put(sys);
            for (int i = 0; i < history.length(); i++) {
                JSONObject m = history.optJSONObject(i);
                if (m == null) continue;
                String text = m.optString("text", "");
                if (text.isEmpty()) continue;
                JSONObject o = new JSONObject();
                o.put("role", "bot".equals(m.optString("role")) ? "assistant" : "user");
                o.put("content", text);
                messages.put(o);
            }
        } catch (Exception e) {
            AppLog.add("本地消息构建失败 " + e);
            return null;
        }
        return post(messages, model, apiKey, 300);
    }

    /** 插件 onPrompt 返回的提示词，直接作为用户消息 */
    public static String chatPrompt(Context ctx, String prompt, String persona, String model, String apiKey) {
        JSONArray messages = new JSONArray();
        try {
            JSONObject sys = new JSONObject();
            sys.put("role", "system");
            sys.put("content", persona == null ? "" : persona);
            messages.put(sys);
            JSONObject user = new JSONObject();
            user.put("role", "user");
            user.put("content", prompt == null ? "" : prompt);
            messages.put(user);
        } catch (Exception e) {
            AppLog.add("本地提示词构建失败 " + e);
            return null;
        }
        return post(messages, model, apiKey, 300);
    }

    /** 只用内置 DeepSeek 改代码，不参与聊天回复 */
    public static String rewriteCode(String apiKey, String model, String instruction, String code) {
        JSONArray messages = new JSONArray();
        try {
            JSONObject sys = new JSONObject();
            sys.put("role", "system");
            sys.put("content", "你是 JS 代码助手。只输出可运行的 JavaScript 代码，不要解释，不要 Markdown 代码围栏。");
            messages.put(sys);
            JSONObject user = new JSONObject();
            user.put("role", "user");
            user.put("content", "要求：\n" + (instruction == null ? "" : instruction)
                    + "\n\n当前代码：\n" + (code == null ? "" : code));
            messages.put(user);
        } catch (Exception e) {
            return null;
        }
        String out = post(messages, model, apiKey, 1500);
        if (out == null) return null;
        out = out.trim();
        if (out.startsWith("```")) {
            int nl = out.indexOf('\n');
            if (nl > 0) out = out.substring(nl + 1);
            if (out.endsWith("```")) out = out.substring(0, out.length() - 3);
        }
        return out.trim();
    }

    private static String post(JSONArray messages, String model, String apiKey, int maxTokens) {
        if (apiKey == null || apiKey.trim().isEmpty()) {
            AppLog.add("本地模式：未填 API Key");
            return null;
        }
        try {
            JSONObject body = new JSONObject();
            body.put("model", model == null || model.isEmpty() ? "deepseek-chat" : model);
            body.put("messages", messages);
            body.put("temperature", 0.9);
            body.put("max_tokens", maxTokens);

            HttpURLConnection conn = (HttpURLConnection) new URL(API).openConnection();
            conn.setRequestMethod("POST");
            conn.setConnectTimeout(15000);
            conn.setReadTimeout(60000);
            conn.setDoOutput(true);
            conn.setRequestProperty("content-type", "application/json; charset=utf-8");
            conn.setRequestProperty("authorization", "Bearer " + apiKey.trim());

            try (OutputStream os = conn.getOutputStream()) {
                os.write(body.toString().getBytes(StandardCharsets.UTF_8));
            }
            int code = conn.getResponseCode();
            InputStream is = code >= 400 ? conn.getErrorStream() : conn.getInputStream();
            StringBuilder sb = new StringBuilder();
            if (is != null) {
                try (BufferedReader br = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8))) {
                    String line;
                    while ((line = br.readLine()) != null) sb.append(line);
                }
            }
            String raw = sb.toString();
            AppLog.add("DeepSeek HTTP " + code);
            Log.d(TAG, "deepseek " + code + " " + raw);
            if (code >= 400) return null;
            JSONObject obj = new JSONObject(raw);
            JSONArray choices = obj.optJSONArray("choices");
            if (choices == null || choices.length() == 0) return null;
            JSONObject msg = choices.getJSONObject(0).optJSONObject("message");
            if (msg == null) return null;
            String reply = msg.optString("content", "").trim();
            return reply.isEmpty() ? null : reply;
        } catch (Exception e) {
            AppLog.add("DeepSeek 异常 " + e);
            Log.e(TAG, "deepseek error", e);
            return null;
        }
    }
}
