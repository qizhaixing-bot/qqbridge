package com.example.qqbridge;

import android.content.Context;

import java.io.File;
import java.io.FileWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public final class AppLog {
    private static final int MAX = 300;
    private static final List<String> LINES = new ArrayList<>();
    private static final SimpleDateFormat FMT = new SimpleDateFormat("MM-dd HH:mm:ss", Locale.getDefault());

    private AppLog() {}

    public static synchronized void add(String s) {
        LINES.add(FMT.format(new Date()) + " " + s);
        while (LINES.size() > MAX) LINES.remove(0);
        android.util.Log.d("QQBridge", s);
    }

    public static synchronized String text() {
        StringBuilder sb = new StringBuilder();
        for (String s : LINES) sb.append(s).append('\n');
        return sb.toString();
    }

    public static synchronized void clear() { LINES.clear(); }

    /** 写入 App 专属目录，返回路径；失败返回空串 */
    public static synchronized String save(Context c) {
        try {
            File dir = c.getExternalFilesDir(null);
            if (dir == null) dir = c.getFilesDir();
            File f = new File(dir, "qqbridge.log");
            try (FileWriter w = new FileWriter(f, false)) {
                w.write(text());
            }
            return f.getAbsolutePath();
        } catch (Exception e) {
            return "";
        }
    }
}
