package com.example.qqbridge;

import android.content.Context;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.TimeUnit;

/**
 * 用随包的 rish dex + Shizuku/Shevery 的 shell 身份执行命令。
 * 首次运行会请求 Shizuku 授权（在 Shevery/Shizuku 里允许 QQBridge）。
 */
public final class ShizukuShell {
    private ShizukuShell() {}

    private static File dex(Context c) throws Exception {
        File f = new File(c.getFilesDir(), "rish_shizuku.dex");
        if (!f.exists() || f.length() == 0) {
            try (InputStream in = c.getAssets().open("rish_shizuku.dex");
                 FileOutputStream out = new FileOutputStream(f)) {
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            }
        }
        f.setReadOnly();
        return f;
    }

    public static String run(Context c, String command) {
        Process process = null;
        try {
            File dex = dex(c);
            ProcessBuilder pb = new ProcessBuilder(
                    "/system/bin/app_process",
                    "-Djava.class.path=" + dex.getAbsolutePath(),
                    "/system/bin",
                    "--nice-name=rish",
                    "rikka.shizuku.shell.ShizukuShellLoader",
                    "-c", command);
            pb.environment().put("RISH_APPLICATION_ID", c.getPackageName());
            pb.redirectErrorStream(true);
            process = pb.start();
            StringBuilder sb = new StringBuilder();
            try (BufferedReader br = new BufferedReader(
                    new InputStreamReader(process.getInputStream(), StandardCharsets.UTF_8))) {
                String line;
                while ((line = br.readLine()) != null) sb.append(line).append('\n');
            }
            if (!process.waitFor(20, TimeUnit.SECONDS)) {
                process.destroy();
                return sb + "\n[timeout: 可能没在 Shizuku/Shevery 里授权]";
            }
            return sb.toString().trim();
        } catch (Exception e) {
            return "error: " + e;
        } finally {
            if (process != null) process.destroy();
        }
    }
}
