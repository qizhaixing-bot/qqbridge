package com.example.qqbridge;

import android.accessibilityservice.AccessibilityService;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

public class QqAccessibilityService extends AccessibilityService {
    private static final String TAG = "QQBridge";
    private static volatile QqAccessibilityService instance;

    public static QqAccessibilityService get() { return instance; }

    @Override
    public void onServiceConnected() {
        instance = this;
        Log.d(TAG, "accessibility connected");
    }

    @Override
    public void onDestroy() {
        instance = null;
        super.onDestroy();
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) {}
    @Override public void onInterrupt() {}

    /** 由通知服务调用：打开聊天并发送 */
    public void sendReply(String name, String uin, String text) {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(
                    "mqqwpa://im/chat?chat_type=wpa&uin=" + uin + "&version=1&src_type=web"));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (Exception e) {
            Log.e(TAG, "scheme failed", e);
        }

        new Handler(Looper.getMainLooper()).postDelayed(() -> doSend(name, text), 1500);
    }

    private void doSend(String name, String text) {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) {
            Log.w(TAG, "no root window");
            return;
        }
        AccessibilityNodeInfo input = findEditable(root);
        if (input == null) {
            Log.w(TAG, "no edit text");
            return;
        }
        input.performAction(AccessibilityNodeInfo.ACTION_FOCUS);
        Bundle args = new Bundle();
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text);
        boolean ok = input.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args);
        Log.d(TAG, "setText=" + ok + " for " + name);
        if (!ok) return;

        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            AccessibilityNodeInfo r = getRootInActiveWindow();
            if (r == null) return;
            AccessibilityNodeInfo send = findText(r, "发送");
            if (send == null) {
                Log.w(TAG, "no send button");
                return;
            }
            send.performAction(AccessibilityNodeInfo.ACTION_CLICK);
            Log.d(TAG, " clicked send");
        }, 600);
    }

    private AccessibilityNodeInfo findEditable(AccessibilityNodeInfo node) {
        if (node == null) return null;
        if (node.isEditable()) return node;
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            AccessibilityNodeInfo r = findEditable(child);
            if (r != null) return r;
        }
        return null;
    }

    private AccessibilityNodeInfo findText(AccessibilityNodeInfo node, String text) {
        if (node == null) return null;
        CharSequence t = node.getText();
        CharSequence d = node.getContentDescription();
        if ((t != null && text.contentEquals(t)) || (d != null && text.contentEquals(d))) return node;
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo r = findText(node.getChild(i), text);
            if (r != null) return r;
        }
        return null;
    }
}
