package com.example.qqbridge;

import android.accessibilityservice.AccessibilityService;
import android.app.PendingIntent;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class QqAccessibilityService extends AccessibilityService {
    private static final String TAG = "QQBridge";
    private static volatile QqAccessibilityService instance;
    private static final Pattern QQ_RE = Pattern.compile("(\\d{5,12})");
    private final Map<String, CachedProfile> profileCache = new HashMap<>();
    private final Map<String, Boolean> adminCache = new HashMap<>();
    private final Map<String, Long> adminCacheTime = new HashMap<>();
    private final AtomicBoolean acceptingFriend = new AtomicBoolean(false);

    public interface AdminCallback {
        void onResult(boolean admin);
    }

    public interface ProfileCallback {
        void onProfile(String nickname, String qq);
    }

    private static class CachedProfile {
        final String nickname;
        final String qq;
        final long time;
        CachedProfile(String nickname, String qq) {
            this.nickname = nickname;
            this.qq = qq;
            this.time = System.currentTimeMillis();
        }
    }

    public static QqAccessibilityService get() { return instance; }

    @Override
    public void onServiceConnected() {
        instance = this;
        AppLog.add("无障碍已连接");
        Log.d(TAG, "accessibility connected");
    }

    @Override
    public void onDestroy() {
        instance = null;
        super.onDestroy();
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) {}
    @Override public void onInterrupt() {}

    /** 管理员校验：直接搜管理员 QQ 号，打开后核对聊天标题 */
    public void verifyAdminBySearch(String adminUin, String expectedName, AdminCallback cb) {
        if (adminUin == null || adminUin.isEmpty() || expectedName == null || expectedName.isEmpty()) {
            cb.onResult(false);
            return;
        }
        Long t = adminCacheTime.get(expectedName);
        boolean cachedOk = Boolean.TRUE.equals(adminCache.get(expectedName));
        long ttl = cachedOk
                ? Config.adminCacheMinutes(this) * 60000L
                : Config.adminFailSeconds(this) * 1000L;
        if (t != null && System.currentTimeMillis() - t < ttl && adminCache.containsKey(expectedName)) {
            cb.onResult(cachedOk);
            return;
        }
        startSearch(adminUin, true, () -> {
            AccessibilityNodeInfo root = getRootInActiveWindow();
            boolean ok = root != null && findTextNearTop(root, expectedName) != null;
            adminCache.put(expectedName, ok);
            adminCacheTime.put(expectedName, System.currentTimeMillis());
            Log.d(TAG, "admin search " + adminUin + " expected=" + expectedName + " ok=" + ok);
            cb.onResult(ok);
        }, () -> {
            adminCache.put(expectedName, false);
            adminCacheTime.put(expectedName, System.currentTimeMillis());
            cb.onResult(false);
        });
    }

    /** 自动同意好友：同步等待结果，供管理员命令使用 */
    public boolean acceptFriendSync(PendingIntent intent, String nickname, String qq, long timeoutMs) {
        final boolean[] result = {false};
        final CountDownLatch latch = new CountDownLatch(1);
        acceptFriend(intent, nickname, qq, ok -> {
            result[0] = ok;
            latch.countDown();
        });
        try { latch.await(timeoutMs, TimeUnit.MILLISECONDS); }
        catch (InterruptedException e) { Thread.currentThread().interrupt(); }
        return result[0];
    }

    private void acceptFriend(PendingIntent intent, String nickname, String qq, AdminCallback cb) {
        if (nickname == null || nickname.trim().isEmpty() || qq == null || !qq.matches("\\d{5,12}")) {
            cb.onResult(false);
            return;
        }
        if (!acceptingFriend.compareAndSet(false, true)) {
            cb.onResult(false);
            return;
        }
        if (intent != null) {
            try {
                intent.send();
            } catch (Exception e) {
                Log.e(TAG, "friend intent failed", e);
                finishAccept(cb, false);
                return;
            }
            new Handler(Looper.getMainLooper()).postDelayed(
                    () -> findFriendRow(nickname.trim(), qq, cb), 1800);
        } else {
            openNewFriends(() -> findFriendRow(nickname.trim(), qq, cb), cb);
        }
    }

    private void openNewFriends(Runnable after, AdminCallback cb) {
        try {
            Intent i = getPackageManager().getLaunchIntentForPackage("com.tencent.mobileqq");
            if (i != null) {
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
            }
        } catch (Exception e) {
            Log.e(TAG, "launch QQ failed", e);
            finishAccept(cb, false);
            return;
        }
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            AccessibilityNodeInfo root = getRootInActiveWindow();
            AccessibilityNodeInfo contacts = findText(root, "联系人");
            if (contacts == null) {
                Log.w(TAG, "contacts tab not found");
                finishAccept(cb, false);
                return;
            }
            clickNodeOrParent(contacts);
            new Handler(Looper.getMainLooper()).postDelayed(() -> {
                AccessibilityNodeInfo r = getRootInActiveWindow();
                AccessibilityNodeInfo nf = findText(r, "新朋友");
                if (nf == null) {
                    Log.w(TAG, "new friends entry not found");
                    finishAccept(cb, false);
                    return;
                }
                clickNodeOrParent(nf);
                new Handler(Looper.getMainLooper()).postDelayed(after, 1200);
            }, 1200);
        }, 1600);
    }

    private void findFriendRow(String nickname, String qq, AdminCallback cb) {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) { finishAccept(cb, false); return; }
        if (findTextNearTop(root, "新朋友") == null && findTextNearTop(root, "好友通知") == null) {
            Log.w(TAG, "not on friend request page");
            finishAccept(cb, false);
            return;
        }
        List<AccessibilityNodeInfo> rows = new ArrayList<>();
        collectFriendRows(root, nickname, qq, rows);
        if (rows.size() != 1) {
            Log.w(TAG, "friend row matches=" + rows.size());
            finishAccept(cb, false);
            return;
        }
        List<AccessibilityNodeInfo> buttons = new ArrayList<>();
        collectAcceptButtons(rows.get(0), buttons);
        if (buttons.size() != 1) {
            Log.w(TAG, "accept button matches=" + buttons.size());
            finishAccept(cb, false);
            return;
        }
        if (!clickNodeOrParent(buttons.get(0))) {
            finishAccept(cb, false);
            return;
        }
        new Handler(Looper.getMainLooper()).postDelayed(
                () -> verifyAccepted(nickname, qq, cb), 1600);
    }

    private void collectFriendRows(AccessibilityNodeInfo node, String nickname, String qq,
                                   List<AccessibilityNodeInfo> out) {
        if (node == null) return;
        CharSequence t = node.getText();
        if (t != null && t.toString().trim().equals(nickname)) {
            AccessibilityNodeInfo row = node;
            for (int i = 0; i < 6 && row != null; i++) {
                String text = rowText(row);
                boolean request = text.contains("请求添加") || text.contains("添加你为好友")
                        || text.contains("请求加你为好友");
                if (request) {
                    if (qq == null || qq.isEmpty() || text.contains(qq)) {
                        if (!out.contains(row)) out.add(row);
                    }
                    break;
                }
                row = row.getParent();
            }
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            collectFriendRows(node.getChild(i), nickname, qq, out);
        }
    }

    private String rowText(AccessibilityNodeInfo node) {
        StringBuilder sb = new StringBuilder();
        collectAllText(node, sb, 0);
        return sb.toString();
    }

    private void collectAllText(AccessibilityNodeInfo node, StringBuilder sb, int depth) {
        if (node == null || depth > 6) return;
        CharSequence t = node.getText();
        CharSequence d = node.getContentDescription();
        if (t != null) sb.append(t).append(' ');
        if (d != null) sb.append(d).append(' ');
        for (int i = 0; i < node.getChildCount(); i++) {
            collectAllText(node.getChild(i), sb, depth + 1);
        }
    }

    private void collectAcceptButtons(AccessibilityNodeInfo node,
                                      List<AccessibilityNodeInfo> out) {
        if (node == null) return;
        CharSequence t = node.getText();
        CharSequence d = node.getContentDescription();
        boolean match = (t != null && "同意".contentEquals(t))
                || (d != null && "同意".contentEquals(d));
        if (match) {
            AccessibilityNodeInfo clickable = clickableAncestor(node);
            if (clickable != null && !out.contains(clickable)) out.add(clickable);
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            collectAcceptButtons(node.getChild(i), out);
        }
    }

    private AccessibilityNodeInfo clickableAncestor(AccessibilityNodeInfo node) {
        AccessibilityNodeInfo n = node;
        for (int i = 0; i < 5 && n != null; i++) {
            if (n.isClickable()) return n;
            n = n.getParent();
        }
        return null;
    }

    private void collectExactText(AccessibilityNodeInfo node, String text,
                                  List<AccessibilityNodeInfo> out) {
        if (node == null) return;
        CharSequence t = node.getText();
        CharSequence d = node.getContentDescription();
        if ((t != null && text.contentEquals(t)) || (d != null && text.contentEquals(d))) {
            out.add(node);
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            collectExactText(node.getChild(i), text, out);
        }
    }

    private void verifyAccepted(String nickname, String qq, AdminCallback cb) {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) { finishAccept(cb, false); return; }
        StringBuilder sb = new StringBuilder();
        collectAllText(root, sb, 0);
        String all = sb.toString();
        if (all.contains("已添加") || all.contains("等待验证") || all.contains("已发送")) {
            finishAccept(cb, true);
            return;
        }
        List<AccessibilityNodeInfo> rows = new ArrayList<>();
        collectFriendRows(root, nickname, qq, rows);
        if (rows.isEmpty()) {
            finishAccept(cb, true);
            return;
        }
        List<AccessibilityNodeInfo> buttons = new ArrayList<>();
        collectAcceptButtons(rows.get(0), buttons);
        finishAccept(cb, buttons.isEmpty());
    }

    private void finishAccept(AdminCallback cb, boolean ok) {
        acceptingFriend.set(false);
        cb.onResult(ok);
    }

    /** 管理员校验：打开私聊资料页，读 QQ 号 */
    public void readProfile(String name, String uin, ProfileCallback cb) {
        if (uin == null || uin.isEmpty()) {
            cb.onProfile(name, "");
            return;
        }
        long okTtl = Config.adminCacheMinutes(this) * 60000L;
        CachedProfile cached = profileCache.get(name);
        if (cached != null && System.currentTimeMillis() - cached.time < okTtl && !cached.qq.isEmpty()) {
            cb.onProfile(cached.nickname, cached.qq);
            return;
        }
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(
                    "mqqwpa://im/chat?chat_type=wpa&uin=" + uin + "&version=1&src_type=web"));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (Exception e) {
            Log.e(TAG, "profile scheme failed", e);
            cb.onProfile(name, "");
            return;
        }

        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            AccessibilityNodeInfo root = getRootInActiveWindow();
            AccessibilityNodeInfo title = findTextNearTop(root, name);
            if (title == null) {
                Log.w(TAG, "profile title not found");
                cb.onProfile(name, "");
                return;
            }
            clickNodeOrParent(title);

            new Handler(Looper.getMainLooper()).postDelayed(() -> {
                AccessibilityNodeInfo p = getRootInActiveWindow();
                String qq = findQqNumber(p);
                String nickname = findProfileNickname(p, name);
                if (qq != null && !qq.isEmpty()) {
                    profileCache.put(name, new CachedProfile(nickname, qq));
                }
                Log.d(TAG, "profile " + nickname + " qq=" + qq);
                performGlobalAction(GLOBAL_ACTION_BACK);
                new Handler(Looper.getMainLooper()).postDelayed(
                        () -> cb.onProfile(nickname, qq == null ? "" : qq), 800);
            }, 2200);
        }, 2200);
    }

    private String findProfileNickname(AccessibilityNodeInfo node, String fallback) {
        String n = findNicknameNode(node, 0);
        return (n == null || n.trim().isEmpty()) ? fallback : n.trim();
    }

    private String findNicknameNode(AccessibilityNodeInfo node, int depth) {
        if (node == null || depth > 8) return null;
        android.graphics.Rect r = new android.graphics.Rect();
        node.getBoundsInScreen(r);
        CharSequence t = node.getText();
        int limit = getResources().getDisplayMetrics().heightPixels / 3;
        if (t != null && r.top < limit) {
            String s = t.toString().trim();
            if (!s.isEmpty()
                    && !s.contains("详细资料")
                    && !s.contains("QQ号")
                    && !s.contains("QQ 号")
                    && !s.contains("账号")
                    && !s.contains("昵称")
                    && !s.contains("资料")
                    && !s.matches("\\d+")) {
                return s;
            }
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            String hit = findNicknameNode(node.getChild(i), depth + 1);
            if (hit != null) return hit;
        }
        return null;
    }

    private String findQqNumber(AccessibilityNodeInfo node) {
        if (node == null) return "";
        return findLabeledQq(node);
    }

    private String findLabeledQq(AccessibilityNodeInfo node) {
        if (node == null) return "";
        CharSequence t = node.getText();
        if (t != null) {
            String s = t.toString();
            if (s.contains("QQ号") || s.contains("QQ 号") || s.contains("QQ：")
                    || s.contains("QQ:") || s.contains("账号")) {
                Matcher m = QQ_RE.matcher(s);
                if (m.find()) return m.group(1);
            }
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            String r = findLabeledQq(node.getChild(i));
            if (!r.isEmpty()) return r;
        }
        return "";
    }

    private AccessibilityNodeInfo findTextNearTop(AccessibilityNodeInfo node, String text) {
        if (node == null) return null;
        android.graphics.Rect r = new android.graphics.Rect();
        node.getBoundsInScreen(r);
        CharSequence t = node.getText();
        int limit = getResources().getDisplayMetrics().heightPixels / 4;
        if (t != null && t.toString().contains(text) && r.top < limit) return node;
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo hit = findTextNearTop(node.getChild(i), text);
            if (hit != null) return hit;
        }
        return null;
    }

    /** 由通知服务调用：打开聊天并发送 */
    public void sendReply(String name, String uin, String text) {
        sendReply(name, uin, text, false);
    }

    public void sendReply(String name, String uin, String text, boolean group) {
        sendReply(name, uin, text, group, null);
    }

    /** 先回桌面再触发通知 intent，保证 QQ 在前台时也能导航到目标聊天 */
    public void sendReply(String name, String uin, String text, boolean group, PendingIntent intent) {
        if (intent != null) {
            AppLog.add("回桌面后打开 " + name);
            performGlobalAction(GLOBAL_ACTION_HOME);
            new Handler(Looper.getMainLooper()).postDelayed(() -> {
                try {
                    intent.send();
                    AppLog.add("通知 intent 打开 " + name);
                } catch (Exception e) {
                    Log.e(TAG, "chat intent failed", e);
                    AppLog.add("通知 intent 失败 " + name);
                    searchThenScheme(name, uin, text, group);
                    return;
                }
                new Handler(Looper.getMainLooper()).postDelayed(() -> {
                    AccessibilityNodeInfo root = getRootInActiveWindow();
                    if (root != null && findChatInput(root) != null) {
                        AppLog.add("intent 已进入聊天 " + name);
                        new Handler(Looper.getMainLooper()).postDelayed(
                                () -> doSend(name, text), 800);
                    } else {
                        AppLog.add("intent 未进入聊天，转搜索");
                        searchThenScheme(name, uin, text, group);
                    }
                }, 2600);
            }, 700);
            return;
        }
        searchThenScheme(name, uin, text, group);
    }

    private void searchThenScheme(String name, String uin, String text, boolean group) {
        if (name == null || name.isEmpty()) {
            openChat(name, uin, group, () -> doSend(name, text));
            return;
        }
        startSearch(name, () -> {
            AppLog.add("搜索已打开 " + name);
            new Handler(Looper.getMainLooper()).postDelayed(() -> doSend(name, text), 600);
        }, () -> {
            AppLog.add("搜索失败，回退 scheme");
            openChat(name, uin, group, () -> doSend(name, text));
        });
    }

    /** 打开聊天后执行 after（表情截图用） */
    public void openChat(String name, String uin, Runnable after) {
        openChat(name, uin, false, after);
    }

    public void openChat(String name, String uin, boolean group, Runnable after) {
        if (group) {
            openGroup(name, uin, after);
            return;
        }
        if (uin != null && !uin.isEmpty()) {
            try {
                Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(
                        "mqqwpa://im/chat?chat_type=wpa&uin=" + uin + "&version=1&src_type=web"));
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
                AppLog.add("打开私聊 scheme " + uin);
            } catch (Exception e) {
                Log.e(TAG, "scheme failed", e);
                AppLog.add("scheme 失败 " + uin);
            }
            new Handler(Looper.getMainLooper()).postDelayed(() -> {
                AccessibilityNodeInfo root = getRootInActiveWindow();
                boolean open = root != null && findChatInput(root) != null;
                if (open) {
                    AppLog.add("私聊已打开 " + name);
                    new Handler(Looper.getMainLooper()).postDelayed(after, 800);
                } else {
                    AppLog.add("私聊未打开，转搜索 " + name);
                    startSearch(name, after, () -> {});
                }
            }, 2600);
        } else {
            startSearch(name, after, () -> {});
        }
    }

    /** 群：群号 scheme 优先，失败搜群名 */
    private void openGroup(String name, String uin, Runnable after) {
        if (uin != null && !uin.isEmpty()) {
            try {
                Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(
                        "mqqwpa://im/chat?chat_type=group&uin=" + uin + "&version=1&src_type=web"));
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
            } catch (Exception e) {
                Log.e(TAG, "group scheme failed", e);
                AppLog.add("群 scheme 失败 " + uin);
            }
            new Handler(Looper.getMainLooper()).postDelayed(() -> {
                AccessibilityNodeInfo root = getRootInActiveWindow();
                boolean ok = root != null && findChatInput(root) != null
                        && (name == null || name.isEmpty() || findTextNearTop(root, name) != null);
                if (ok) {
                    after.run();
                } else if (name != null && !name.isEmpty()) {
                    startSearch(name, after, () -> {});
                } else {
                    Log.w(TAG, "group open failed: " + uin);
                }
            }, 2600);
        } else if (name != null && !name.isEmpty()) {
            startSearch(name, after, () -> {});
        } else {
            Log.w(TAG, "group target has no uin and no name");
        }
    }

    /** 搜索并打开：成功执行 onSuccess，失败执行 onFail */
    private void startSearch(String query, Runnable onSuccess, Runnable onFail) {
        startSearch(query, false, onSuccess, onFail);
    }

    private void startSearch(String query, boolean firstResult, Runnable onSuccess, Runnable onFail) {
        AppLog.add("搜索 " + query);
        try {
            Intent i = getPackageManager().getLaunchIntentForPackage("com.tencent.mobileqq");
            if (i != null) {
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
            }
        } catch (Exception e) {
            Log.e(TAG, "launch QQ failed", e);
        }

        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            AccessibilityNodeInfo root = getRootInActiveWindow();
            AccessibilityNodeInfo topInput = findTopEditable(root);
            if (topInput != null) {
                typeAndSearch(topInput, query, firstResult, onSuccess, onFail);
                return;
            }
            AccessibilityNodeInfo search = findSearchEntry(root);
            if (search == null) {
                Log.w(TAG, "no search entry");
                AppLog.add("找不到搜索入口");
                onFail.run();
                return;
            }
            clickNodeOrParent(search);
            new Handler(Looper.getMainLooper()).postDelayed(() -> {
                AccessibilityNodeInfo r = getRootInActiveWindow();
                AccessibilityNodeInfo input = findTopEditable(r);
                if (input == null) input = findEditable(r);
                if (input == null) {
                    AppLog.add("找不到搜索输入框");
                    onFail.run();
                    return;
                }
                typeAndSearch(input, query, firstResult, onSuccess, onFail);
            }, 1000);
        }, 1400);
    }

    private void typeAndSearch(AccessibilityNodeInfo input, String query, boolean firstResult,
                               Runnable onSuccess, Runnable onFail) {
        Bundle args = new Bundle();
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, query);
        input.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args);
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            AccessibilityNodeInfo rr = getRootInActiveWindow();
            AccessibilityNodeInfo hit = firstResult ? findFirstResult(rr) : findSearchResult(rr, query);
            if (hit == null) {
                AppLog.add("搜索无结果 " + query);
                onFail.run();
                return;
            }
            clickNodeOrParent(hit);
            new Handler(Looper.getMainLooper()).postDelayed(onSuccess, 1800);
        }, 1600);
    }

    /** 只认屏幕下半部分的输入框，避免把主界面搜索框当聊天输入 */
    private AccessibilityNodeInfo findChatInput(AccessibilityNodeInfo node) {
        if (node == null) return null;
        if (node.isEditable()) {
            android.graphics.Rect r = new android.graphics.Rect();
            node.getBoundsInScreen(r);
            if (r.top > getResources().getDisplayMetrics().heightPixels / 2) return node;
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo hit = findChatInput(node.getChild(i));
            if (hit != null) return hit;
        }
        return null;
    }

    /** 屏幕上半部分的 editable，通常是搜索框 */
    private AccessibilityNodeInfo findTopEditable(AccessibilityNodeInfo node) {
        if (node == null) return null;
        if (node.isEditable()) {
            android.graphics.Rect r = new android.graphics.Rect();
            node.getBoundsInScreen(r);
            if (r.top < getResources().getDisplayMetrics().heightPixels / 3) return node;
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo hit = findTopEditable(node.getChild(i));
            if (hit != null) return hit;
        }
        return null;
    }

    private void doSend(String name, String text) {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) {
            Log.w(TAG, "no root window");
            return;
        }
        // 不再用标题校验拦截：intent/搜索已确定目标，标题节点可能是 contentDescription

        AccessibilityNodeInfo input = findChatInput(root);
        if (input == null) {
            Log.w(TAG, "no edit text");
            AppLog.add("找不到输入框 " + name);
            return;
        }
        input.performAction(AccessibilityNodeInfo.ACTION_FOCUS);
        Bundle args = new Bundle();
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text);
        boolean ok = input.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args);
        AppLog.add("输入 " + (ok ? "成功" : "失败") + " " + name);
        Log.d(TAG, "setText=" + ok + " for " + name);
        if (!ok) return;

        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            AccessibilityNodeInfo r = getRootInActiveWindow();
            if (r == null) return;
            AccessibilityNodeInfo send = findText(r, "发送");
            if (send == null) {
                Log.w(TAG, "no send button");
                AppLog.add("找不到发送按钮 " + name);
                return;
            }
            send.performAction(AccessibilityNodeInfo.ACTION_CLICK);
            AppLog.add("已点发送 " + name);
            Log.d(TAG, "clicked send");
        }, 800);
    }

    /** 点屏幕上方第一个可点击结果（用于按 QQ 号搜索，结果标题是昵称） */
    private AccessibilityNodeInfo findFirstResult(AccessibilityNodeInfo root) {
        AccessibilityNodeInfo best = null;
        int bestTop = Integer.MAX_VALUE;
        int minTop = getResources().getDisplayMetrics().heightPixels / 8;
        java.util.ArrayDeque<AccessibilityNodeInfo> q = new java.util.ArrayDeque<>();
        q.add(root);
        while (!q.isEmpty()) {
            AccessibilityNodeInfo n = q.removeFirst();
            if (n == null) continue;
            if (!n.isEditable() && n.getText() != null && n.getText().length() > 0
                    && hasClickableParent(n)) {
                String text = n.getText().toString().trim();
                String id = n.getViewIdResourceName();
                boolean tab = text.equals("全部") || text.equals("联系人") || text.equals("群聊")
                        || text.equals("聊天记录") || text.equals("搜索") || text.equals("取消");
                if (!tab && (id == null || !id.toLowerCase().contains("search"))) {
                    android.graphics.Rect r = new android.graphics.Rect();
                    n.getBoundsInScreen(r);
                    if (r.top >= minTop && r.top < bestTop) {
                        best = n;
                        bestTop = r.top;
                    }
                }
            }
            for (int i = 0; i < n.getChildCount(); i++) q.addLast(n.getChild(i));
        }
        return best;
    }

    private AccessibilityNodeInfo findSearchResult(AccessibilityNodeInfo node, String name) {
        AccessibilityNodeInfo exact = findExactResult(node, name);
        if (exact != null && hasClickableParent(exact)) return exact;
        AccessibilityNodeInfo starts = findStartsWithResult(node, name);
        return (starts != null && hasClickableParent(starts)) ? starts : null;
    }

    private AccessibilityNodeInfo findStartsWithResult(AccessibilityNodeInfo node, String name) {
        if (node == null || node.isEditable()) return null;
        CharSequence t = node.getText();
        if (t != null && t.toString().trim().startsWith(name)) return node;
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo hit = findStartsWithResult(node.getChild(i), name);
            if (hit != null) return hit;
        }
        return null;
    }

    private boolean hasClickableParent(AccessibilityNodeInfo node) {
        AccessibilityNodeInfo n = node;
        for (int i = 0; i < 5 && n != null; i++) {
            if (n.isClickable()) return true;
            n = n.getParent();
        }
        return false;
    }

    private AccessibilityNodeInfo findExactResult(AccessibilityNodeInfo node, String name) {
        if (node == null || node.isEditable()) return null;
        CharSequence t = node.getText();
        if (t != null && t.toString().trim().equals(name)) return node;
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo hit = findExactResult(node.getChild(i), name);
            if (hit != null) return hit;
        }
        return null;
    }

    private AccessibilityNodeInfo findContainsResult(AccessibilityNodeInfo node, String name) {
        if (node == null || node.isEditable()) return null;
        CharSequence t = node.getText();
        if (t != null && t.toString().contains(name)) return node;
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo hit = findContainsResult(node.getChild(i), name);
            if (hit != null) return hit;
        }
        return null;
    }

    private boolean clickNodeOrParent(AccessibilityNodeInfo node) {
        AccessibilityNodeInfo n = node;
        for (int i = 0; i < 5 && n != null; i++) {
            if (n.isClickable()) {
                return n.performAction(AccessibilityNodeInfo.ACTION_CLICK);
            }
            n = n.getParent();
        }
        return node.performAction(AccessibilityNodeInfo.ACTION_CLICK);
    }

    private AccessibilityNodeInfo findSearchEntry(AccessibilityNodeInfo node) {
        if (node == null) return null;
        String id = node.getViewIdResourceName();
        CharSequence t = node.getText();
        CharSequence d = node.getContentDescription();
        android.graphics.Rect r = new android.graphics.Rect();
        node.getBoundsInScreen(r);
        int topLimit = getResources().getDisplayMetrics().heightPixels / 3;
        if (r.top <= topLimit) {
            if (id != null && id.toLowerCase().contains("search")) return node;
            if (t != null && (t.toString().equals("搜索") || t.toString().equals("Search"))) return node;
            if (d != null && (d.toString().equals("搜索") || d.toString().equals("Search"))) return node;
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo hit = findSearchEntry(node.getChild(i));
            if (hit != null) return hit;
        }
        return null;
    }

    private AccessibilityNodeInfo findTextContains(AccessibilityNodeInfo node, String text) {
        if (node == null) return null;
        if (!node.isEditable()) {
            CharSequence t = node.getText();
            if (t != null && t.toString().contains(text)) return node;
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo r = findTextContains(node.getChild(i), text);
            if (r != null) return r;
        }
        return null;
    }

    private AccessibilityNodeInfo findEditable(AccessibilityNodeInfo node) {
        if (node == null) return null;
        if (node.isEditable()) return node;
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            AccessibilityNodeInfo r = findEditable(child);
            if (r != null) return r;
        }
        return null;
    }

    private AccessibilityNodeInfo findText(AccessibilityNodeInfo node, String text) {
        if (node == null) return null;
        CharSequence t = node.getText();
        CharSequence d = node.getContentDescription();
        if ((t != null && text.contentEquals(t)) || (d != null && text.contentEquals(d))) return node;
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo r = findText(node.getChild(i), text);
            if (r != null) return r;
        }
        return null;
    }
}
