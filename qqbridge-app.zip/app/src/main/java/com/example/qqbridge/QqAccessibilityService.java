package com.example.qqbridge;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.app.PendingIntent;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class QqAccessibilityService extends AccessibilityService {
    private static final String TAG = "QQBridge";
    private static volatile QqAccessibilityService instance;
    private static final Pattern QQ_RE = Pattern.compile("(\\d{5,12})");
    private final Map<String, CachedProfile> profileCache = new HashMap<>();
    private final Map<String, Boolean> adminCache = new HashMap<>();
    private final Map<String, Long> adminCacheTime = new HashMap<>();
    private final AtomicBoolean acceptingFriend = new AtomicBoolean(false);

    public interface AdminCallback {
        void onResult(boolean admin);
    }

    public interface ProfileCallback {
        void onProfile(String nickname, String qq);
    }

    public interface ActionCallback {
        void onResult(boolean ok, String detail);
    }

    private static class CachedProfile {
        final String nickname;
        final String qq;
        final long time;
        CachedProfile(String nickname, String qq) {
            this.nickname = nickname;
            this.qq = qq;
            this.time = System.currentTimeMillis();
        }
    }

    public static QqAccessibilityService get() { return instance; }

    @Override
    public void onServiceConnected() {
        instance = this;
        AppLog.add("无障碍已连接");
        Log.d(TAG, "accessibility connected");
    }

    @Override
    public void onDestroy() {
        instance = null;
        super.onDestroy();
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) {}
    @Override public void onInterrupt() {}

    /** 管理员校验：直接搜管理员 QQ 号，打开后核对聊天标题 */
    /** 主动加好友/加群：需要验证或页面不匹配就放弃，不填验证 */
    public boolean addFriendSync(String qq, long timeoutMs) {
        return friendOrGroupSync(qq, false, timeoutMs);
    }

    public boolean joinGroupSync(String uin, long timeoutMs) {
        return friendOrGroupSync(uin, true, timeoutMs);
    }

    private boolean friendOrGroupSync(String query, boolean group, long timeoutMs) {
        if (query == null || !query.matches("\\d{5,12}")) return false;
        final CountDownLatch latch = new CountDownLatch(1);
        final boolean[] result = {false};
        startSearch(query, true, group, () -> {
            AccessibilityNodeInfo root = getRootInActiveWindow();
            AccessibilityNodeInfo btn = group
                    ? firstText(root, "申请加入", "加入群聊", "加入")
                    : firstText(root, "加好友", "添加到通讯录", "加为好友");
            if (btn == null) {
                AppLog.add((group ? "加群" : "加好友") + "：找不到按钮");
                latch.countDown();
                return;
            }
            if (!clickNodeOrParent(btn)) {
                AppLog.add((group ? "加群" : "加好友") + "：按钮点不动");
                latch.countDown();
                return;
            }
            new Handler(Looper.getMainLooper()).postDelayed(() -> {
                AccessibilityNodeInfo r = getRootInActiveWindow();
                if (r == null) { latch.countDown(); return; }
                if (findTextContains(r, "已发送") != null
                        || findTextContains(r, "等待验证") != null
                        || findTextContains(r, "已申请") != null) {
                    result[0] = true;
                    latch.countDown();
                    return;
                }
                AccessibilityNodeInfo send = firstText(r, "发送", "确定", "完成");
                boolean needVerify = findEditable(r) != null;
                if (send != null && !needVerify) {
                    result[0] = clickNodeOrParent(send);
                } else if (needVerify) {
                    AppLog.add((group ? "加群" : "加好友") + "：需要验证，已放弃");
                } else {
                    AppLog.add((group ? "加群" : "加好友") + "：找不到发送按钮");
                }
                latch.countDown();
            }, 1800);
        }, latch::countDown);
        try { latch.await(timeoutMs, TimeUnit.MILLISECONDS); }
        catch (InterruptedException e) { Thread.currentThread().interrupt(); }
        return result[0];
    }

    private AccessibilityNodeInfo firstText(AccessibilityNodeInfo root, String... names) {
        for (String n : names) {
            AccessibilityNodeInfo hit = findTextContains(root, n);
            if (hit != null) return hit;
        }
        return null;
    }

    public void verifyAdminBySearch(String adminUin, String expectedName, AdminCallback cb) {
        if (adminUin == null || adminUin.isEmpty() || expectedName == null || expectedName.isEmpty()) {
            cb.onResult(false);
            return;
        }
        Long t = adminCacheTime.get(expectedName);
        boolean cachedOk = Boolean.TRUE.equals(adminCache.get(expectedName));
        long ttl = cachedOk
                ? Config.adminCacheMinutes(this) * 60000L
                : Config.adminFailSeconds(this) * 1000L;
        if (t != null && System.currentTimeMillis() - t < ttl && adminCache.containsKey(expectedName)) {
            cb.onResult(cachedOk);
            return;
        }
        startSearch(adminUin, true, () -> {
            AccessibilityNodeInfo root = getRootInActiveWindow();
            boolean ok = root != null && findTextNearTop(root, expectedName) != null;
            adminCache.put(expectedName, ok);
            adminCacheTime.put(expectedName, System.currentTimeMillis());
            Log.d(TAG, "admin search " + adminUin + " expected=" + expectedName + " ok=" + ok);
            cb.onResult(ok);
        }, () -> {
            adminCache.put(expectedName, false);
            adminCacheTime.put(expectedName, System.currentTimeMillis());
            cb.onResult(false);
        });
    }

    /** 自动同意好友：同步等待结果，供管理员命令使用 */
    /** 只同意“新朋友”页里最上面一条申请。 */
    public boolean acceptLatestSync(PendingIntent intent, long timeoutMs) {
        final CountDownLatch latch = new CountDownLatch(1);
        final boolean[] result = {false};
        Runnable click = () -> {
            AccessibilityNodeInfo root = getRootInActiveWindow();
            List<AccessibilityNodeInfo> buttons = new ArrayList<>();
            collectAcceptButtons(root, buttons);
            AppLog.add("待同意好友申请：" + buttons.size() + " 条");
            if (!buttons.isEmpty()) {
                result[0] = clickNodeOrParent(buttons.get(0));
                AppLog.add("已点同意第一条，共 " + buttons.size() + " 条");
            }
            latch.countDown();
        };
        if (intent != null) {
            try {
                intent.send();
                AppLog.add("好友申请：用 intent 打开申请页");
                new Handler(Looper.getMainLooper()).postDelayed(click, 1800);
            } catch (Exception e) {
                AppLog.add("好友申请 intent 失败 " + e);
                openNewFriends(click, ok -> latch.countDown());
            }
        } else {
            openNewFriends(click, ok -> latch.countDown());
        }
        try { latch.await(timeoutMs, TimeUnit.MILLISECONDS); }
        catch (InterruptedException e) { Thread.currentThread().interrupt(); }
        return result[0];
    }

    public boolean acceptFriendSync(PendingIntent intent, String nickname, String qq, long timeoutMs) {
        final boolean[] result = {false};
        final CountDownLatch latch = new CountDownLatch(1);
        acceptFriend(intent, nickname, qq, ok -> {
            result[0] = ok;
            latch.countDown();
        });
        try { latch.await(timeoutMs, TimeUnit.MILLISECONDS); }
        catch (InterruptedException e) { Thread.currentThread().interrupt(); }
        return result[0];
    }

    private void acceptFriend(PendingIntent intent, String nickname, String qq, AdminCallback cb) {
        if (nickname == null || nickname.trim().isEmpty() || qq == null || !qq.matches("\\d{5,12}")) {
            cb.onResult(false);
            return;
        }
        if (!acceptingFriend.compareAndSet(false, true)) {
            cb.onResult(false);
            return;
        }
        // 通知里的 intent 可能过期，统一从 QQ 的“新朋友”列表里找，按昵称+QQ 校验后再同意。
        if (intent != null) AppLog.add("忽略好友申请 intent，从新朋友页处理");
        openNewFriends(() -> findFriendRow(nickname.trim(), qq, cb), cb);
    }

    private void openNewFriends(Runnable after, AdminCallback cb) {
        try {
            Intent i = getPackageManager().getLaunchIntentForPackage("com.tencent.mobileqq");
            if (i != null) {
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
            }
        } catch (Exception e) {
            Log.e(TAG, "launch QQ failed", e);
            finishAccept(cb, false);
            return;
        }
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            AccessibilityNodeInfo root = getRootInActiveWindow();
            AccessibilityNodeInfo contacts = findText(root, "联系人");
            if (contacts == null) {
                Log.w(TAG, "contacts tab not found");
                finishAccept(cb, false);
                return;
            }
            clickNodeOrParent(contacts);
            new Handler(Looper.getMainLooper()).postDelayed(() -> {
                AccessibilityNodeInfo r = getRootInActiveWindow();
                AccessibilityNodeInfo nf = findText(r, "新朋友");
                if (nf == null) {
                    Log.w(TAG, "new friends entry not found");
                    finishAccept(cb, false);
                    return;
                }
                clickNodeOrParent(nf);
                new Handler(Looper.getMainLooper()).postDelayed(after, 1200);
            }, 1200);
        }, 1600);
    }

    private void findFriendRow(String nickname, String qq, AdminCallback cb) {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) { finishAccept(cb, false); return; }
        if (findTextNearTop(root, "新朋友") == null && findTextNearTop(root, "好友通知") == null) {
            Log.w(TAG, "not on friend request page");
            finishAccept(cb, false);
            return;
        }
        List<AccessibilityNodeInfo> rows = new ArrayList<>();
        collectFriendRows(root, nickname, qq, rows);
        if (rows.size() != 1) {
            Log.w(TAG, "friend row matches=" + rows.size());
            finishAccept(cb, false);
            return;
        }
        List<AccessibilityNodeInfo> buttons = new ArrayList<>();
        collectAcceptButtons(rows.get(0), buttons);
        if (buttons.size() != 1) {
            Log.w(TAG, "accept button matches=" + buttons.size());
            finishAccept(cb, false);
            return;
        }
        if (!clickNodeOrParent(buttons.get(0))) {
            finishAccept(cb, false);
            return;
        }
        new Handler(Looper.getMainLooper()).postDelayed(
                () -> verifyAccepted(nickname, qq, cb), 1600);
    }

    private void collectFriendRows(AccessibilityNodeInfo node, String nickname, String qq,
                                   List<AccessibilityNodeInfo> out) {
        if (node == null) return;
        CharSequence t = node.getText();
        if (t != null && t.toString().trim().equals(nickname)) {
            AccessibilityNodeInfo row = node;
            for (int i = 0; i < 6 && row != null; i++) {
                String text = rowText(row);
                boolean request = text.contains("请求添加") || text.contains("添加你为好友")
                        || text.contains("请求加你为好友");
                if (request) {
                    if (qq == null || qq.isEmpty() || text.contains(qq)) {
                        if (!out.contains(row)) out.add(row);
                    }
                    break;
                }
                row = row.getParent();
            }
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            collectFriendRows(node.getChild(i), nickname, qq, out);
        }
    }

    private String rowText(AccessibilityNodeInfo node) {
        StringBuilder sb = new StringBuilder();
        collectAllText(node, sb, 0);
        return sb.toString();
    }

    private void collectAllText(AccessibilityNodeInfo node, StringBuilder sb, int depth) {
        if (node == null || depth > 6) return;
        CharSequence t = node.getText();
        CharSequence d = node.getContentDescription();
        if (t != null) sb.append(t).append(' ');
        if (d != null) sb.append(d).append(' ');
        for (int i = 0; i < node.getChildCount(); i++) {
            collectAllText(node.getChild(i), sb, depth + 1);
        }
    }

    private void collectAcceptButtons(AccessibilityNodeInfo node,
                                      List<AccessibilityNodeInfo> out) {
        if (node == null) return;
        CharSequence t = node.getText();
        CharSequence d = node.getContentDescription();
        boolean match = (t != null && "同意".contentEquals(t))
                || (d != null && "同意".contentEquals(d));
        if (match) {
            AccessibilityNodeInfo clickable = clickableAncestor(node);
            if (clickable != null && !out.contains(clickable)) out.add(clickable);
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            collectAcceptButtons(node.getChild(i), out);
        }
    }

    private AccessibilityNodeInfo clickableAncestor(AccessibilityNodeInfo node) {
        AccessibilityNodeInfo n = node;
        for (int i = 0; i < 5 && n != null; i++) {
            if (n.isClickable()) return n;
            n = n.getParent();
        }
        return null;
    }

    private void collectExactText(AccessibilityNodeInfo node, String text,
                                  List<AccessibilityNodeInfo> out) {
        if (node == null) return;
        CharSequence t = node.getText();
        CharSequence d = node.getContentDescription();
        if ((t != null && text.contentEquals(t)) || (d != null && text.contentEquals(d))) {
            out.add(node);
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            collectExactText(node.getChild(i), text, out);
        }
    }

    private void verifyAccepted(String nickname, String qq, AdminCallback cb) {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) { finishAccept(cb, false); return; }
        StringBuilder sb = new StringBuilder();
        collectAllText(root, sb, 0);
        String all = sb.toString();
        if (all.contains("已添加") || all.contains("等待验证") || all.contains("已发送")) {
            finishAccept(cb, true);
            return;
        }
        List<AccessibilityNodeInfo> rows = new ArrayList<>();
        collectFriendRows(root, nickname, qq, rows);
        if (rows.isEmpty()) {
            finishAccept(cb, true);
            return;
        }
        List<AccessibilityNodeInfo> buttons = new ArrayList<>();
        collectAcceptButtons(rows.get(0), buttons);
        finishAccept(cb, buttons.isEmpty());
    }

    private void finishAccept(AdminCallback cb, boolean ok) {
        acceptingFriend.set(false);
        cb.onResult(ok);
    }

    /** 管理员校验：打开私聊资料页，读 QQ 号 */
    public void readProfile(String name, String uin, ProfileCallback cb) {
        if (uin == null || uin.isEmpty()) {
            cb.onProfile(name, "");
            return;
        }
        long okTtl = Config.adminCacheMinutes(this) * 60000L;
        CachedProfile cached = profileCache.get(name);
        if (cached != null && System.currentTimeMillis() - cached.time < okTtl && !cached.qq.isEmpty()) {
            cb.onProfile(cached.nickname, cached.qq);
            return;
        }
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(
                    "mqqwpa://im/chat?chat_type=wpa&uin=" + uin + "&version=1&src_type=web"));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (Exception e) {
            Log.e(TAG, "profile scheme failed", e);
            cb.onProfile(name, "");
            return;
        }

        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            AccessibilityNodeInfo root = getRootInActiveWindow();
            AccessibilityNodeInfo title = findTextNearTop(root, name);
            if (title == null) {
                Log.w(TAG, "profile title not found");
                cb.onProfile(name, "");
                return;
            }
            clickNodeOrParent(title);

            new Handler(Looper.getMainLooper()).postDelayed(() -> {
                AccessibilityNodeInfo p = getRootInActiveWindow();
                String qq = findQqNumber(p);
                String nickname = findProfileNickname(p, name);
                if (qq != null && !qq.isEmpty()) {
                    profileCache.put(name, new CachedProfile(nickname, qq));
                }
                Log.d(TAG, "profile " + nickname + " qq=" + qq);
                performGlobalAction(GLOBAL_ACTION_BACK);
                new Handler(Looper.getMainLooper()).postDelayed(
                        () -> cb.onProfile(nickname, qq == null ? "" : qq), 800);
            }, 2200);
        }, 2200);
    }

    private String findProfileNickname(AccessibilityNodeInfo node, String fallback) {
        String n = findNicknameNode(node, 0);
        return (n == null || n.trim().isEmpty()) ? fallback : n.trim();
    }

    private String findNicknameNode(AccessibilityNodeInfo node, int depth) {
        if (node == null || depth > 8) return null;
        android.graphics.Rect r = new android.graphics.Rect();
        node.getBoundsInScreen(r);
        CharSequence t = node.getText();
        int limit = getResources().getDisplayMetrics().heightPixels / 3;
        if (t != null && r.top < limit) {
            String s = t.toString().trim();
            if (!s.isEmpty()
                    && !s.contains("详细资料")
                    && !s.contains("QQ号")
                    && !s.contains("QQ 号")
                    && !s.contains("账号")
                    && !s.contains("昵称")
                    && !s.contains("资料")
                    && !s.matches("\\d+")) {
                return s;
            }
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            String hit = findNicknameNode(node.getChild(i), depth + 1);
            if (hit != null) return hit;
        }
        return null;
    }

    private String findQqNumber(AccessibilityNodeInfo node) {
        if (node == null) return "";
        return findLabeledQq(node);
    }

    private String findLabeledQq(AccessibilityNodeInfo node) {
        if (node == null) return "";
        CharSequence t = node.getText();
        if (t != null) {
            String s = t.toString();
            if (s.contains("QQ号") || s.contains("QQ 号") || s.contains("QQ：")
                    || s.contains("QQ:") || s.contains("账号")) {
                Matcher m = QQ_RE.matcher(s);
                if (m.find()) return m.group(1);
            }
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            String r = findLabeledQq(node.getChild(i));
            if (!r.isEmpty()) return r;
        }
        return "";
    }

    private AccessibilityNodeInfo findTextNearTop(AccessibilityNodeInfo node, String text) {
        if (node == null) return null;
        android.graphics.Rect r = new android.graphics.Rect();
        node.getBoundsInScreen(r);
        CharSequence t = node.getText();
        CharSequence d = node.getContentDescription();
        int limit = getResources().getDisplayMetrics().heightPixels / 4;
        if (r.top < limit
                && ((t != null && t.toString().contains(text))
                || (d != null && d.toString().contains(text)))) return node;
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo hit = findTextNearTop(node.getChild(i), text);
            if (hit != null) return hit;
        }
        return null;
    }

    /** 管理员命令校验：必须从这条通知对应的聊天里读出真实 QQ，和配置的管理员号一致。 */
    public void verifyAdminFromChat(PendingIntent intent, String name, String expectedUin, AdminCallback cb) {
        AppLog.add("校验管理员 " + name + " → " + expectedUin);
        if (intent != null) {
            try {
                intent.send();
            } catch (Exception e) {
                AppLog.add("管理员校验：打开聊天失败 " + e);
                cb.onResult(false);
                return;
            }
            new Handler(Looper.getMainLooper()).postDelayed(
                    () -> verifyByChatTitle(expectedUin, cb), 2400);
        } else {
            startSearch(name, false, false,
                    () -> new Handler(Looper.getMainLooper()).postDelayed(
                            () -> verifyByChatTitle(expectedUin, cb), 1500),
                    () -> cb.onResult(false));
        }
    }

    private void verifyByChatTitle(String expectedUin, AdminCallback cb) {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        AccessibilityNodeInfo title = findTitleNode(root,
                getResources().getDisplayMetrics().heightPixels / 6);
        if (title == null) {
            AppLog.add("管理员校验：找不到聊天标题");
            cb.onResult(false);
            return;
        }
        clickNodeOrParent(title);
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            AccessibilityNodeInfo profile = getRootInActiveWindow();
            String qq = findQqNumber(profile);
            boolean ok = qq != null && !qq.isEmpty() && expectedUin.equals(qq);
            AppLog.add("管理员校验 QQ=" + qq + " 期望=" + expectedUin + " ok=" + ok);
            performGlobalAction(GLOBAL_ACTION_BACK);
            new Handler(Looper.getMainLooper()).postDelayed(() -> cb.onResult(ok), 700);
        }, 2000);
    }

    private AccessibilityNodeInfo findTitleNode(AccessibilityNodeInfo node, int limit) {
        if (node == null) return null;
        android.graphics.Rect r = new android.graphics.Rect();
        node.getBoundsInScreen(r);
        String id = node.getViewIdResourceName();
        if (r.top < limit && id != null && id.toLowerCase().contains("title")
                && (node.getText() != null || node.getContentDescription() != null)) {
            return node;
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo hit = findTitleNode(node.getChild(i), limit);
            if (hit != null) return hit;
        }
        return null;
    }

    /** 管理员命令：按 QQ 号搜索并发送好友申请。 */
    public void addFriend(String uin, String remark, ActionCallback cb) {
        if (uin == null || !uin.matches("\\d{5,12}")) {
            cb.onResult(false, "QQ 号格式不对");
            return;
        }
        AppLog.add("加好友 " + uin);
        startSearch(uin, true, () -> new Handler(Looper.getMainLooper()).postDelayed(() -> {
            AccessibilityNodeInfo root = getRootInActiveWindow();
            AccessibilityNodeInfo add = findTextContains(root, "加好友");
            if (add == null) add = findTextContains(root, "添加到通讯录");
            if (add == null) {
                AppLog.add("加好友：没找到按钮");
                cb.onResult(false, "没找到加好友按钮（可能已是好友/页面不同）");
                return;
            }
            clickNodeOrParent(add);
            new Handler(Looper.getMainLooper()).postDelayed(() -> {
                AccessibilityNodeInfo dialog = getRootInActiveWindow();
                AccessibilityNodeInfo input = findEditable(dialog);
                if (input != null && remark != null && !remark.trim().isEmpty()) {
                    Bundle args = new Bundle();
                    args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,
                            remark.trim());
                    input.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args);
                }
                AccessibilityNodeInfo send = findBottomTextExact(dialog, "发送");
                if (send == null) send = findBottomTextExact(dialog, "确定");
                if (send == null) send = findBottomTextContains(dialog, "发送");
                if (send == null) {
                    AppLog.add("加好友：没找到发送按钮");
                    cb.onResult(false, "没找到发送按钮，请手动确认");
                    return;
                }
                send.performAction(AccessibilityNodeInfo.ACTION_CLICK);
                AppLog.add("加好友：已点发送");
                cb.onResult(true, "已发送好友申请");
            }, 1300);
        }, 1800), () -> cb.onResult(false, "搜索不到这个 QQ"));
    }

    /** 由通知服务调用：打开聊天并发送 */
    public void sendReply(String name, String uin, String text) {
        sendReply(name, uin, text, false);
    }

    public void sendReply(String name, String uin, String text, boolean group) {
        sendReply(name, uin, text, group, null);
    }

    private boolean chatLooksOpen(String name) {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (!qqForeground(root) || findChatInput(root) == null) return false;
        if (name == null || name.isEmpty()) return true;
        String title = findChatTitle(root, getResources().getDisplayMetrics().heightPixels / 6);
        return title == null || title.contains(name) || name.contains(title);
    }

    private boolean cloneMode() {
        return Config.cloneUser(this) > 0 || Config.shizukuClone(this);
    }

    /** 收到消息就先跳到 QQ（不等回复生成）；有通知 intent 优先用它。 */
    public void jumpToChat(String name, String uin, boolean group, PendingIntent intent, Runnable after) {
        // 配置了分身用户时，通知 intent 可能打不开分身；优先用 root/Shizuku 的 am start --user。
        if (cloneMode()) {
            AppLog.add("有消息，按分身用户跳转 " + name);
            openChat(name, uin, group, after == null ? () -> {} : after);
            return;
        }
        if (intent != null) {
            try {
                intent.send();
                AppLog.add("有消息，通知 intent 跳转 " + name);
                new Handler(Looper.getMainLooper()).postDelayed(
                        after == null ? () -> {} : after, 1200);
                return;
            } catch (Exception e) {
                AppLog.add("有消息，intent 跳转失败 " + e);
            }
        }
        AppLog.add("有消息，按配置跳转 " + name);
        openChat(name, uin, group, after == null ? () -> {} : after);
    }

    private void done(Runnable r) {
        if (r != null) r.run();
    }

    /** 打开一次聊天，然后按顺序逐条发送，上一条点完发送再发下一条。 */
    public void sendParts(String name, String uin, boolean group, java.util.List<String> parts) {
        if (parts == null || parts.isEmpty()) return;
        if (chatLooksOpen(name)) {
            sendPartsAt(name, parts, 0);
            return;
        }
        openChat(name, uin, group, () -> sendPartsAt(name, parts, 0));
    }

    private void sendPartsAt(String name, java.util.List<String> parts, int index) {
        if (index >= parts.size()) return;
        doSend(name, parts.get(index), () -> new Handler(Looper.getMainLooper()).post(
                () -> sendPartsAt(name, parts, index + 1)));
    }

    /** 优先用通知自带的 contentIntent：分身/多用户（UserHandle 999）只有它能打开正确的 QQ。 */
    public void sendReply(String name, String uin, String text, boolean group, PendingIntent intent) {
        if (name != null && !name.isEmpty() && chatLooksOpen(name)) {
            AppLog.add("聊天已在前台，直接发送 " + name);
            waitInputAndSend(name, text, 0);
            return;
        }
        if (cloneMode()) {
            AppLog.add("按分身用户发送 " + name);
            openChat(name, uin, group, () -> waitInputAndSend(name, text, 0));
            return;
        }
        if (intent == null && name != null) {
            intent = QqNotificationService.lastIntent(name);
            if (intent != null) AppLog.add("复用上次通知 intent " + name);
        }
        if (intent != null) {
            try {
                intent.send();
                AppLog.add("通知 intent 打开 " + name);
                waitInputAndSend(name, text, 0, () -> {
                    AppLog.add("intent 没进聊天，改用配置打开 " + name);
                    openChat(name, uin, group, () -> waitInputAndSend(name, text, 0));
                });
                return;
            } catch (Exception e) {
                AppLog.add("通知 intent 失败，转号码打开 " + e);
            }
        }
        AppLog.add("无 intent，打开聊天 " + name);
        openChat(name, uin, group, () -> waitInputAndSend(name, text, 0));
    }

    private void waitInputAndSend(String name, String text, int attempt) {
        waitInputAndSend(name, text, attempt, () -> AppLog.add("未进入聊天，放弃 " + name));
    }

    private void waitInputAndSend(String name, String text, int attempt, Runnable onFail) {
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            AccessibilityNodeInfo root = getRootInActiveWindow();
            if (root != null && findChatInput(root) != null) {
                AppLog.add("输入框就绪 " + name);
                doSend(name, text);
            } else if (attempt < 3) {
                AppLog.add("等聊天加载 " + name);
                waitInputAndSend(name, text, attempt + 1, onFail);
            } else {
                AppLog.add("未进入聊天，换一种方式 " + name);
                onFail.run();
            }
        }, 2000);
    }

    private boolean clickConversation(String name) {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return false;
        AccessibilityNodeInfo node = findConversationRow(root, name);
        if (node == null) return false;
        return clickNodeOrParent(node);
    }

    private AccessibilityNodeInfo findConversationRow(AccessibilityNodeInfo node, String name) {
        if (node == null) return null;
        CharSequence t = node.getText();
        if (t != null && t.toString().trim().equals(name)) {
            android.graphics.Rect r = new android.graphics.Rect();
            node.getBoundsInScreen(r);
            if (r.top > getResources().getDisplayMetrics().heightPixels / 10) return node;
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo hit = findConversationRow(node.getChild(i), name);
            if (hit != null) return hit;
        }
        return null;
    }

    private void searchThenScheme(String name, String uin, String text, boolean group) {
        if (name == null || name.isEmpty()) {
            openChat(name, uin, group, () -> doSend(name, text));
            return;
        }
        startSearch(name, false, group, () -> {
            AppLog.add("搜索已打开 " + name);
            new Handler(Looper.getMainLooper()).postDelayed(() -> doSend(name, text), 600);
        }, () -> {
            AppLog.add("搜索失败，回退 scheme");
            openChat(name, uin, group, () -> doSend(name, text));
        });
    }

    /** 轮询等待目标聊天真正打开（输入框出现；群聊还要求标题匹配）。 */
    private void awaitChat(String name, boolean group, Runnable onOk, Runnable onFail, int attempt) {
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            AccessibilityNodeInfo root = getRootInActiveWindow();
            boolean input = root != null && findChatInput(root) != null;
            // 群标题可能是 contentDescription/带人数，不用它判断是否进群。
            boolean titled = true;
            if (input && titled) {
                onOk.run();
            } else if (attempt < 4) {
                awaitChat(name, group, onOk, onFail, attempt + 1);
            } else {
                onFail.run();
            }
        }, 1200);
    }

    /** 打开聊天后执行 after（表情截图用） */
    public void openChat(String name, String uin, Runnable after) {
        openChat(name, uin, false, after);
    }

    public void openChat(String name, String uin, boolean group, Runnable after) {
        if (group) {
            openGroup(name, uin, after);
            return;
        }
        if (name != null && !name.isEmpty() && uin != null && !uin.isEmpty()) {
            MemoryStore.setProfile(this, name, null, uin);
        }
        if (uin != null && !uin.isEmpty()) {
            String uri = "mqqwpa://im/chat?chat_type=wpa&uin=" + uin
                    + "&version=1&src_type=web";
            if (tryRootOpen(uri, name, false, after)) return;
            openWithUri(uri, name, false, after);
        } else {
            startSearch(name, false, false, after, () -> {});
        }
    }

    private boolean looksFailed(String out) {
        return out == null || out.contains("Error") || out.contains("Exception")
                || out.contains("does not exist") || out.contains("Permission denied")
                || out.contains("timeout") || out.contains("error:")
                || !out.contains("Starting");
    }

    /** 有 root 且配置了分身用户时，用 am start --user N 打开分身 QQ。返回 true 表示已尝试。 */
    private boolean tryRootOpen(final String uri, final String name, final boolean group,
                                final Runnable after) {
        int configured = Config.cloneUser(this);
        final int user = configured > 0 ? configured : (Config.shizukuClone(this) ? 999 : 0);
        if (user <= 0) return false;
        final boolean useShizuku = Config.shizukuClone(this);
        new Thread(() -> {
            String cmd = "am start --user " + user
                    + " -a android.intent.action.VIEW -d '" + uri + "'";
            String out;
            if (useShizuku) {
                out = ShizukuShell.run(this, cmd);
                AppLog.add("shizuku am start user=" + user + "：" + out);
                if (looksFailed(out) && RootShell.available()) {
                    AppLog.add("Shizuku 没成功，改走 root");
                    out = RootShell.run(cmd);
                    AppLog.add("root am start user=" + user + "：" + out);
                }
            } else {
                if (!RootShell.available()) {
                    AppLog.add("root 不可用，退回本用户打开");
                    new Handler(Looper.getMainLooper()).post(() -> openWithUri(uri, name, group, after));
                    return;
                }
                out = RootShell.run(cmd);
                AppLog.add("root am start user=" + user + "：" + out);
            }
            final String result = out;
            new Handler(Looper.getMainLooper()).post(() -> {
                boolean fail = result.contains("Error") || result.contains("Exception")
                        || result.contains("does not exist") || result.contains("unable");
                if (fail) {
                    openWithUri(uri, name, group, after);
                } else {
                    awaitChat(name, group, after,
                            () -> openWithUri(uri, name, group, after), 0);
                }
            });
        }).start();
        return true;
    }

    private void openWithUri(String uri, String name, boolean group, Runnable after) {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(uri));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
            AppLog.add("scheme 打开 " + uri);
        } catch (Exception e) {
            AppLog.add("scheme 失败 " + e);
        }
        awaitChat(name, group, after, () -> {
            if (name != null && !name.isEmpty()) startSearch(name, false, group, after, () -> {});
        }, 0);
    }

    /** 群：群号 scheme 优先，失败搜群名（只点群聊结果） */
    private void openGroup(String name, String uin, Runnable after) {
        if (uin != null && !uin.isEmpty()) {
            // 主路径：群号 scheme 直接进群，最快；搜索只作兜底。
            String uri = "mqqwpa://im/chat?chat_type=group&uin=" + uin
                    + "&version=1&src_type=web";
            if (tryRootOpen(uri, name, true, after)) return;
            openWithUri(uri, name, true, after);
        } else if (name != null && !name.isEmpty()) {
            startSearch(name, false, true, after, () -> {});
        } else {
            Log.w(TAG, "group target has no uin and no name");
        }
    }

    private static final String QQ_PKG = "com.tencent.mobileqq";

    /** 前台必须是 QQ，避免 QQ 没起来时把字打进 QQBridge 自己的输入框。 */
    private boolean qqForeground(AccessibilityNodeInfo root) {
        return root != null && QQ_PKG.equals(String.valueOf(root.getPackageName()));
    }

    private void launchQq() {
        launchQqApp(null);
    }

    /** 启动 QQ 主界面；配置了分身用户时用 am start --user 999，失败回落主用户。 */
    private void launchQqApp(Runnable after) {
        final int user = Config.cloneUser(this);
        if (user <= 0) {
            launchQqMain();
            new Handler(Looper.getMainLooper()).postDelayed(
                    after == null ? () -> {} : after, 1600);
            return;
        }
        new Thread(() -> {
            String cmd = "am start --user " + user
                    + " -a android.intent.action.MAIN"
                    + " -c android.intent.category.LAUNCHER -p " + QQ_PKG;
            String out;
            if (Config.shizukuClone(this)) out = ShizukuShell.run(this, cmd);
            else if (RootShell.available()) out = RootShell.run(cmd);
            else out = "no root/shizuku";
            AppLog.add("启动分身 QQ：" + out);
            boolean fail = out.contains("Error") || out.contains("Exception")
                    || out.contains("does not exist") || out.contains("no root");
            new Handler(Looper.getMainLooper()).postDelayed(() -> {
                if (fail) launchQqMain();
                if (after != null) after.run();
            }, 1500);
        }).start();
    }

    private void launchQqMain() {
        try {
            Intent i = getPackageManager().getLaunchIntentForPackage(QQ_PKG);
            if (i == null) {
                AppLog.add("系统看不到 QQ（未安装/被隐藏/包可见性）");
                return;
            }
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
            startActivity(i);
            AppLog.add("拉起 QQ");
        } catch (Exception e) {
            Log.e(TAG, "launch QQ failed", e);
            AppLog.add("拉起 QQ 失败 " + e.getMessage());
        }
    }

    /** 搜索并打开：成功执行 onSuccess，失败执行 onFail */
    private void startSearch(String query, Runnable onSuccess, Runnable onFail) {
        startSearch(query, false, false, onSuccess, onFail);
    }

    private void startSearch(String query, boolean firstResult, Runnable onSuccess, Runnable onFail) {
        startSearch(query, firstResult, false, onSuccess, onFail);
    }

    private void startSearch(String query, boolean firstResult, boolean group,
                             Runnable onSuccess, Runnable onFail) {
        AppLog.add("搜索 " + query + (group ? "（群）" : "（私聊）"));
        launchQq();
        awaitSearchUi(query, firstResult, group, onSuccess, onFail, 0);
    }

    /** QQ 冷启动可能超过 8 秒，轮询等搜索框，不再写死 1.4 秒。 */
    private void awaitSearchUi(String query, boolean firstResult, boolean group,
                               Runnable onSuccess, Runnable onFail, int attempt) {
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            AccessibilityNodeInfo root = getRootInActiveWindow();
            if (!qqForeground(root)) {
                if (attempt >= 7) {
                    AppLog.add("QQ 未到前台，停止（检查后台弹出界面权限）");
                    onFail.run();
                    return;
                }
                if (attempt == 2) launchQq();
                awaitSearchUi(query, firstResult, group, onSuccess, onFail, attempt + 1);
                return;
            }
            AccessibilityNodeInfo topInput = findTopEditable(root);
            if (topInput != null) {
                typeAndSearch(topInput, query, firstResult, group, onSuccess, onFail, 0);
                return;
            }
            AccessibilityNodeInfo search = findSearchEntry(root);
            if (search != null) {
                clickNodeOrParent(search);
                awaitSearchInput(query, firstResult, group, onSuccess, onFail, 0);
                return;
            }
            if (attempt < 7) {
                awaitSearchUi(query, firstResult, group, onSuccess, onFail, attempt + 1);
            } else {
                Log.w(TAG, "no search entry");
                AppLog.add("找不到搜索入口");
                onFail.run();
            }
        }, attempt == 0 ? 1200 : 1000);
    }

    private void awaitSearchInput(String query, boolean firstResult, boolean group,
                                  Runnable onSuccess, Runnable onFail, int attempt) {
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            AccessibilityNodeInfo r = getRootInActiveWindow();
            AccessibilityNodeInfo input = findTopEditable(r);
            if (input != null) {
                typeAndSearch(input, query, firstResult, group, onSuccess, onFail, 0);
                return;
            }
            if (attempt < 4) {
                awaitSearchInput(query, firstResult, group, onSuccess, onFail, attempt + 1);
            } else {
                AppLog.add("找不到搜索输入框");
                onFail.run();
            }
        }, 800);
    }

    private void typeAndSearch(AccessibilityNodeInfo input, String query, boolean firstResult,
                               boolean group, Runnable onSuccess, Runnable onFail) {
        typeAndSearch(input, query, firstResult, group, onSuccess, onFail, 0);
    }

    private void typeAndSearch(AccessibilityNodeInfo input, String query, boolean firstResult,
                               boolean group, Runnable onSuccess, Runnable onFail, int attempt) {
        if (attempt == 0) {
            input.performAction(AccessibilityNodeInfo.ACTION_FOCUS);
            Bundle args = new Bundle();
            args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, query);
            input.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args);
            new Handler(Looper.getMainLooper()).postDelayed(() -> {
                if (Build.VERSION.SDK_INT >= 30) {
                    input.performAction(
                            AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.getId());
                }
                // 群聊只点“群聊”结果，私聊只点“联系人”结果，避免同名群/人串台。
                clickSearchTab(getRootInActiveWindow(), group ? "群聊" : "联系人");
            }, 500);
        }
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            AccessibilityNodeInfo rr = getRootInActiveWindow();
            AccessibilityNodeInfo hit = firstResult ? findFirstResult(rr) : findSearchResult(rr, query);
            if (hit == null) {
                if (attempt < 5) {
                    typeAndSearch(input, query, firstResult, group, onSuccess, onFail, attempt + 1);
                } else {
                    AppLog.add("搜索无结果 " + query);
                    onFail.run();
                }
                return;
            }
            clickNodeOrParent(hit);
            new Handler(Looper.getMainLooper()).postDelayed(onSuccess, 2200);
        }, attempt == 0 ? 1200 : 1000);
    }

    private boolean clickSearchTab(AccessibilityNodeInfo node, String label) {
        if (node == null) return false;
        CharSequence t = node.getText();
        CharSequence d = node.getContentDescription();
        String text = t == null ? "" : t.toString().trim();
        String desc = d == null ? "" : d.toString().trim();
        if (text.equals(label) || desc.equals(label)) {
            android.graphics.Rect r = new android.graphics.Rect();
            node.getBoundsInScreen(r);
            if (r.top < getResources().getDisplayMetrics().heightPixels / 3) {
                return clickNodeOrParent(node);
            }
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            if (clickSearchTab(node.getChild(i), label)) return true;
        }
        return false;
    }

    /** 只认屏幕下半部分的输入框，避免把主界面搜索框当聊天输入 */
    private AccessibilityNodeInfo findChatInput(AccessibilityNodeInfo node) {
        if (node == null) return null;
        if (node.isEditable()) {
            android.graphics.Rect r = new android.graphics.Rect();
            node.getBoundsInScreen(r);
            if (r.top > getResources().getDisplayMetrics().heightPixels / 2) return node;
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo hit = findChatInput(node.getChild(i));
            if (hit != null) return hit;
        }
        return null;
    }

    /** 屏幕上半部分的 editable，通常是搜索框 */
    private AccessibilityNodeInfo findTopEditable(AccessibilityNodeInfo node) {
        if (node == null) return null;
        if (node.isEditable()) {
            android.graphics.Rect r = new android.graphics.Rect();
            node.getBoundsInScreen(r);
            if (r.top < getResources().getDisplayMetrics().heightPixels / 3) return node;
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo hit = findTopEditable(node.getChild(i));
            if (hit != null) return hit;
        }
        return null;
    }

    /** 只在能明确拿到标题节点时校验；避免把空白/错误聊天当成目标。 */
    private String findChatTitle(AccessibilityNodeInfo node, int limit) {
        if (node == null) return null;
        android.graphics.Rect r = new android.graphics.Rect();
        node.getBoundsInScreen(r);
        String id = node.getViewIdResourceName();
        if (r.top < limit && id != null && id.toLowerCase().contains("title")) {
            CharSequence t = node.getText();
            if (t == null || t.length() == 0) t = node.getContentDescription();
            if (t != null) {
                String value = t.toString().trim();
                boolean junk = value.contains("返回") || value.contains("未读")
                        || value.contains("消息") || value.contains("聊天")
                        || value.matches("\\d+");
                if (!junk && value.length() > 0 && value.length() <= 40) return value;
            }
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            String hit = findChatTitle(node.getChild(i), limit);
            if (hit != null) return hit;
        }
        return null;
    }

    /** 把当前界面的无障碍节点树导出成文本，用来定位发送按钮/标题，不需要 root。 */
    public String dumpUi() {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return "当前没有活动窗口（无障碍未连接或界面不可见）";
        StringBuilder sb = new StringBuilder();
        dumpNode(root, sb, 0);
        return sb.toString();
    }

    private void dumpNode(AccessibilityNodeInfo node, StringBuilder sb, int depth) {
        if (node == null || depth > 18 || sb.length() > 30000) return;
        android.graphics.Rect r = new android.graphics.Rect();
        node.getBoundsInScreen(r);
        for (int i = 0; i < depth; i++) sb.append("  ");
        sb.append(node.getClassName()).append(" id=").append(node.getViewIdResourceName())
                .append(" text=").append(node.getText())
                .append(" desc=").append(node.getContentDescription())
                .append(" bounds=").append(r)
                .append(node.isClickable() ? " click" : "")
                .append(node.isEditable() ? " edit" : "")
                .append('\n');
        for (int i = 0; i < node.getChildCount(); i++) {
            dumpNode(node.getChild(i), sb, depth + 1);
        }
    }

    private void doSend(String name, String text) {
        doSend(name, text, null);
    }

    private void doSend(String name, String text, Runnable onDone) {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) {
            Log.w(TAG, "no root window");
            done(onDone);
            return;
        }
        if (!qqForeground(root)) {
            AppLog.add("当前不是 QQ，放弃发送");
            done(onDone);
            return;
        }
        String title = findChatTitle(root, getResources().getDisplayMetrics().heightPixels / 6);
        if (title != null) {
            AppLog.add("当前聊天 " + title + "，目标 " + name);
            if (name != null && !name.isEmpty()) MemoryStore.setProfile(this, name, title, null);
            if (name != null && !name.isEmpty()
                    && !title.contains(name) && !name.contains(title)
                    && !title.equals("QQ") && !title.equals("消息") && !title.equals("聊天")) {
                // 昵称可能是备注/群名片，标题对不上不再拦截发送，只记录。
                AppLog.add("标题不一致，继续发送 " + name + "，当前 " + title);
            }
        }

        AccessibilityNodeInfo input = findChatInput(root);
        if (input == null) {
            Log.w(TAG, "no edit text");
            AppLog.add("找不到输入框 " + name);
            done(onDone);
            return;
        }
        input.performAction(AccessibilityNodeInfo.ACTION_FOCUS);
        Bundle args = new Bundle();
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text);
        boolean ok = input.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args);
        AppLog.add("输入 " + (ok ? "成功" : "失败") + " " + name);
        Log.d(TAG, "setText=" + ok + " for " + name);
        if (!ok) {
            done(onDone);
            return;
        }

        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            AccessibilityNodeInfo r = getRootInActiveWindow();
            if (r == null) {
                done(onDone);
                return;
            }
            AccessibilityNodeInfo send = findSendButton(r);
            if (send != null) {
                send.performAction(AccessibilityNodeInfo.ACTION_CLICK);
                AppLog.add("已点发送 " + name);
                Log.d(TAG, "clicked send");
                done(onDone);
            } else {
                // 按钮没暴露给无障碍时，按输入框的位置点它右侧。
                android.graphics.Rect ir = new android.graphics.Rect();
                AccessibilityNodeInfo liveInput = findChatInput(r);
                if (liveInput != null) liveInput.getBoundsInScreen(ir);
                else input.getBoundsInScreen(ir);
                int w = getResources().getDisplayMetrics().widthPixels;
                int dp = Math.round(getResources().getDisplayMetrics().density);
                int x = Math.min(w - 30 * dp, ir.right + 30 * dp);
                int y = ir.centerY();
                tapPoint(x, y);
                AppLog.add("按输入框位置点发送 " + x + "," + y + " " + name);
                done(onDone);
            }
        }, 1200);
    }

    /** 点屏幕上方第一个可点击结果（用于按 QQ 号搜索，结果标题是昵称） */
    private AccessibilityNodeInfo findFirstResult(AccessibilityNodeInfo root) {
        AccessibilityNodeInfo best = null;
        int bestTop = Integer.MAX_VALUE;
        int minTop = getResources().getDisplayMetrics().heightPixels / 8;
        java.util.ArrayDeque<AccessibilityNodeInfo> q = new java.util.ArrayDeque<>();
        q.add(root);
        while (!q.isEmpty()) {
            AccessibilityNodeInfo n = q.removeFirst();
            if (n == null) continue;
            if (!n.isEditable() && n.getText() != null && n.getText().length() > 0
                    && hasClickableParent(n)) {
                String text = n.getText().toString().trim();
                String id = n.getViewIdResourceName();
                boolean tab = text.equals("全部") || text.equals("联系人") || text.equals("群聊")
                        || text.equals("聊天记录") || text.equals("搜索") || text.equals("取消");
                if (!tab && (id == null || !id.toLowerCase().contains("search"))) {
                    android.graphics.Rect r = new android.graphics.Rect();
                    n.getBoundsInScreen(r);
                    if (r.top >= minTop && r.top < bestTop) {
                        best = n;
                        bestTop = r.top;
                    }
                }
            }
            for (int i = 0; i < n.getChildCount(); i++) q.addLast(n.getChild(i));
        }
        return best;
    }

    private AccessibilityNodeInfo findSendButton(AccessibilityNodeInfo root) {
        AccessibilityNodeInfo n = findBottomTextExact(root, "发送");
        if (n != null) return n;
        n = findBottomTextContains(root, "发送");
        if (n != null) return clickableAncestor(n) != null ? clickableAncestor(n) : n;
        String[] ids = {"send_btn", "btn_send", "sendbtn", "fun_btn", "send"};
        for (String id : ids) {
            n = findByViewId(root, id);
            if (n != null) return n;
        }
        return null;
    }

    private void tapPoint(int x, int y) {
        if (Build.VERSION.SDK_INT < 24) return;
        android.graphics.Path path = new android.graphics.Path();
        path.moveTo(x, y);
        GestureDescription.StrokeDescription stroke =
                new GestureDescription.StrokeDescription(path, 0, 40);
        GestureDescription.Builder builder = new GestureDescription.Builder();
        builder.addStroke(stroke);
        dispatchGesture(builder.build(), null, null);
    }

    private AccessibilityNodeInfo findBottomTextExact(AccessibilityNodeInfo node, String text) {
        if (node == null) return null;
        CharSequence t = node.getText();
        CharSequence d = node.getContentDescription();
        boolean match = (t != null && text.contentEquals(t))
                || (d != null && text.contentEquals(d));
        if (!node.isEditable() && match) {
            android.graphics.Rect r = new android.graphics.Rect();
            node.getBoundsInScreen(r);
            if (r.top > getResources().getDisplayMetrics().heightPixels / 2) {
                AccessibilityNodeInfo c = clickableAncestor(node);
                return c != null ? c : node;
            }
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo hit = findBottomTextExact(node.getChild(i), text);
            if (hit != null) return hit;
        }
        return null;
    }

    private AccessibilityNodeInfo findBottomTextContains(AccessibilityNodeInfo node, String text) {
        if (node == null) return null;
        CharSequence t = node.getText();
        CharSequence d = node.getContentDescription();
        boolean matched = (t != null && t.toString().contains(text))
                || (d != null && d.toString().contains(text));
        if (!node.isEditable() && matched) {
            android.graphics.Rect r = new android.graphics.Rect();
            node.getBoundsInScreen(r);
            if (r.top > getResources().getDisplayMetrics().heightPixels / 2) return node;
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo hit = findBottomTextContains(node.getChild(i), text);
            if (hit != null) return hit;
        }
        return null;
    }

    private AccessibilityNodeInfo findByViewId(AccessibilityNodeInfo node, String key) {
        if (node == null) return null;
        String id = node.getViewIdResourceName();
        if (id != null && id.toLowerCase().contains(key)) {
            AccessibilityNodeInfo c = clickableAncestor(node);
            return c != null ? c : node;
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo hit = findByViewId(node.getChild(i), key);
            if (hit != null) return hit;
        }
        return null;
    }

    private AccessibilityNodeInfo findSearchResult(AccessibilityNodeInfo node, String name) {
        AccessibilityNodeInfo exact = findExactResult(node, name);
        if (exact != null && hasClickableParent(exact)) return exact;
        AccessibilityNodeInfo starts = findStartsWithResult(node, name);
        return (starts != null && hasClickableParent(starts)) ? starts : null;
    }

    private AccessibilityNodeInfo findStartsWithResult(AccessibilityNodeInfo node, String name) {
        if (node == null || node.isEditable()) return null;
        CharSequence t = node.getText();
        if (t != null && t.toString().trim().startsWith(name)) return node;
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo hit = findStartsWithResult(node.getChild(i), name);
            if (hit != null) return hit;
        }
        return null;
    }

    private boolean hasClickableParent(AccessibilityNodeInfo node) {
        AccessibilityNodeInfo n = node;
        for (int i = 0; i < 5 && n != null; i++) {
            if (n.isClickable()) return true;
            n = n.getParent();
        }
        return false;
    }

    private AccessibilityNodeInfo findExactResult(AccessibilityNodeInfo node, String name) {
        if (node == null || node.isEditable()) return null;
        CharSequence t = node.getText();
        if (t != null && t.toString().trim().equals(name)) return node;
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo hit = findExactResult(node.getChild(i), name);
            if (hit != null) return hit;
        }
        return null;
    }

    private AccessibilityNodeInfo findContainsResult(AccessibilityNodeInfo node, String name) {
        if (node == null || node.isEditable()) return null;
        CharSequence t = node.getText();
        if (t != null && t.toString().contains(name)) return node;
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo hit = findContainsResult(node.getChild(i), name);
            if (hit != null) return hit;
        }
        return null;
    }

    private boolean clickNodeOrParent(AccessibilityNodeInfo node) {
        AccessibilityNodeInfo n = node;
        for (int i = 0; i < 5 && n != null; i++) {
            if (n.isClickable()) {
                return n.performAction(AccessibilityNodeInfo.ACTION_CLICK);
            }
            n = n.getParent();
        }
        return node.performAction(AccessibilityNodeInfo.ACTION_CLICK);
    }

    private AccessibilityNodeInfo findSearchEntry(AccessibilityNodeInfo node) {
        if (node == null) return null;
        String id = node.getViewIdResourceName();
        CharSequence t = node.getText();
        CharSequence d = node.getContentDescription();
        android.graphics.Rect r = new android.graphics.Rect();
        node.getBoundsInScreen(r);
        int topLimit = getResources().getDisplayMetrics().heightPixels / 3;
        if (r.top <= topLimit) {
            if (id != null && id.toLowerCase().contains("search")) return node;
            if (t != null && (t.toString().contains("搜索") || t.toString().contains("Search"))) return node;
            if (d != null && (d.toString().contains("搜索") || d.toString().contains("Search"))) return node;
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo hit = findSearchEntry(node.getChild(i));
            if (hit != null) return hit;
        }
        return null;
    }

    private AccessibilityNodeInfo findTextContains(AccessibilityNodeInfo node, String text) {
        if (node == null) return null;
        if (!node.isEditable()) {
            CharSequence t = node.getText();
            if (t != null && t.toString().contains(text)) return node;
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo r = findTextContains(node.getChild(i), text);
            if (r != null) return r;
        }
        return null;
    }

    private AccessibilityNodeInfo findEditable(AccessibilityNodeInfo node) {
        if (node == null) return null;
        if (node.isEditable()) return node;
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            AccessibilityNodeInfo r = findEditable(child);
            if (r != null) return r;
        }
        return null;
    }

    private AccessibilityNodeInfo findText(AccessibilityNodeInfo node, String text) {
        if (node == null) return null;
        CharSequence t = node.getText();
        CharSequence d = node.getContentDescription();
        if ((t != null && text.contentEquals(t)) || (d != null && text.contentEquals(d))) return node;
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo r = findText(node.getChild(i), text);
            if (r != null) return r;
        }
        return null;
    }
}
