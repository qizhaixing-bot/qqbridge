package com.example.qqbridge;

import android.content.Context;
import android.content.SharedPreferences;

public final class Config {
    private static final String PREFS = "qqbridge";
    public static final String DEFAULT_URL = "http://127.0.0.1:3099/phone/chat";
    public static final String DEFAULT_CONTACT = "星七宅";
    public static final String DEFAULT_UIN = "1519912110";

    private Config() {}

    private static SharedPreferences p(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public static String url(Context c) {
        return p(c).getString("url", DEFAULT_URL);
    }
    public static String secret(Context c) {
        return p(c).getString("secret", "");
    }
    public static String contact(Context c) {
        return p(c).getString("contact", DEFAULT_CONTACT);
    }
    public static String uin(Context c) {
        return p(c).getString("uin", DEFAULT_UIN);
    }

    public static void save(Context c, String url, String secret, String contact, String uin) {
        p(c).edit()
                .putString("url", url.trim())
                .putString("secret", secret.trim())
                .putString("contact", contact.trim())
                .putString("uin", uin.trim())
                .apply();
    }
}
