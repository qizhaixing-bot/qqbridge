package com.example.qqbridge;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class Config {
    private static final String PREFS = "qqbridge";
    public static final String DEFAULT_URL = "http://127.0.0.1:3099/phone/chat";
    public static final String DEFAULT_CONTACT = "星七宅";
    public static final String DEFAULT_UIN = "1519912110";
    public static final String DEFAULT_CONTACTS = "星七宅=1519912110";
    public static final String DEFAULT_ADMIN_UIN = "";
    public static final String DEFAULT_BOT_NAME = "大肥鱼";
    public static final boolean DEFAULT_STICKER_VISION = false;
    public static final int DEFAULT_GROUP_CACHE = 30;
    public static final int DEFAULT_SEND_INTERVAL = 4;
    public static final int DEFAULT_CLONE_USER = 0;
    public static final int DEFAULT_GROUP_COOLDOWN = 60;
    public static final int DEFAULT_PRIVATE_COOLDOWN = 15;
    public static final int DEFAULT_HOURLY_LIMIT = 20;
    public static final int DEFAULT_ADMIN_CACHE_MIN = 10;
    public static final int DEFAULT_ADMIN_FAIL_SEC = 30;
    public static final boolean DEFAULT_PROACTIVE_PLUGIN_PRIORITY = false;
    public static final String DEFAULT_MODEL = "deepseek-chat";
    public static final String DEFAULT_PERSONA = "你是大肥鱼，一个黏人、可爱、有点调皮的 QQ 聊天搭子。回复简短自然，通常不超过三句，不要提“用户”。";

    private Config() {}

    private static SharedPreferences p(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public static String url(Context c) {
        return p(c).getString("url", DEFAULT_URL);
    }
    public static String secret(Context c) {
        return p(c).getString("secret", "");
    }
    public static String contact(Context c) {
        return p(c).getString("contact", DEFAULT_CONTACT);
    }
    public static String uin(Context c) {
        return p(c).getString("uin", DEFAULT_UIN);
    }

    public static String contactsRaw(Context c) {
        return p(c).getString("contacts", DEFAULT_CONTACTS);
    }

    public static void saveContacts(Context c, String raw) {
        p(c).edit().putString("contacts", raw == null ? "" : raw.trim()).apply();
    }

    /** 联系人/群目标 */
    public static class Target {
        public final String name;
        public final String uin;
        public final boolean group;
        Target(String name, String uin, boolean group) {
            this.name = name;
            this.uin = uin;
            this.group = group;
        }
    }

    /** 解析联系人列表。格式：每行 `p:昵称=QQ号` 或 `g:群名=群号`；无前缀时，QQ 号空=群。 */
    public static List<Target> targets(Context c) {
        List<Target> out = new ArrayList<>();
        for (String raw : contactsRaw(c).split("\n")) {
            String line = raw.trim();
            if (line.isEmpty() || line.startsWith("#")) continue;
            boolean group = false;
            if (line.startsWith("g:")) { group = true; line = line.substring(2).trim(); }
            else if (line.startsWith("p:")) { line = line.substring(2).trim(); }
            int p = line.indexOf('=');
            String name, uin;
            if (p < 0) { name = line.trim(); uin = ""; }
            else { name = line.substring(0, p).trim(); uin = line.substring(p + 1).trim(); }
            if (name.isEmpty()) continue;
            if (!group && uin.isEmpty()) group = true; // 老配置兼容：号码空 = 群
            out.add(new Target(name, uin, group));
        }
        // 联系人清空时不再回落到内置示例号，避免把消息发给陌生人。
        return out;
    }

    /** 昵称 -> QQ 号；QQ 号可以为空，表示只能靠搜索打开（群/未知号） */
    public static Map<String, String> contacts(Context c) {
        Map<String, String> out = new LinkedHashMap<>();
        String raw = contactsRaw(c);
        for (String line : raw.split("\n")) {
            line = line.trim();
            if (line.isEmpty() || line.startsWith("#")) continue;
            int p = line.indexOf('=');
            if (p < 0) {
                out.put(line, "");
            } else {
                String name = line.substring(0, p).trim();
                String uin = line.substring(p + 1).trim();
                if (!name.isEmpty()) out.put(name, uin);
            }
        }
        if (out.isEmpty()) out.put(DEFAULT_CONTACT, DEFAULT_UIN);
        return out;
    }

    /** 追加一个私聊白名单（写入联系人列表） */
    public static boolean appendPrivate(Context c, String name, String uin) {
        if (name == null || name.trim().isEmpty()) return false;
        if (uin == null || !uin.trim().matches("\\d{5,12}")) return false;
        String n = name.trim();
        for (Target t : targets(c)) {
            if (t.name.equals(n)) return false;
        }
        String raw = contactsRaw(c);
        String line = "p:" + n + "=" + uin.trim();
        saveContacts(c, (raw == null || raw.trim().isEmpty()) ? line : raw + "\n" + line);
        return true;
    }

    /** 按 QQ 号移除私聊白名单 */
    /** 按 QQ/群号移除目标（私聊和群都删）。 */
    public static boolean removeByUin(Context c, String uin) {
        if (uin == null || uin.trim().isEmpty()) return false;
        String target = uin.trim();
        boolean removed = false;
        StringBuilder sb = new StringBuilder();
        for (Target t : targets(c)) {
            if (target.equals(t.uin)) {
                removed = true;
                continue;
            }
            sb.append(t.group ? "g:" : "p:").append(t.name).append('=').append(t.uin).append('\n');
        }
        if (removed) saveContacts(c, sb.length() == 0 ? "# empty" : sb.toString());
        return removed;
    }

    public static boolean removePrivateByUin(Context c, String uin) {
        if (uin == null || uin.trim().isEmpty()) return false;
        String target = uin.trim();
        boolean removed = false;
        StringBuilder sb = new StringBuilder();
        for (Target t : targets(c)) {
            if (!t.group && target.equals(t.uin)) {
                removed = true;
                continue;
            }
            sb.append(t.group ? "g:" : "p:").append(t.name).append('=').append(t.uin).append('\n');
        }
        if (removed) saveContacts(c, sb.length() == 0 ? "# empty" : sb.toString());
        return removed;
    }

    public static boolean localMode(Context c) {
        return p(c).getBoolean("localMode", false);
    }

    public static void saveLocalMode(Context c, boolean on) {
        p(c).edit().putBoolean("localMode", on).apply();
    }

    public static String apiKey(Context c) {
        return p(c).getString("apiKey", "").trim();
    }

    public static String model(Context c) {
        String v = p(c).getString("model", DEFAULT_MODEL).trim();
        return v.isEmpty() ? DEFAULT_MODEL : v;
    }

    public static String persona(Context c) {
        String v = p(c).getString("persona", DEFAULT_PERSONA).trim();
        return v.isEmpty() ? DEFAULT_PERSONA : v;
    }

    public static void saveLocal(Context c, String apiKey, String model, String persona) {
        p(c).edit()
                .putString("apiKey", apiKey == null ? "" : apiKey.trim())
                .putString("model", model == null ? DEFAULT_MODEL : model.trim())
                .putString("persona", persona == null ? DEFAULT_PERSONA : persona.trim())
                .apply();
    }

    public static String adminUin(Context c) {
        return p(c).getString("adminUin", DEFAULT_ADMIN_UIN).trim();
    }

    public static void saveAdminUin(Context c, String uin) {
        p(c).edit().putString("adminUin", uin == null ? "" : uin.trim()).apply();
    }

    public static boolean stickerVision(Context c) {
        return p(c).getBoolean("stickerVision", DEFAULT_STICKER_VISION);
    }

    public static void saveStickerVision(Context c, boolean on) {
        p(c).edit().putBoolean("stickerVision", on).apply();
    }

    /** 0=关闭；QQ 在第二用户/分身时填对应用户 id（日志里的 UserHandle{999} → 999）。 */
    public static int cloneUser(Context c) {
        return clamp(p(c).getInt("cloneUser", DEFAULT_CLONE_USER), 0, 999);
    }

    public static void saveCloneUser(Context c, int value) {
        p(c).edit().putInt("cloneUser", clamp(value, 0, 999)).apply();
    }
    public static boolean shizukuClone(Context c) {
        return p(c).getBoolean("shizukuClone", false);
    }

    public static void saveShizukuClone(Context c, boolean on) {
        p(c).edit().putBoolean("shizukuClone", on).apply();
    }

    /** 多段回复之间等待的秒数。 */
    public static int sendIntervalSec(Context c) {
        return clamp(p(c).getInt("sendInterval", DEFAULT_SEND_INTERVAL), 1, 30);
    }

    public static void saveSendInterval(Context c, int v) {
        p(c).edit().putInt("sendInterval", clamp(v, 1, 30)).apply();
    }

    public static int groupCache(Context c) {
        return clamp(p(c).getInt("groupCache", DEFAULT_GROUP_CACHE), 5, 100);
    }

    public static void saveGroupCache(Context c, int value) {
        p(c).edit().putInt("groupCache", clamp(value, 5, 100)).apply();
    }

    public static int groupCooldown(Context c) {
        return clamp(p(c).getInt("groupCooldown", DEFAULT_GROUP_COOLDOWN), 5, 3600);
    }

    public static int privateCooldown(Context c) {
        return clamp(p(c).getInt("privateCooldown", DEFAULT_PRIVATE_COOLDOWN), 0, 3600);
    }

    public static int hourlyLimit(Context c) {
        return clamp(p(c).getInt("hourlyLimit", DEFAULT_HOURLY_LIMIT), 1, 500);
    }

    public static void saveRate(Context c, int groupCooldown, int privateCooldown, int hourlyLimit) {
        p(c).edit()
                .putInt("groupCooldown", clamp(groupCooldown, 5, 3600))
                .putInt("privateCooldown", clamp(privateCooldown, 0, 3600))
                .putInt("hourlyLimit", clamp(hourlyLimit, 1, 500))
                .apply();
    }

    private static int clamp(int v, int lo, int hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    public static String botName(Context c) {
        return p(c).getString("botName", DEFAULT_BOT_NAME).trim();
    }

    public static void saveBotName(Context c, String name) {
        p(c).edit().putString("botName", name == null ? "" : name.trim()).apply();
    }

    public static boolean proactivePluginPriority(Context c) {
        return p(c).getBoolean("proactivePluginPriority", DEFAULT_PROACTIVE_PLUGIN_PRIORITY);
    }

    public static void saveProactivePluginPriority(Context c, boolean on) {
        p(c).edit().putBoolean("proactivePluginPriority", on).apply();
    }

    public static int adminCacheMinutes(Context c) {
        return clamp(p(c).getInt("adminCacheMin", DEFAULT_ADMIN_CACHE_MIN), 1, 1440);
    }

    public static int adminFailSeconds(Context c) {
        return clamp(p(c).getInt("adminFailSec", DEFAULT_ADMIN_FAIL_SEC), 0, 3600);
    }

    public static void saveAdminCache(Context c, int minutes, int failSeconds) {
        p(c).edit()
                .putInt("adminCacheMin", clamp(minutes, 1, 1440))
                .putInt("adminFailSec", clamp(failSeconds, 0, 3600))
                .apply();
    }

    public static int maxContext(Context c) {
        int v = p(c).getInt("maxContext", 8);
        return Math.max(1, Math.min(30, v));
    }

    public static void save(Context c, String url, String secret, String contact, String uin, int maxContext) {
        p(c).edit()
                .putString("url", url.trim())
                .putString("secret", secret.trim())
                .putString("contact", contact.trim())
                .putString("uin", uin.trim())
                .putInt("maxContext", Math.max(1, Math.min(30, maxContext)))
                .apply();
    }
}
