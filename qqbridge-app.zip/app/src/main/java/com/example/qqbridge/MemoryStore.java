package com.example.qqbridge;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * 本地长期记忆 + 统计。
 *
 * - 管理员私聊：自动保留全部消息（最多 200 条），不需要“记住”前缀。
 * - 群聊：滚动缓存最近 N 条（可配置），满了顶掉最老的一条；被 @ 时用这批缓存回答。
 * - 其他私聊：只更新档案/统计，不保留长期消息。
 *
 * 所有数据只存本机 SharedPreferences。
 */
public final class MemoryStore {
    private static final String PREFS = "qqbridge_memory";
    private static final int MAX_ADMIN = 200;
    private static final int MEMORY_LINES = 20;
    private static final int MAX_FACTS = 20;

    private MemoryStore() {}

    private static SharedPreferences p(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    private static String key(String contact) { return "m_" + contact; }
    private static String adminKey(String contact) { return "a_" + contact; }
    private static String groupKey(String contact) { return "g_" + contact; }

    private static String day() {
        return new SimpleDateFormat("yyyyMMdd", Locale.US).format(new Date());
    }

    private static JSONObject load(Context c, String contact) {
        try { return new JSONObject(p(c).getString(key(contact), "{}")); }
        catch (Exception e) { return new JSONObject(); }
    }

    private static void save(Context c, String contact, JSONObject o) {
        p(c).edit().putString(key(contact), o.toString()).apply();
    }

    private static JSONArray loadArray(Context c, String k) {
        try { return new JSONArray(p(c).getString(k, "[]")); }
        catch (Exception e) { return new JSONArray(); }
    }

    private static void saveArray(Context c, String k, JSONArray a) {
        p(c).edit().putString(k, a.toString()).apply();
    }

    /** 收到消息：只更新档案与统计，不改长期消息。 */
    public static synchronized void observe(Context c, String contact, String uin,
                                            boolean group, String nickname) {
        if (contact == null || contact.trim().isEmpty()) return;
        JSONObject o = load(c, contact);
        try {
            String nick = nickname == null ? "" : nickname.trim();
            if (!nick.isEmpty()) o.put("nickname", nick);
            if (uin != null && !uin.trim().isEmpty()) o.put("uin", uin.trim());
            o.put("group", group);
            long now = System.currentTimeMillis();
            if (!o.has("first")) o.put("first", now);
            o.put("last", now);
            String today = day();
            if (!today.equals(o.optString("day"))) {
                o.put("day", today);
                o.put("recvToday", 0);
                o.put("sentToday", 0);
            }
            o.put("recv", o.optInt("recv", 0) + 1);
            o.put("recvToday", o.optInt("recvToday", 0) + 1);
            save(c, contact, o);
        } catch (Exception ignored) {}
    }

    /** 管理员私聊：自动追加一条长期记忆。 */
    public static synchronized void appendAdmin(Context c, String contact, String sender, String text) {
        if (contact == null || contact.isEmpty() || text == null || text.trim().isEmpty()) return;
        JSONArray a = loadArray(c, adminKey(contact));
        try {
            JSONObject m = new JSONObject();
            m.put("s", sender == null ? "" : sender);
            m.put("t", text.trim());
            m.put("ts", System.currentTimeMillis());
            a.put(m);
            while (a.length() > MAX_ADMIN) a.remove(0);
            saveArray(c, adminKey(contact), a);
        } catch (Exception ignored) {}
    }

    /** 群聊：滚动缓存，满了顶掉最老一条。 */
    public static synchronized void appendGroup(Context c, String contact, String sender,
                                                String text, int max) {
        if (contact == null || contact.isEmpty() || text == null || text.trim().isEmpty()) return;
        int limit = Math.max(5, Math.min(100, max));
        JSONArray a = loadArray(c, groupKey(contact));
        try {
            JSONObject m = new JSONObject();
            m.put("s", sender == null ? "" : sender);
            m.put("t", text.trim());
            m.put("ts", System.currentTimeMillis());
            a.put(m);
            while (a.length() > limit) a.remove(0);
            saveArray(c, groupKey(contact), a);
        } catch (Exception ignored) {}
    }

    public static synchronized void markSent(Context c, String contact) {
        JSONObject o = load(c, contact);
        try {
            String today = day();
            if (!today.equals(o.optString("day"))) {
                o.put("day", today);
                o.put("recvToday", 0);
                o.put("sentToday", 0);
            }
            o.put("sent", o.optInt("sent", 0) + 1);
            o.put("sentToday", o.optInt("sentToday", 0) + 1);
            o.put("last", System.currentTimeMillis());
            save(c, contact, o);
        } catch (Exception ignored) {}
    }

    public static synchronized void setProfile(Context c, String contact, String nickname, String uin) {
        if (contact == null || contact.trim().isEmpty()) return;
        JSONObject o = load(c, contact);
        try {
            if (nickname != null && !nickname.trim().isEmpty()) o.put("nickname", nickname.trim());
            if (uin != null && !uin.trim().isEmpty()) o.put("uin", uin.trim());
            o.put("last", System.currentTimeMillis());
            save(c, contact, o);
        } catch (Exception ignored) {}
    }

    public static synchronized void addFact(Context c, String contact, String fact) {
        if (fact == null || fact.trim().isEmpty()) return;
        JSONObject o = load(c, contact);
        try {
            JSONArray facts = o.optJSONArray("facts");
            if (facts == null) facts = new JSONArray();
            List<String> list = new ArrayList<>();
            for (int i = 0; i < facts.length(); i++) list.add(facts.optString(i));
            if (!list.contains(fact.trim())) list.add(fact.trim());
            while (list.size() > MAX_FACTS) list.remove(0);
            JSONArray out = new JSONArray();
            for (String s : list) out.put(s);
            o.put("facts", out);
            save(c, contact, o);
        } catch (Exception ignored) {}
    }

    private static String profileLine(JSONObject o) {
        StringBuilder sb = new StringBuilder("【本地记忆】");
        String nick = o.optString("nickname", "");
        String uin = o.optString("uin", "");
        boolean group = o.optBoolean("group", false);
        if (!nick.isEmpty()) sb.append("昵称/群名：").append(nick).append("；");
        if (!uin.isEmpty()) sb.append(group ? "群号：" : "QQ：").append(uin).append("；");
        sb.append(group ? "类型：群聊；" : "类型：私聊；");
        long first = o.optLong("first", 0);
        long last = o.optLong("last", 0);
        if (first > 0) sb.append("首次：").append(fmt(first)).append("；");
        if (last > 0) sb.append("最近：").append(fmt(last)).append("；");
        sb.append("累计收 ").append(o.optInt("recv", 0))
                .append(" 条、回 ").append(o.optInt("sent", 0)).append(" 条；");
        return sb.toString();
    }

    /** 管理员长期记忆：档案 + 最近 20 条 + 事实。 */
    public static String adminMemoryText(Context c, String contact) {
        JSONObject o = load(c, contact);
        if (o.length() == 0) return "";
        StringBuilder sb = new StringBuilder(profileLine(o));
        JSONArray a = loadArray(c, adminKey(contact));
        if (a.length() > 0) {
            sb.append("\n最近消息（管理员私聊，共 ").append(a.length()).append(" 条）：");
            int from = Math.max(0, a.length() - MEMORY_LINES);
            for (int i = from; i < a.length(); i++) {
                JSONObject m = a.optJSONObject(i);
                if (m == null) continue;
                sb.append("\n").append(m.optString("s", "我")).append("：")
                        .append(m.optString("t", ""));
            }
        }
        JSONArray facts = o.optJSONArray("facts");
        if (facts != null && facts.length() > 0) {
            sb.append("\n已知信息：");
            for (int i = 0; i < facts.length(); i++) {
                if (i > 0) sb.append("；");
                sb.append(facts.optString(i));
            }
        }
        return cap(sb.toString(), 480);
    }

    /** 群聊摘要：参与者 + 条数 + 时间跨度。 */
    public static String groupSummaryText(Context c, String contact) {
        JSONObject o = load(c, contact);
        JSONArray a = loadArray(c, groupKey(contact));
        if (o.length() == 0 && a.length() == 0) return "";
        StringBuilder sb = new StringBuilder(profileLine(o));
        sb.append("\n群聊滚动缓存：").append(a.length()).append(" 条");
        Set<String> people = new LinkedHashSet<>();
        for (int i = 0; i < a.length(); i++) {
            JSONObject m = a.optJSONObject(i);
            if (m != null) {
                String s = m.optString("s", "");
                if (!s.isEmpty()) people.add(s);
            }
        }
        if (!people.isEmpty()) sb.append("；参与者：").append(join(people));
        if (a.length() > 0) {
            long t0 = a.optJSONObject(0) == null ? 0 : a.optJSONObject(0).optLong("ts", 0);
            long t1 = a.optJSONObject(a.length() - 1) == null ? 0
                    : a.optJSONObject(a.length() - 1).optLong("ts", 0);
            if (t0 > 0 && t1 > 0) sb.append("；时间：").append(fmt(t0)).append(" ~ ").append(fmt(t1));
        }
        sb.append("。");
        return sb.toString();
    }

    /** 群聊请求：摘要 + 最近 19 条原文；更早的合并进摘要，保证手机桥 20 条上限内仍覆盖全部缓存。 */
    public static JSONArray groupPayload(Context c, String contact, JSONArray fallback) {
        JSONArray out = new JSONArray();
        JSONArray a = loadArray(c, groupKey(contact));
        if (a.length() == 0) {
            copy(out, fallback);
            return out;
        }
        final int keep = 19;
        int older = Math.max(0, a.length() - keep);
        StringBuilder sb = new StringBuilder(groupSummaryText(c, contact));
        if (older > 0) {
            sb.append("\n更早 ").append(older).append(" 条：");
            for (int i = 0; i < older; i++) {
                JSONObject m = a.optJSONObject(i);
                if (m == null) continue;
                if (sb.length() > 300) { sb.append("…"); break; }
                sb.append(m.optString("s", "")).append("说「")
                        .append(m.optString("t", "")).append("」；");
            }
        }
        try {
            JSONObject m = new JSONObject();
            m.put("role", "user");
            m.put("name", "群聊缓存摘要");
            m.put("text", cap(sb.toString(), 480));
            out.put(m);
        } catch (Exception ignored) {}

        for (int i = older; i < a.length(); i++) {
            JSONObject src = a.optJSONObject(i);
            if (src == null) continue;
            try {
                JSONObject m = new JSONObject();
                m.put("role", "user");
                m.put("name", src.optString("s", "群友"));
                m.put("text", src.optString("t", ""));
                out.put(m);
            } catch (Exception ignored) {}
        }
        return out;
    }

    /** 管理员请求：长期记忆 + 当前短期对话。 */
    public static JSONArray adminPayload(Context c, String contact, JSONArray history) {
        JSONArray out = new JSONArray();
        String mem = adminMemoryText(c, contact);
        if (!mem.isEmpty()) {
            try {
                JSONObject m = new JSONObject();
                m.put("role", "user");
                m.put("name", "长期记忆");
                m.put("text", mem);
                out.put(m);
            } catch (Exception ignored) {}
        }
        copy(out, history);
        return out;
    }

    private static void copy(JSONArray out, JSONArray src) {
        if (src == null) return;
        for (int i = 0; i < src.length(); i++) {
            try { out.put(src.get(i)); } catch (Exception ignored) {}
        }
    }

    public static String summary(Context c) {
        int contacts = 0, recvToday = 0, sentToday = 0, recv = 0, sent = 0;
        for (Map.Entry<String, ?> e : p(c).getAll().entrySet()) {
            if (!e.getKey().startsWith("m_")) continue;
            try {
                JSONObject o = new JSONObject(String.valueOf(e.getValue()));
                contacts++;
                recvToday += o.optInt("recvToday", 0);
                sentToday += o.optInt("sentToday", 0);
                recv += o.optInt("recv", 0);
                sent += o.optInt("sent", 0);
            } catch (Exception ignored) {}
        }
        return "记忆联系人 " + contacts + " 个 · 今日收 " + recvToday + " / 回 " + sentToday
                + " · 累计收 " + recv + " / 回 " + sent;
    }

    public static String dump(Context c) {
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<String, ?> e : p(c).getAll().entrySet()) {
            if (!e.getKey().startsWith("m_")) continue;
            String contact = e.getKey().substring(2);
            JSONObject o = load(c, contact);
            sb.append(profileLine(o)).append("\n");
            JSONArray a = loadArray(c, adminKey(contact));
            if (a.length() > 0) sb.append("  管理员长期记忆：").append(a.length()).append(" 条\n");
            JSONArray g = loadArray(c, groupKey(contact));
            if (g.length() > 0) sb.append("  群聊缓存：").append(g.length()).append(" 条\n");
        }
        return sb.length() == 0 ? "还没有本地记忆" : sb.toString();
    }

    public static synchronized void clear(Context c) {
        p(c).edit().clear().apply();
    }

    private static String join(Set<String> set) {
        StringBuilder sb = new StringBuilder();
        for (String s : set) {
            if (sb.length() > 0) sb.append("、");
            sb.append(s);
        }
        return sb.toString();
    }

    private static String cap(String s, int max) {
        if (s == null) return "";
        return s.length() <= max ? s : s.substring(0, max) + "…";
    }

    private static String fmt(long ms) {
        return new SimpleDateFormat("MM-dd HH:mm", Locale.getDefault()).format(new Date(ms));
    }
}
