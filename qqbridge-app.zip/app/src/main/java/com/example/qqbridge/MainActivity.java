package com.example.qqbridge;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.Settings;
import android.text.InputType;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private EditText url, secret, adminUin, botName, maxContext, groupCache;
    private Switch proactivePluginPriority;
    private LinearLayout contactList;
    private final List<Row> contactRows = new ArrayList<>();
    private TextView status, permStatus, logView;

    private static class Row {
        final EditText name, uin;
        final Button type;
        Row(EditText name, EditText uin, Button type) {
            this.name = name; this.uin = uin; this.type = type;
        }
        boolean isGroup() { return "群聊".equals(type.getText().toString()); }
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        ScrollView scroll = new ScrollView(this);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16), dp(16), dp(16), dp(32));
        scroll.addView(box);
        setContentView(scroll);

        TextView title = new TextView(this);
        title.setText("QQBridge 精简版");
        title.setTextSize(22);
        box.addView(title);

        status = new TextView(this);
        status.setTextSize(12);
        status.setPadding(0, dp(4), 0, dp(6));
        status.setText("就绪");
        box.addView(status);

        permStatus = new TextView(this);
        permStatus.setTextSize(12);
        permStatus.setPadding(0, dp(2), 0, dp(8));
        box.addView(permStatus);

        url = addInput(box, "手机桥地址", Config.url(this));
        secret = addInput(box, "phoneBridgeSecret", Config.secret(this));

        TextView cLabel = new TextView(this);
        cLabel.setText("\n支持的私聊/群聊");
        cLabel.setTextSize(12);
        box.addView(cLabel);

        contactList = new LinearLayout(this);
        contactList.setOrientation(LinearLayout.VERTICAL);
        box.addView(contactList);
        for (Config.Target t : Config.targets(this)) addContactRow(t.name, t.uin, t.group);
        if (contactRows.isEmpty()) addContactRow("", "", false);

        Button addRow = new Button(this);
        addRow.setText("+ 添加一行");
        addRow.setOnClickListener(v -> addContactRow("", "", false));
        box.addView(addRow);

        adminUin = addInput(box, "管理员 QQ 号（长期记忆/身份识别）", Config.adminUin(this));
        adminUin.setInputType(InputType.TYPE_CLASS_NUMBER);
        botName = addInput(box, "机器人昵称（群 @ 识别）", Config.botName(this));
        maxContext = addInput(box, "私聊上下文/长期记忆条数（1–30）",
                String.valueOf(Config.maxContext(this)));
        maxContext.setInputType(InputType.TYPE_CLASS_NUMBER);
        groupCache = addInput(box, "群消息缓存条数（5–100，满了顶最老的）",
                String.valueOf(Config.groupCache(this)));
        groupCache.setInputType(InputType.TYPE_CLASS_NUMBER);

        proactivePluginPriority = new Switch(this);
        proactivePluginPriority.setText("主动消息：插件优先（跳过 App 限流）");
        proactivePluginPriority.setChecked(Config.proactivePluginPriority(this));
        box.addView(proactivePluginPriority);

        Button save = new Button(this);
        save.setText("保存配置");
        save.setOnClickListener(v -> save());
        box.addView(save);

        Button notify = new Button(this);
        notify.setText("开启通知使用权");
        notify.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)));
        box.addView(notify);

        Button a11y = new Button(this);
        a11y.setText("开启无障碍");
        a11y.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        box.addView(a11y);

        Button overlay = new Button(this);
        overlay.setText("允许后台弹出界面（悬浮窗权限）");
        overlay.setOnClickListener(v -> startActivity(new Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                android.net.Uri.parse("package:" + getPackageName()))));
        box.addView(overlay);

        Button battery = new Button(this);
        battery.setText("申请忽略电池优化");
        battery.setOnClickListener(v -> {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            if (pm == null || pm.isIgnoringBatteryOptimizations(getPackageName())) {
                Toast.makeText(this, "已经无限制", Toast.LENGTH_SHORT).show();
                return;
            }
            startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                    android.net.Uri.parse("package:" + getPackageName())));
        });
        box.addView(battery);

        Button testBridge = new Button(this);
        testBridge.setText("测试手机桥");
        testBridge.setOnClickListener(v -> new Thread(() -> {
            String r = BridgeClient.chat(this, "测试", "在吗");
            runOnUiThread(() -> status.setText(r == null ? "桥没有回复，看日志" : "桥回复：" + r));
        }).start());
        box.addView(testBridge);

        Button testSend = new Button(this);
        testSend.setText("测试发送管理员消息（发一条“测试”）");
        testSend.setOnClickListener(v -> {
            String admin = Config.adminUin(this).trim();
            if (admin.isEmpty()) {
                status.setText("先填管理员 QQ 号");
                return;
            }
            String name = "";
            for (Config.Target t : Config.targets(this)) {
                if (!t.group && admin.equals(t.uin)) { name = t.name; break; }
            }
            QqAccessibilityService svc = QqAccessibilityService.get();
            if (svc == null) {
                status.setText("无障碍未连接，请先开启无障碍");
                return;
            }
            AppLog.add("test send admin " + admin);
            svc.sendReply(name, admin, "测试", false);
            status.setText("已发起给管理员发“测试”");
        });
        box.addView(testSend);

        TextView logLabel = new TextView(this);
        logLabel.setText("\n最近事件");
        logLabel.setTextSize(12);
        box.addView(logLabel);

        logView = new TextView(this);
        logView.setTextSize(11);
        logView.setText(AppLog.text());
        box.addView(logView);

        LinearLayout logBtns = new LinearLayout(this);
        Button copyLog = new Button(this);
        copyLog.setText("复制日志");
        copyLog.setOnClickListener(v -> {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("log", AppLog.text()));
            Toast.makeText(this, "已复制", Toast.LENGTH_SHORT).show();
        });
        Button saveLog = new Button(this);
        saveLog.setText("导出日志");
        saveLog.setOnClickListener(v -> status.setText("日志：" + AppLog.save(this)));
        Button dumpUi = new Button(this);
        dumpUi.setText("导出界面结构");
        dumpUi.setOnClickListener(v -> dumpUi());
        logBtns.addView(copyLog);
        logBtns.addView(saveLog);
        logBtns.addView(dumpUi);

        Button showMem = new Button(this);
        showMem.setText("查看本地记忆");
        showMem.setOnClickListener(v -> {
            logView.setText(MemoryStore.dump(this));
            status.setText("已显示本地记忆（私聊/管理员/群缓存）");
        });
        logBtns.addView(showMem);
        box.addView(logBtns);

        refreshPermissions();
    }

    private EditText addInput(LinearLayout parent, String hint, String value) {
        TextView label = new TextView(this);
        label.setText(hint);
        label.setTextSize(12);
        parent.addView(label);
        EditText e = new EditText(this);
        e.setText(value == null ? "" : value);
        e.setSingleLine(true);
        parent.addView(e);
        return e;
    }

    private void addContactRow(String nameValue, String uinValue, boolean groupValue) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);

        EditText name = new EditText(this);
        name.setHint("昵称/群名");
        name.setText(nameValue);
        name.setSingleLine(true);
        name.setLayoutParams(new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1.2f));

        EditText uin = new EditText(this);
        uin.setHint("QQ号/群号");
        uin.setText(uinValue);
        uin.setSingleLine(true);
        uin.setInputType(InputType.TYPE_CLASS_NUMBER);
        uin.setLayoutParams(new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        Button type = new Button(this);
        type.setText(groupValue ? "群聊" : "私聊");
        type.setLayoutParams(new LinearLayout.LayoutParams(dp(72), dp(44)));
        type.setOnClickListener(v -> type.setText(
                "私聊".equals(type.getText().toString()) ? "群聊" : "私聊"));

        Button del = new Button(this);
        del.setText("×");
        del.setLayoutParams(new LinearLayout.LayoutParams(dp(44), dp(44)));

        row.addView(name);
        row.addView(uin);
        row.addView(type);
        row.addView(del);
        contactList.addView(row);

        final Row entry = new Row(name, uin, type);
        contactRows.add(entry);
        del.setOnClickListener(v -> {
            contactList.removeView(row);
            contactRows.remove(entry);
        });
    }

    private void save() {
        int max = 8, cache = 30;
        try { max = Integer.parseInt(maxContext.getText().toString().trim()); } catch (Exception ignored) {}
        try { cache = Integer.parseInt(groupCache.getText().toString().trim()); } catch (Exception ignored) {}
        StringBuilder sb = new StringBuilder();
        for (Row row : contactRows) {
            String name = row.name.getText().toString().trim();
            String uin = row.uin.getText().toString().trim();
            if (name.isEmpty()) continue;
            sb.append(row.isGroup() ? "g:" : "p:").append(name).append('=').append(uin).append('\n');
        }
        Config.saveContacts(this, sb.length() == 0 ? "# empty" : sb.toString());
        if (!contactRows.isEmpty()) {
            String n = contactRows.get(0).name.getText().toString().trim();
            String u = contactRows.get(0).uin.getText().toString().trim();
            Config.save(this, url.getText().toString(), secret.getText().toString(),
                    n, u, max);
        }
        Config.saveAdminUin(this, adminUin.getText().toString());
        Config.saveBotName(this, botName.getText().toString());
        Config.saveGroupCache(this, cache);
        Config.saveProactivePluginPriority(this, proactivePluginPriority.isChecked());
        // 主空间专用：强制关闭分身/Shizuku 路径。
        Config.saveCloneUser(this, 0);
        Config.saveShizukuClone(this, false);
        Toast.makeText(this, "已保存", Toast.LENGTH_SHORT).show();
    }

    private void dumpUi() {
        QqAccessibilityService svc = QqAccessibilityService.get();
        if (svc == null) { status.setText("无障碍未连接，导不了"); return; }
        String dump = svc.dumpUi();
        try {
            java.io.File dir = getExternalFilesDir(null);
            if (dir == null) dir = getFilesDir();
            java.io.File f = new java.io.File(dir, "ui-dump.txt");
            try (java.io.FileWriter w = new java.io.FileWriter(f, false)) { w.write(dump); }
            status.setText("已导出：" + f.getAbsolutePath());
            AppLog.add("导出界面结构 " + dump.length() + " 字符");
        } catch (Exception e) {
            status.setText("导出失败：" + e);
        }
    }

    private void refreshPermissions() {
        boolean notify = Settings.Secure.getString(getContentResolver(),
                "enabled_notification_listeners") != null
                && Settings.Secure.getString(getContentResolver(),
                "enabled_notification_listeners").contains(getPackageName());
        String a = Settings.Secure.getString(getContentResolver(),
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        boolean a11y = a != null && a.contains(getPackageName());
        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        boolean battery = pm != null && pm.isIgnoringBatteryOptimizations(getPackageName());
        permStatus.setText((notify ? "✅ 通知" : "❌ 通知") + "  "
                + (a11y ? "✅ 无障碍" : "❌ 无障碍") + "  "
                + (battery ? "✅ 电池" : "❌ 电池"));
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshPermissions();
        if (logView != null) logView.setText(AppLog.text());
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
