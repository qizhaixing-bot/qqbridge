package com.example.qqbridge;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.pm.PackageManager;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.PowerManager;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private EditText url, secret, maxContext, groupCache, cloneUser, adminUin, botName;
    private Switch shizukuClone;
    private EditText groupCooldown, privateCooldown, hourlyLimit;
    private EditText codeEditor, pluginFile;
    private EditText adminCacheMin, adminFailSec;
    private Switch stickerVision;
    private LinearLayout contactList;
    private final List<Row> contactRows = new ArrayList<>();

    private static class Row {
        final EditText name;
        final EditText uin;
        final Button type;
        Row(EditText name, EditText uin, Button type) { this.name = name; this.uin = uin; this.type = type; }
        boolean isGroup() { return "群聊".equals(type.getText().toString()); }
    }
    private TextView status;
    private TextView permStatus;
    private TextView logView;
    private TextView memView;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(20), dp(20), dp(20));

        TextView title = new TextView(this);
        title.setText("QQBridge 实验版");
        title.setTextSize(22);
        title.setTextColor(Color.BLACK);
        box.addView(title);

        status = new TextView(this);
        status.setText("1. 开启通知使用权\n2. 开启无障碍\n3. 填手机桥地址和 secret\n4. 用 QQ 发消息测试");
        status.setTextSize(14);
        status.setPadding(0, dp(12), 0, dp(12));
        box.addView(status);

        permStatus = new TextView(this);
        permStatus.setTextSize(14);
        permStatus.setPadding(0, dp(4), 0, dp(8));
        box.addView(permStatus);

        url = addInput(box, "手机桥地址", Config.DEFAULT_URL);
        secret = addInput(box, "phoneBridgeSecret", Config.secret(this));

        TextView contactLabel = new TextView(this);
        contactLabel.setText("支持的私聊/群聊");
        contactLabel.setTextSize(13);
        contactLabel.setPadding(0, dp(12), 0, dp(6));
        box.addView(contactLabel);

        LinearLayout big = new LinearLayout(this);
        big.setOrientation(LinearLayout.VERTICAL);
        big.setPadding(dp(10), dp(10), dp(10), dp(10));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.rgb(245, 245, 245));
        bg.setCornerRadius(dp(8));
        bg.setStroke(dp(1), Color.LTGRAY);
        big.setBackground(bg);
        box.addView(big);

        contactList = new LinearLayout(this);
        contactList.setOrientation(LinearLayout.VERTICAL);
        big.addView(contactList);

        TextView contactHint = new TextView(this);
        contactHint.setText("每行一个：昵称/群名 + QQ号/群号 + 私聊/群聊按钮，点按钮切换类型。");
        contactHint.setTextSize(11);
        contactHint.setTextColor(Color.DKGRAY);
        big.addView(contactHint);

        Button addRow = new Button(this);
        addRow.setText("＋ 添加一行");
        addRow.setOnClickListener(v -> addContactRow("", "", false));
        big.addView(addRow);

        for (Config.Target t : Config.targets(this)) {
            addContactRow(t.name, t.uin, t.group);
        }
        if (contactRows.isEmpty()) addContactRow("", "", false);

        adminUin = addInput(box, "管理员 QQ 号（只在私聊生效）", Config.adminUin(this));
        adminUin.setInputType(InputType.TYPE_CLASS_NUMBER);

        botName = addInput(box, "机器人昵称（群 @ 识别用）", Config.botName(this));

        stickerVision = new Switch(this);
        stickerVision.setText("表情截图识别（实验，只截静态）");
        stickerVision.setChecked(Config.stickerVision(this));
        box.addView(stickerVision);

        maxContext = addInput(box, "私聊上下文条数（1–30）", String.valueOf(Config.maxContext(this)));
        maxContext.setInputType(InputType.TYPE_CLASS_NUMBER);

        groupCache = addInput(box, "群消息缓存条数（5–100，满了顶掉最老的）", String.valueOf(Config.groupCache(this)));
        groupCache.setInputType(InputType.TYPE_CLASS_NUMBER);

        cloneUser = addInput(box, "QQ 分身用户 ID（0=关闭；日志 UserHandle{999} 就填 999）",
                String.valueOf(Config.cloneUser(this)));
        cloneUser.setInputType(InputType.TYPE_CLASS_NUMBER);

        shizukuClone = new Switch(this);
        shizukuClone.setText("用 Shizuku 打开分身（免 root，需在 Shevery/Shizuku 里授权 QQBridge）");
        shizukuClone.setChecked(Config.shizukuClone(this));
        box.addView(shizukuClone);

        groupCooldown = addInput(box, "群冷却秒数（5–3600）", String.valueOf(Config.groupCooldown(this)));
        groupCooldown.setInputType(InputType.TYPE_CLASS_NUMBER);
        privateCooldown = addInput(box, "私聊冷却秒数（0–3600）", String.valueOf(Config.privateCooldown(this)));
        privateCooldown.setInputType(InputType.TYPE_CLASS_NUMBER);
        hourlyLimit = addInput(box, "每小时回复上限（1–500）", String.valueOf(Config.hourlyLimit(this)));
        hourlyLimit.setInputType(InputType.TYPE_CLASS_NUMBER);

        adminCacheMin = addInput(box, "管理员验证成功缓存（分钟，1–1440）", String.valueOf(Config.adminCacheMinutes(this)));
        adminCacheMin.setInputType(InputType.TYPE_CLASS_NUMBER);
        adminFailSec = addInput(box, "验证失败重试间隔（秒，0–3600，0=每次重试）", String.valueOf(Config.adminFailSeconds(this)));
        adminFailSec.setInputType(InputType.TYPE_CLASS_NUMBER);

        Button save = new Button(this);
        save.setText("保存配置");
        save.setOnClickListener(v -> {
            int max = 8;
            try { max = Integer.parseInt(maxContext.getText().toString().trim()); } catch (Exception ignored) {}
            int gcSize = 30;
            try { gcSize = Integer.parseInt(groupCache.getText().toString().trim()); } catch (Exception ignored) {}
            Config.saveGroupCache(this, gcSize);
            int clone = 0;
            try { clone = Integer.parseInt(cloneUser.getText().toString().trim()); } catch (Exception ignored) {}
            Config.saveCloneUser(this, clone);
            Config.saveShizukuClone(this, shizukuClone.isChecked());
            StringBuilder sb = new StringBuilder();
            for (Row row : contactRows) {
                String name = row.name.getText().toString().trim();
                String uin = row.uin.getText().toString().trim();
                if (name.isEmpty()) continue;
                sb.append(row.isGroup() ? "g:" : "p:")
                  .append(name).append('=').append(uin).append('\n');
            }
            Config.saveContacts(this, sb.length() == 0 ? "# empty" : sb.toString());
            Config.Target first = firstTarget();
            Config.save(this, url.getText().toString(), secret.getText().toString(),
                    first.name, first.uin, max);
            Config.saveAdminUin(this, adminUin.getText().toString());
            Config.saveBotName(this, botName.getText().toString());
            Config.saveStickerVision(this, stickerVision.isChecked());
            int gc = 60, pc = 15, hl = 20;
            try { gc = Integer.parseInt(groupCooldown.getText().toString().trim()); } catch (Exception ignored) {}
            try { pc = Integer.parseInt(privateCooldown.getText().toString().trim()); } catch (Exception ignored) {}
            try { hl = Integer.parseInt(hourlyLimit.getText().toString().trim()); } catch (Exception ignored) {}
            Config.saveRate(this, gc, pc, hl);
            int cm = 10, cf = 30;
            try { cm = Integer.parseInt(adminCacheMin.getText().toString().trim()); } catch (Exception ignored) {}
            try { cf = Integer.parseInt(adminFailSec.getText().toString().trim()); } catch (Exception ignored) {}
            Config.saveAdminCache(this, cm, cf);
            Toast.makeText(this, "已保存", Toast.LENGTH_SHORT).show();
        });
        box.addView(save);

        Button notify = new Button(this);
        notify.setText("开启通知使用权");
        notify.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)));
        box.addView(notify);

        Button a11y = new Button(this);
        a11y.setText("开启无障碍");
        a11y.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        box.addView(a11y);

        Button battery = new Button(this);
        battery.setText("申请忽略电池优化");
        battery.setOnClickListener(v -> {
            try {
                Intent i = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                        Uri.parse("package:" + getPackageName()));
                startActivity(i);
            } catch (Exception e) {
                startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
            }
        });
        box.addView(battery);

        Button test = new Button(this);
        test.setText("测试手机桥");
        test.setOnClickListener(v -> {
            status.setText("请求中…");
            new Thread(() -> {
                Config.Target first = firstTarget();
                String r = BridgeClient.chat(this, first.name, "测试");
                runOnUiThread(() -> status.setText(r == null ? "失败：看 logcat" : "回复：" + r));
            }).start();
        });
        box.addView(test);

        Button testOpen = new Button(this);
        testOpen.setText("测试发送管理员消息（会发一条“测试”）");
        testOpen.setOnClickListener(v -> {
            String adminUin = Config.adminUin(this);
            if (adminUin.isEmpty()) {
                status.setText("先在上面填写管理员 QQ 号");
                AppLog.add("test open: admin uin empty");
                return;
            }
            String foundName = "";
            for (Config.Target t : Config.targets(this)) {
                if (!t.group && adminUin.equals(t.uin)) { foundName = t.name; break; }
            }
            final String adminName = foundName;
            QqAccessibilityService svc = QqAccessibilityService.get();
            if (svc == null) {
                status.setText("无障碍未连接，请先开启无障碍");
                AppLog.add("test open: accessibility null");
                return;
            }
            AppLog.add("test send admin " + adminUin);
            // 真正走一遍打开→输入→发送，方便验证分身 QQ 能不能发出去。
            svc.sendReply(adminName, adminUin, "测试", false);
            status.setText("已发起给管理员发“测试”：" + adminUin);
        });
        box.addView(testOpen);

        Button shizukuPerm = new Button(this);
        shizukuPerm.setText("申请 Shizuku 权限（Shevery 授权）");
        shizukuPerm.setOnClickListener(v -> {
            status.setText("正在请求 Shizuku，若弹窗请允许 QQBridge...");
            new Thread(() -> {
                String out = ShizukuShell.run(this, "id");
                runOnUiThread(() -> {
                    AppLog.add("Shizuku 授权测试：" + out);
                    boolean ok = out.contains("uid=2000") || out.contains("uid=0");
                    status.setText(ok ? "Shizuku 已授权，可以用了"
                            : "未授权：去 Shevery → 管理应用 → 允许 QQBridge");
                });
            }).start();
        });
        box.addView(shizukuPerm);

        Button installClone = new Button(this);
        installClone.setText("安装到分身用户 999 并开无障碍");
        installClone.setOnClickListener(v -> {
            status.setText("正在安装到 999...");
            new Thread(() -> {
                String pkg = getPackageName();
                String cmd = "pm install-existing --user 999 " + pkg
                        + " && am start --user 999 -n " + pkg + "/.MainActivity"
                        + " && settings --user 999 put secure enabled_accessibility_services "
                        + pkg + "/" + pkg + ".QqAccessibilityService"
                        + " && settings --user 999 put secure accessibility_enabled 1";
                String out;
                if (Config.shizukuClone(this)) out = ShizukuShell.run(this, cmd);
                else if (RootShell.available()) out = RootShell.run(cmd);
                else out = "没有 root/Shizuku 权限";
                final String result = out;
                runOnUiThread(() -> {
                    AppLog.add("安装到分身 999：" + result);
                    status.setText(result.contains("Error") || result.contains("Exception")
                            ? "安装失败，看最近事件" : "已安装到 999；去 999 的 QQBridge 里开通知、填配置");
                });
            }).start();
        });
        box.addView(installClone);

        Button openShevery = new Button(this);
        openShevery.setText("打开 Shevery 去授权");
        openShevery.setOnClickListener(v -> {
            Intent i = getPackageManager().getLaunchIntentForPackage("com.hamondev.shevery");
            if (i != null) startActivity(i);
            else Toast.makeText(this, "没找到 Shevery", Toast.LENGTH_SHORT).show();
        });
        box.addView(openShevery);

        TextView logLabel = new TextView(this);
        logLabel.setText("\n最近事件");
        logLabel.setTextSize(12);
        box.addView(logLabel);

        logView = new TextView(this);
        logView.setTextSize(11);
        logView.setPadding(0, dp(4), 0, dp(8));
        logView.setText(AppLog.text());
        box.addView(logView);

        LinearLayout logBtns = new LinearLayout(this);
        logBtns.setOrientation(LinearLayout.HORIZONTAL);
        Button copyLog = new Button(this);
        copyLog.setText("复制日志");
        copyLog.setOnClickListener(v -> {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm != null) {
                cm.setPrimaryClip(ClipData.newPlainText("QQBridge log", AppLog.text()));
                Toast.makeText(this, "日志已复制", Toast.LENGTH_SHORT).show();
            }
        });
        Button saveLog = new Button(this);
        saveLog.setText("导出日志");
        saveLog.setOnClickListener(v -> {
            String path = AppLog.save(this);
            status.setText(path.isEmpty() ? "日志导出失败" : "日志已导出：" + path);
        });
        Button clearLog = new Button(this);
        clearLog.setText("清空日志");
        clearLog.setOnClickListener(v -> {
            AppLog.clear();
            logView.setText("");
        });
        logBtns.addView(copyLog);
        logBtns.addView(saveLog);
        logBtns.addView(clearLog);
        box.addView(logBtns);

        TextView memLabel = new TextView(this);
        memLabel.setText("\n本地记忆与统计（只存本机）");
        memLabel.setTextSize(12);
        box.addView(memLabel);

        memView = new TextView(this);
        memView.setTextSize(12);
        memView.setPadding(0, dp(4), 0, dp(8));
        memView.setText(MemoryStore.summary(this));
        box.addView(memView);

        LinearLayout memBtns = new LinearLayout(this);
        memBtns.setOrientation(LinearLayout.HORIZONTAL);
        Button showMem = new Button(this);
        showMem.setText("查看记忆");
        showMem.setOnClickListener(v -> logView.setText(MemoryStore.dump(this)));
        Button clearMem = new Button(this);
        clearMem.setText("清空记忆");
        clearMem.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle("清空本地记忆？")
                .setMessage("会删除所有联系人的昵称/QQ/统计/“记住”的内容，不可恢复。")
                .setNegativeButton("取消", null)
                .setPositiveButton("清空", (d, w) -> {
                    MemoryStore.clear(this);
                    memView.setText(MemoryStore.summary(this));
                    logView.setText("本地记忆已清空");
                }).show());
        memBtns.addView(showMem);
        memBtns.addView(clearMem);
        box.addView(memBtns);

        Button reloadPlugins = new Button(this);
        reloadPlugins.setText("重载插件");
        reloadPlugins.setOnClickListener(v -> {
            PluginManager.ensureSample(this);
            int n = PluginManager.count(this);
            status.setText("插件数：" + n + "\n目录：" + PluginManager.dir(this).getAbsolutePath());
        });
        box.addView(reloadPlugins);

        TextView codeLabel = new TextView(this);
        codeLabel.setText("\n插件代码改写（只用内置 DeepSeek 改代码，聊天仍走 DSH）");
        codeLabel.setTextSize(12);
        box.addView(codeLabel);

        pluginFile = addInput(box, "插件文件名（如 demo.js）", "demo.js");
        codeEditor = addInput(box, "当前插件代码", "");
        codeEditor.setSingleLine(false);
        codeEditor.setMinLines(6);
        codeEditor.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        Button loadPlugin = new Button(this);
        loadPlugin.setText("加载该插件代码");
        loadPlugin.setOnClickListener(v -> {
            String name = pluginFile.getText().toString().trim();
            if (!name.endsWith(".js")) name += ".js";
            try {
                File f = new File(PluginManager.dir(this), name);
                String src = new String(java.nio.file.Files.readAllBytes(f.toPath()),
                        java.nio.charset.StandardCharsets.UTF_8);
                codeEditor.setText(src);
                status.setText("已加载：" + f.getAbsolutePath());
            } catch (Exception e) {
                status.setText("加载失败：" + e.getMessage());
            }
        });
        box.addView(loadPlugin);

        Button savePlugin = new Button(this);
        savePlugin.setText("保存回该插件");
        savePlugin.setOnClickListener(v -> {
            try {
                String name = pluginFile.getText().toString().trim();
                if (!name.endsWith(".js")) name += ".js";
                File f = new File(PluginManager.dir(this), name);
                try (FileWriter w = new FileWriter(f, false)) {
                    w.write(codeEditor.getText().toString());
                }
                AppLog.add("保存插件 " + name);
                status.setText("已保存：" + f.getAbsolutePath());
            } catch (Exception e) {
                status.setText("保存失败：" + e.getMessage());
            }
        });
        box.addView(savePlugin);

        TextView hint = new TextView(this);
        hint.setText("\n提示：QQ 在后台时通知才会到达；无障碍要允许读取界面。\n日志：adb logcat -s QQBridge");
        hint.setTextSize(12);
        box.addView(hint);

        refreshPermissions();

        ScrollView scroll = new ScrollView(this);
        scroll.addView(box);
        setContentView(scroll);
        PluginManager.ensureSample(this);
        startKeepAlive();
    }

    private void startKeepAlive() {
        try {
            Intent i = new Intent(this, KeepAliveService.class);
            startForegroundService(i);
        } catch (Exception ignored) { /* ignore */ }
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1001);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshPermissions();
        if (logView != null) logView.setText(AppLog.text());
        if (memView != null) memView.setText(MemoryStore.summary(this));
    }

    private void refreshPermissions() {
        boolean notify = Settings.Secure.getString(getContentResolver(),
                "enabled_notification_listeners") != null
                && Settings.Secure.getString(getContentResolver(),
                "enabled_notification_listeners").contains(getPackageName());
        String a = Settings.Secure.getString(getContentResolver(),
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        boolean a11y = a != null && a.contains(getPackageName());
        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        boolean battery = pm != null && pm.isIgnoringBatteryOptimizations(getPackageName());
        permStatus.setText(
                (notify ? "✅ 通知使用权" : "❌ 通知使用权")
                + "   " + (a11y ? "✅ 无障碍" : "❌ 无障碍")
                + "   " + (battery ? "✅ 电池无限制" : "❌ 电池无限制"));
    }

    private Config.Target firstTarget() {
        List<Config.Target> ts = Config.targets(this);
        return ts.isEmpty()
                ? new Config.Target(Config.DEFAULT_CONTACT, Config.DEFAULT_UIN, false)
                : ts.get(0);
    }

    private void addContactRow(String nameValue, String uinValue, boolean groupValue) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, dp(4), 0, dp(4));

        EditText name = new EditText(this);
        name.setHint("昵称/群名");
        name.setText(nameValue);
        name.setSingleLine(true);
        LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1.2f);
        name.setLayoutParams(np);

        EditText uin = new EditText(this);
        uin.setHint("QQ号/群号");
        uin.setText(uinValue);
        uin.setSingleLine(true);
        uin.setInputType(InputType.TYPE_CLASS_NUMBER);
        LinearLayout.LayoutParams up = new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        uin.setLayoutParams(up);

        Button type = new Button(this);
        type.setText(groupValue ? "群聊" : "私聊");
        type.setLayoutParams(new LinearLayout.LayoutParams(dp(72), dp(44)));
        type.setOnClickListener(v -> type.setText(
                "私聊".equals(type.getText().toString()) ? "群聊" : "私聊"));

        Button del = new Button(this);
        del.setText("×");
        del.setLayoutParams(new LinearLayout.LayoutParams(dp(44), dp(44)));

        row.addView(name);
        row.addView(uin);
        row.addView(type);
        row.addView(del);
        contactList.addView(row);

        final Row entry = new Row(name, uin, type);
        contactRows.add(entry);
        del.setOnClickListener(v -> {
            contactList.removeView(row);
            contactRows.remove(entry);
        });
    }

    private EditText addInput(LinearLayout parent, String hint, String value) {
        TextView label = new TextView(this);
        label.setText(hint);
        label.setTextSize(13);
        label.setPadding(0, dp(10), 0, 0);
        parent.addView(label);

        EditText e = new EditText(this);
        e.setText(value);
        e.setSingleLine(true);
        e.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)));
        parent.addView(e);
        return e;
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }
}
