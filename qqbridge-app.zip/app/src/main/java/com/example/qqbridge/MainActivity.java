package com.example.qqbridge;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private EditText url, secret, contact, uin;
    private TextView status;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(20), dp(20), dp(20));

        TextView title = new TextView(this);
        title.setText("QQBridge 实验版");
        title.setTextSize(22);
        title.setTextColor(Color.BLACK);
        box.addView(title);

        status = new TextView(this);
        status.setText("1. 开启通知使用权\n2. 开启无障碍\n3. 填手机桥地址和 secret\n4. 用 QQ 发消息测试");
        status.setTextSize(14);
        status.setPadding(0, dp(12), 0, dp(12));
        box.addView(status);

        url = addInput(box, "手机桥地址", Config.DEFAULT_URL, false);
        secret = addInput(box, "phoneBridgeSecret", Config.secret(this), false);
        contact = addInput(box, "联系人的 QQ 昵称", Config.contact(this), false);
        uin = addInput(box, "联系人 QQ 号", Config.uin(this), false);
        uin.setInputType(InputType.TYPE_CLASS_NUMBER);

        Button save = new Button(this);
        save.setText("保存配置");
        save.setOnClickListener(v -> {
            Config.save(this, url.getText().toString(), secret.getText().toString(),
                    contact.getText().toString(), uin.getText().toString());
            Toast.makeText(this, "已保存", Toast.LENGTH_SHORT).show();
        });
        box.addView(save);

        Button notify = new Button(this);
        notify.setText("开启通知使用权");
        notify.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)));
        box.addView(notify);

        Button a11y = new Button(this);
        a11y.setText("开启无障碍");
        a11y.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        box.addView(a11y);

        Button test = new Button(this);
        test.setText("测试手机桥");
        test.setOnClickListener(v -> {
            status.setText("请求中…");
            new Thread(() -> {
                String r = BridgeClient.chat(this, contact.getText().toString(), "测试");
                runOnUiThread(() -> status.setText(r == null ? "失败：看 logcat" : "回复：" + r));
            }).start();
        });
        box.addView(test);

        TextView hint = new TextView(this);
        hint.setText("\n提示：QQ 在后台时通知才会到达；无障碍要允许读取界面。\n日志：adb logcat -s QQBridge");
        hint.setTextSize(12);
        box.addView(hint);

        ScrollView scroll = new ScrollView(this);
        scroll.addView(box);
        setContentView(scroll);
    }

    private EditText addInput(LinearLayout parent, String hint, String value, boolean password) {
        TextView label = new TextView(this);
        label.setText(hint);
        label.setTextSize(13);
        label.setPadding(0, dp(10), 0, 0);
        parent.addView(label);

        EditText e = new EditText(this);
        e.setText(value);
        e.setSingleLine(true);
        e.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)));
        if (password) e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        parent.addView(e);
        return e;
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }
}
