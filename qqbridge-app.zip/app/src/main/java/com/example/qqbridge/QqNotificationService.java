package com.example.qqbridge;

import android.app.Notification;
import android.app.PendingIntent;
import android.content.Context;
import android.os.Bundle;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** 只做两件事：私聊/群聊收消息 → 请求手机桥 → 分段发送。 */
public class QqNotificationService extends NotificationListenerService {
    private static final String TAG = "QQBridge";
    private static final String QQ = "com.tencent.mobileqq";
    private static final Pattern SENDER_RE = Pattern.compile("^([^:：\\n]{1,24})[:：]\\s*(.+)$");

    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final ArrayDeque<Task> queue = new ArrayDeque<>();
    private boolean running = false;
    private final Map<String, Long> recent = new HashMap<>();
    private final Map<String, String> lastSent = new HashMap<>();
    private static final Map<String, PendingIntent> INTENTS = new HashMap<>();
    private static PendingIntent friendIntent;

    public static PendingIntent lastIntent(String contact) {
        if (contact == null) return null;
        synchronized (INTENTS) { return INTENTS.get(contact); }
    }

    private static class Task {
        final String contact, uin, text, sender;
        final boolean group;
        final CountDownLatch done = new CountDownLatch(1);
        Task(String contact, String uin, String text, String sender, boolean group) {
            this.contact = contact; this.uin = uin; this.text = text;
            this.sender = sender; this.group = group;
        }
    }

    @Override public void onListenerConnected() {
        AppLog.add("通知监听已连接");
        PhoneActions.start(getApplicationContext());
    }

    @Override public void onNotificationPosted(StatusBarNotification sbn) {
        if (sbn == null || !QQ.equals(sbn.getPackageName())) return;
        Bundle extras = sbn.getNotification().extras;
        if (extras == null) return;
        String title = clean(String.valueOf(extras.getCharSequence(Notification.EXTRA_TITLE, "")));
        String text = String.valueOf(extras.getCharSequence(Notification.EXTRA_TEXT, "")).trim();
        CharSequence big = extras.getCharSequence(Notification.EXTRA_BIG_TEXT);
        if (text.isEmpty() && big != null) text = big.toString().trim();
        if (title.isEmpty() || text.isEmpty()) return;

        Context ctx = getApplicationContext();
        if (isFriendRequest(title, text)) {
            friendIntent = sbn.getNotification().contentIntent;
            forwardFriendRequest(ctx, title, text);
            return;
        }
        Config.Target target = null;
        for (Config.Target t : Config.targets(ctx)) {
            if (title.equals(t.name) || title.contains(t.name)) {
                if (target == null || t.name.length() > target.name.length()) target = t;
            }
        }
        if (target == null) return;

        String contact = target.name;
        String uin = target.uin;
        boolean group = target.group;
        String sender = contact;
        if (group) {
            Matcher m = SENDER_RE.matcher(text);
            if (m.matches()) { sender = m.group(1).trim(); text = m.group(2).trim(); }
            MemoryStore.appendGroup(ctx, contact, sender, text, Config.groupCache(ctx));
        } else if (!Config.adminUin(ctx).isEmpty() && Config.adminUin(ctx).equals(uin)) {
            MemoryStore.appendAdmin(ctx, contact, sender, text);
        }
        MemoryStore.observe(ctx, contact, uin, group, title);

        if (group && !isAtMe(ctx, text)) {
            AppLog.add("群缓存 " + sender + "（未 @ " + Config.botName(ctx) + "）");
            return;
        }

        synchronized (lastSent) {
            String sent = lastSent.get(contact);
            if (sent != null && sent.equals(text)) {
                AppLog.add("忽略自己发出的消息 " + contact);
                return;
            }
        }
        String key = title + "|" + sender + "|" + text;
        long now = System.currentTimeMillis();
        synchronized (recent) {
            Long last = recent.get(key);
            if (last != null && now - last < 120000) return;
            recent.put(key, now);
            if (recent.size() > 200) recent.clear();
        }

        AppLog.add("收到 " + title + " / " + sender + ": " + text);
        QqAccessibilityService svc = QqAccessibilityService.get();
        PendingIntent ci = sbn.getNotification().contentIntent;
        if (ci != null) {
            synchronized (INTENTS) { INTENTS.put(contact, ci); }
        }
        if (svc != null) {
            svc.jumpToChat(contact, uin, group, group ? null : ci,
                    () -> AppLog.add("已跳转 " + contact));
        }
        enqueue(new Task(contact, uin, text, sender, group));
    }

    private boolean isAtMe(Context c, String text) {
        String bot = Config.botName(c);
        if (bot.isEmpty()) bot = Config.DEFAULT_BOT_NAME;
        return text.contains("@" + bot)
                || (text.contains("@") && text.contains(bot))
                || text.contains("有人@我") || text.contains("@我");
    }

    private boolean isCommandText(String text) {
        String t = text == null ? "" : text.trim();
        if (t.startsWith("/")) t = t.substring(1).trim();
        if (t.matches(".*\\d{5,12}.*") && (t.contains("加") || t.contains("添加") || t.contains("好友"))) return true;
        if ((t.contains("同意") || t.contains("通过")) && t.contains("好友")) return true;
        return t.startsWith("帮助") || t.startsWith("同意") || t.startsWith("通过")
                || t.startsWith("加好友") || t.startsWith("添加好友")
                || t.startsWith("加群") || t.startsWith("禁止") || t.startsWith("移除");
    }

    private void enqueue(Task task) {
        synchronized (queue) {
            if (queue.size() >= 50) queue.removeFirst();
            queue.addLast(task);
            if (running) return;
            running = true;
        }
        worker.execute(() -> {
            while (true) {
                Task t;
                synchronized (queue) {
                    t = queue.pollFirst();
                    if (t == null) { running = false; return; }
                }
                try { process(t); } catch (Exception e) { Log.e(TAG, "process", e); }
                finally { t.done.countDown(); }
            }
        });
    }

    private void process(Task task) {
        Context ctx = getApplicationContext();
        JSONArray history = loadHistory(ctx, task.contact);
        try {
            JSONObject user = new JSONObject();
            user.put("role", "user");
            user.put("name", task.sender);
            user.put("text", task.text);
            history.put(user);
            trim(history, Config.maxContext(ctx));
        } catch (Exception ignored) {}
        saveHistory(ctx, task.contact, history);

        boolean admin = !task.group && !Config.adminUin(ctx).isEmpty()
                && Config.adminUin(ctx).equals(task.uin);
        if (admin) {
            String cmd = handleAdminCommand(ctx, task.text);
            if (cmd != null) {
                AppLog.add("管理员命令: " + cmd);
                QqAccessibilityService s = QqAccessibilityService.get();
                if (s != null) {
                    List<String> parts = splitReply(cmd);
                    synchronized (lastSent) {
                        for (String part : parts) lastSent.put(task.contact, part);
                    }
                    s.sendParts(task.contact, task.uin, false, parts);
                }
                return;
            }
        }

        JSONArray payload;
        if (task.group) payload = MemoryStore.groupPayload(ctx, task.contact, history);
        else if (admin) payload = MemoryStore.adminPayload(ctx, task.contact, history);
        else payload = history;

        AppLog.add("请求 DSH " + task.contact);
        String reply = BridgeClient.chat(ctx, task.contact, payload, admin,
                admin ? Config.adminUin(ctx) : "", task.sender, "", "");
        if (reply == null || reply.trim().isEmpty()) {
            AppLog.add("桥没有回复，放弃");
            return;
        }
        JSONObject bot = new JSONObject();
        try {
            bot.put("role", "bot");
            bot.put("text", reply);
            history.put(bot);
            trim(history, Config.maxContext(ctx));
            saveHistory(ctx, task.contact, history);
        } catch (Exception ignored) {}

        QqAccessibilityService svc = QqAccessibilityService.get();
        if (svc == null) { AppLog.add("无障碍未连接，无法发送"); return; }

        List<String> parts = splitReply(reply);
        AppLog.add("回复分 " + parts.size() + " 条发送");
        synchronized (lastSent) {
            for (String part : parts) lastSent.put(task.contact, part);
        }
        // 交给无障碍服务串行发送，上一条点完发送再发下一条。
        svc.sendParts(task.contact, task.uin, task.group, parts);
        MemoryStore.markSent(ctx, task.contact);
    }

    private boolean isFriendRequest(String title, String text) {
        return title.contains("好友申请") || title.contains("新朋友")
                || text.contains("请求添加你为好友") || text.contains("请求加你为好友")
                || text.contains("请求添加你为朋友");
    }

    private void forwardFriendRequest(Context ctx, String title, String text) {
        String admin = Config.adminUin(ctx);
        if (admin.isEmpty()) return;
        String msg = "好友申请：" + title + "｜" + text
                + "\n同意好友请回复：同意好友 昵称 QQ号";
        QqAccessibilityService svc = QqAccessibilityService.get();
        if (svc == null) return;
        for (Config.Target t : Config.targets(ctx)) {
            if (!t.group && admin.equals(t.uin)) {
                svc.sendParts(t.name, t.uin, false, splitReply(msg));
                return;
            }
        }
        // 管理员没在联系人里也直接发到管理员 QQ，别把申请吞掉。
        AppLog.add("好友申请转发管理员 " + admin);
        svc.sendReply("", admin, msg, false);
    }

    private String handleAdminCommand(Context ctx, String text) {
        String t = text == null ? "" : text.trim();
        if (t.startsWith("/")) t = t.substring(1).trim();
        if (t.equals("帮助") || t.equals("命令") || t.equals("菜单")) {
            return "命令：\n"
                    + "发消息 昵称/QQ/群名 内容\n"
                    + "群发 群名/群号 内容\n"
                    + "加好友 QQ号\n"
                    + "加群 群号\n"
                    + "同意好友 昵称 QQ号\n"
                    + "同意 昵称 QQ号\n"
                    + "同意好友申请\n"
                    + "禁止 QQ号\n"
                    + "移除 QQ号\n"
                    + "统计 / 记忆";
        }
        if (t.equals("统计")) return MemoryStore.summary(ctx);
        if (t.equals("记忆")) return MemoryStore.dump(ctx);

        Matcher send = Pattern.compile("^(?:发消息|发到|群发)\\s+(.+)$").matcher(t);
        if (send.matches()) {
            boolean forceGroup = t.startsWith("群发");
            String rest = send.group(1).trim();
            Config.Target target = null;
            String content = "";
            for (Config.Target x : Config.targets(ctx)) {
                if (forceGroup && !x.group) continue;
                if (rest.startsWith(x.name)) {
                    String c = rest.substring(x.name.length()).trim();
                    if (!c.isEmpty() && (target == null || x.name.length() > target.name.length())) {
                        target = x; content = c;
                    }
                }
            }
            if (target == null) {
                String[] p = rest.split("\\s+", 2);
                if (p.length == 2 && p[0].matches("\\d{5,12}")) {
                    target = new Config.Target("", p[0], forceGroup);
                    content = p[1].trim();
                }
            }
            if (target == null) return "没找到目标：先加白名单，或写成“发消息 QQ号 内容”";
            if (content.isEmpty()) return "内容不能为空";
            QqAccessibilityService svc = QqAccessibilityService.get();
            if (svc == null) return "无障碍未连接，发不了";
            svc.sendParts(target.name, target.uin, target.group, splitReply(content));
            return "已发送给 " + (target.name.isEmpty() ? target.uin : target.name) + "：" + content;
        }

        // 自然语言：管理员说“加一下 3752780148 这个人/这个群”也执行。
        Matcher anyQq = Pattern.compile("(\\d{5,12})").matcher(t);
        if (anyQq.find() && !t.contains("同意") && !t.contains("通过")
                && (t.contains("加") || t.contains("添加") || t.contains("好友") || t.contains("群"))) {
            String qq = anyQq.group(1);
            boolean isGroup = t.contains("群");
            QqAccessibilityService svc = QqAccessibilityService.get();
            if (svc == null) return "无障碍未连接";
            boolean ok = isGroup ? svc.joinGroupSync(qq, 25000) : svc.addFriendSync(qq, 25000);
            return ok ? (isGroup ? "已发送加群申请：" : "已发送好友申请：") + qq
                    : "未发送：资料页不一致或需要手动验证，请看日志";
        }
        if ((t.contains("同意") || t.contains("通过")) && t.contains("好友")
                && !t.matches(".*\\d{5,12}.*")) {
            QqAccessibilityService svc = QqAccessibilityService.get();
            if (svc == null) return "无障碍未连接，无法自动同意";
            return svc.acceptLatestSync(friendIntent, 25000)
                    ? "已同意最近一条好友申请"
                    : "没有可自动同意的申请（0 条或多条），请用：同意好友 昵称 QQ号";
        }
        Matcher af2 = Pattern.compile("^(?:加好友|添加好友)\\s+(\\d{5,12})$").matcher(t);
        if (af2.matches()) {
            String qq = af2.group(1);
            QqAccessibilityService svc = QqAccessibilityService.get();
            if (svc == null) return "无障碍未连接";
            return svc.addFriendSync(qq, 25000)
                    ? "已发送好友申请：" + qq
                    : "未发送：资料页 QQ 不一致或需要手动验证，请看日志";
        }
        Matcher ag = Pattern.compile("^(?:加群|申请加群|加入群)\\s+(\\d{5,12})$").matcher(t);
        if (ag.matches()) {
            String qq = ag.group(1);
            QqAccessibilityService svc = QqAccessibilityService.get();
            if (svc == null) return "无障碍未连接";
            return svc.joinGroupSync(qq, 25000) ? "已发送加群申请：" + qq : "未发送：需要验证或页面不匹配，请手动处理";
        }
        Matcher rm = Pattern.compile("^(?:移除|删除白名单|移出白名单|禁止)\\s+(\\d{5,12})$").matcher(t);
        if (rm.matches()) {
            String qq = rm.group(1);
            if (qq.equals(Config.adminUin(ctx))) return "不能移除管理员";
            return Config.removeByUin(ctx, qq) ? "已移除白名单：" + qq : "白名单里没有：" + qq;
        }
        Matcher af = Pattern.compile("^(?:同意好友|通过好友)\\s+(\\S+)\\s+(\\d{5,12})$").matcher(t);
        if (af.matches()) {
            String nick = af.group(1);
            String qq = af.group(2);
            QqAccessibilityService svc = QqAccessibilityService.get();
            if (svc == null) return "无障碍未连接，无法自动同意";
            boolean ok = svc.acceptFriendSync(friendIntent, nick, qq, 25000);
            if (ok) {
                Config.appendPrivate(ctx, nick, qq);
                return "已同意好友并加入白名单：" + nick + "（" + qq + "）";
            }
            return "未自动同意：页面/匹配/按钮校验未通过，请手动处理";
        }
        Matcher m = Pattern.compile("^(?:同意|通过|添加白名单|白名单)\\s+(\\S+)(?:\\s+(\\d{5,12}))?$").matcher(t);
        if (!m.matches()) return null;
        String name = m.group(1);
        String qq = m.group(2);
        if (qq == null) return "请发送：同意 昵称 QQ号";
        if (Config.appendPrivate(ctx, name, qq)) return "已加入白名单：" + name + "（" + qq + "）";
        return "添加失败：名称已存在或号码无效";
    }

    private List<String> splitReply(String reply) {
        List<String> out = new ArrayList<>();
        for (String line : reply.split("\\n+")) {
            String t = line.trim();
            if (!t.isEmpty()) out.add(t);
        }
        if (out.isEmpty()) out.add(reply.trim());
        return out;
    }

    private JSONArray loadHistory(Context c, String contact) {
        String raw = c.getSharedPreferences("qqbridge", Context.MODE_PRIVATE)
                .getString("hist_" + contact, "[]");
        try { return new JSONArray(raw); } catch (Exception e) { return new JSONArray(); }
    }

    private void saveHistory(Context c, String contact, JSONArray a) {
        c.getSharedPreferences("qqbridge", Context.MODE_PRIVATE).edit()
                .putString("hist_" + contact, a.toString()).apply();
    }

    private void trim(JSONArray a, int max) {
        while (a.length() > max) a.remove(0);
    }

    private String clean(String s) {
        return s.replaceAll("\\(\\d+条新消息\\)", "").replaceAll("\\[\\d+条\\]", "").trim();
    }
}
