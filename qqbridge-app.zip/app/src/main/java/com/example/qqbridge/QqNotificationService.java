package com.example.qqbridge;

import android.app.Notification;
import android.app.PendingIntent;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayDeque;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class QqNotificationService extends NotificationListenerService {
    private static final String TAG = "QQBridge";
    private static final String QQ = "com.tencent.mobileqq";

    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final ArrayDeque<Task> queue = new ArrayDeque<>();
    private boolean running = false;
    private final Map<String, Long> recent = new HashMap<>();
    private final Map<String, Long> lastReply = new HashMap<>();
    private final Map<String, long[]> hourly = new HashMap<>();
    private static final Pattern SENDER_RE = Pattern.compile("^([^:：\\n]{1,24})[:：]\\s*(.+)$");
    private static PendingIntent pendingFriendIntent;
    private final Map<String, PendingIntent> chatIntents = new HashMap<>();

    private static class Task {
        final String contact;
        final String uin;
        final String text;
        final String sender;
        final boolean group;
        final boolean direct;
        final CountDownLatch done = new CountDownLatch(1);
        Task(String contact, String uin, String text, String sender, boolean group) {
            this(contact, uin, text, sender, group, false);
        }
        Task(String contact, String uin, String text, String sender, boolean group, boolean direct) {
            this.contact = contact;
            this.uin = uin;
            this.text = text;
            this.sender = sender;
            this.group = group;
            this.direct = direct;
        }
    }

    @Override
    public void onListenerConnected() {
        super.onListenerConnected();
        AppLog.add("通知监听已连接");
        Log.d(TAG, "notification listener connected");
    }

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        if (sbn == null || !QQ.equals(sbn.getPackageName())) return;
        Bundle extras = sbn.getNotification().extras;
        if (extras == null) return;
        CharSequence titleCs = extras.getCharSequence(Notification.EXTRA_TITLE);
        CharSequence textCs = extras.getCharSequence(Notification.EXTRA_TEXT);
        String title = clean(titleCs == null ? "" : titleCs.toString());
        String text = textCs == null ? "" : textCs.toString().trim();
        CharSequence big = extras.getCharSequence(Notification.EXTRA_BIG_TEXT);
        CharSequence sub = extras.getCharSequence(Notification.EXTRA_SUB_TEXT);
        if (text.isEmpty() && big != null) text = big.toString().trim();
        if (text.isEmpty() && sub != null) text = sub.toString().trim();
        if (text.isEmpty()) {
            CharSequence[] lines = extras.getCharSequenceArray(Notification.EXTRA_TEXT_LINES);
            if (lines != null && lines.length > 0 && lines[0] != null) text = lines[0].toString().trim();
        }
        if (title.isEmpty() || text.isEmpty()) return;

        Context ctx = getApplicationContext();
        if (isFriendRequest(title, text)) {
            pendingFriendIntent = sbn.getNotification().contentIntent;
            forwardFriendRequest(ctx, title, text);
            return;
        }
        Config.Target target = null;
        for (Config.Target t : Config.targets(ctx)) {
            if (title.equals(t.name) || title.contains(t.name)) {
                if (target == null || t.name.length() > target.name.length()) target = t;
            }
        }
        if (target == null) {
            AppLog.add("未匹配联系人 " + title);
            return;
        }
        String contact = target.name;
        String uin = target.uin;
        boolean group = target.group;
        PendingIntent chatIntent = sbn.getNotification().contentIntent;
        if (chatIntent != null) chatIntents.put(contact, chatIntent);

        String sender = contact;
        if (group) {
            Matcher m = SENDER_RE.matcher(text);
            if (m.matches()) {
                sender = m.group(1).trim();
                text = m.group(2).trim();
            }
        }

        String key = title + "|" + sender + "|" + text;
        long now = System.currentTimeMillis();
        synchronized (recent) {
            Long last = recent.get(key);
            if (last != null && now - last < 120000) return;
            recent.put(key, now);
            if (recent.size() > 200) recent.clear();
        }

        if (group && !isAtMe(ctx, text)) {
            remember(ctx, contact, sender, text);
            return;
        }

        AppLog.add("收到 " + title + " / " + sender + ": " + text);
        Log.d(TAG, "recv " + title + " / " + sender + ": " + text);
        enqueue(new Task(contact, uin, text, sender, group));
    }

    private boolean isFriendRequest(String title, String text) {
        return title.contains("好友申请") || title.contains("新朋友")
                || text.contains("请求添加你为好友") || text.contains("请求加你为好友")
                || text.contains("请求添加你为朋友");
    }

    private void forwardFriendRequest(Context ctx, String title, String text) {
        String admin = Config.adminUin(ctx);
        if (admin.isEmpty()) return;
        String key = "friend|" + title + "|" + text;
        long now = System.currentTimeMillis();
        synchronized (recent) {
            Long last = recent.get(key);
            if (last != null && now - last < 300000) return;
            recent.put(key, now);
        }
        for (Config.Target t : Config.targets(ctx)) {
            if (!t.group && admin.equals(t.uin)) {
                String msg = "好友申请：" + title + "｜" + text
                        + "\n同意请回复：同意好友 昵称 QQ号（只加白名单用：同意 昵称 QQ号）";
                enqueue(new Task(t.name, t.uin, msg, t.name, false, true));
                return;
            }
        }
    }

    private String handleAdminCommand(Context ctx, String text) {
        String t = text.trim();
        if (t.startsWith("/")) t = t.substring(1).trim();
        if (t.equals("帮助") || t.equals("命令") || t.equals("菜单")) {
            return "命令：\n同意 昵称 QQ号\n同意好友 昵称 QQ号\n移除 QQ号\n也可加 / 前缀";
        }

        Matcher rm = Pattern.compile("^(?:移除|删除白名单|移出白名单)\\s+(\\d{5,12})$").matcher(t);
        if (rm.matches()) {
            String qq = rm.group(1);
            if (qq.equals(Config.adminUin(ctx))) return "不能移除管理员";
            return Config.removePrivateByUin(ctx, qq)
                    ? "已移除白名单：" + qq
                    : "白名单里没有：" + qq;
        }

        Matcher af = Pattern.compile("^(?:同意好友|通过好友)\\s+(\\S+)\\s+(\\d{5,12})$").matcher(t);
        if (af.matches()) {
            String nick = af.group(1);
            String qq = af.group(2);
            QqAccessibilityService svc = QqAccessibilityService.get();
            if (svc == null) return "无障碍未连接，无法自动同意";
            boolean ok = svc.acceptFriendSync(pendingFriendIntent, nick, qq, 25000);
            if (ok) {
                Config.appendPrivate(ctx, nick, qq);
                return "已同意好友并加入白名单：" + nick + "（" + qq + "）";
            }
            return "未自动同意：页面/匹配/按钮校验未通过，请手动处理";
        }

        Matcher m = Pattern.compile("^(?:同意|通过|添加白名单|白名单)\\s+(\\S+)(?:\\s+(\\d{5,12}))?$")
                .matcher(t);
        if (!m.matches()) return null;
        String name = m.group(1);
        String qq = m.group(2);
        if (qq == null) return "请发送：同意 昵称 QQ号";
        if (Config.appendPrivate(ctx, name, qq)) return "已加入白名单：" + name + "（" + qq + "）";
        return "添加失败：名称已存在或号码无效";
    }

    private boolean isSticker(String text) {
        return text.contains("[表情]") || text.contains("[动画表情]")
                || text.contains("[图片]") || text.equals("表情")
                || text.equals("动画表情") || text.equals("图片");
    }

    private boolean isAtMe(Context ctx, String text) {
        String bot = Config.botName(ctx);
        if (bot.isEmpty()) bot = Config.DEFAULT_BOT_NAME;
        return text.contains("@" + bot)
                || (text.contains("@") && text.contains(bot))
                || text.contains("有人@我")
                || text.contains("@我");
    }

    private void enqueue(Task task) {
        synchronized (queue) {
            if (queue.size() >= 50) {
                Task removed = null;
                for (Task t : queue) {
                    if (t.group) { removed = t; break; }
                }
                if (removed != null) queue.remove(removed);
                else queue.removeFirst();
            }
            queue.addLast(task);
            if (!running) {
                running = true;
                worker.execute(this::drain);
            }
        }
    }

    private void drain() {
        try {
        while (true) {
            Task task;
            synchronized (queue) {
                if (queue.isEmpty()) {
                    running = false;
                    return;
                }
                task = queue.removeFirst();
            }
            Context ctx = getApplicationContext();
            {
                long now = System.currentTimeMillis();
                long cooldown = (task.group ? Config.groupCooldown(ctx)
                        : Config.privateCooldown(ctx)) * 1000L;
                Long last = lastReply.get(task.contact);
                if (last != null && now - last < cooldown) {
                    Log.d(TAG, "local cooldown skip " + task.contact);
                    continue;
                }
                long[] h = hourly.get(task.contact);
                if (h == null || now - h[0] > 3600000) {
                    h = new long[]{now, 0};
                    hourly.put(task.contact, h);
                }
                if (h[1] >= Config.hourlyLimit(ctx)) {
                    Log.d(TAG, "local hourly skip " + task.contact);
                    continue;
                }
                h[1]++;
                lastReply.put(task.contact, now);
            }
            if (task.direct) {
                try {
                    QqAccessibilityService svc = QqAccessibilityService.get();
                    if (svc != null) svc.sendReply(task.contact, task.uin, task.text, task.group);
                    Thread.sleep(12000);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    return;
                } finally {
                    task.done.countDown();
                }
                continue;
            }
            try {
                process(task);
                task.done.await(90, TimeUnit.SECONDS);
                Thread.sleep(1200);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return;
            } catch (Exception e) {
                Log.e(TAG, "process error", e);
                task.done.countDown();
            }
        }
        } finally {
            synchronized (queue) {
                running = false;
                if (!queue.isEmpty()) {
                    running = true;
                    worker.execute(this::drain);
                }
            }
        }
    }

    private void process(Task task) {
        AppLog.add("处理消息 " + task.contact);
        Context ctx = getApplicationContext();
        JSONArray history = loadHistory(ctx, task.contact);
        try {
            JSONObject user = new JSONObject();
            user.put("role", "user");
            user.put("name", task.sender);
            user.put("text", task.text);
            history.put(user);
            trim(history, Config.maxContext(ctx));
        } catch (Exception e) {
            Log.e(TAG, "build history", e);
        }
        saveHistory(ctx, task.contact, history);

        QqAccessibilityService svc = QqAccessibilityService.get();
        String admin = Config.adminUin(ctx);
        boolean privateChat = !task.group;

        if (svc != null && Config.stickerVision(ctx) && isSticker(task.text)) {
            final JSONArray h = history;
            svc.openChat(task.contact, task.uin, task.group, () -> ScreenCapture.capture(svc, (b64, mime) -> {
                if (b64 == null || b64.isEmpty()) {
                    Log.w(TAG, "sticker capture empty, fallback text");
                    new Thread(() -> finish(ctx, task.contact, task.uin, task.group, h, false, "", task.sender, task.done)).start();
                    return;
                }
                Log.d(TAG, "sticker screenshot " + b64.length() + " chars");
                new Thread(() -> finish(ctx, task.contact, task.uin, task.group, h, false,
                        "", task.sender, task.done, b64, mime)).start();
            }));
            return;
        }

        boolean isConfiguredAdmin = privateChat && !admin.isEmpty() && admin.equals(task.uin);
        boolean isCommand = isConfiguredAdmin && isCommandText(task.text);

        if (svc != null && isCommand) {
            final JSONArray h = history;
            svc.readProfile(task.contact, task.uin, (nickname, qq) -> {
                if (qq != null && !qq.isEmpty()) {
                    boolean isAdmin = admin.equals(qq);
                    Log.d(TAG, "cmd " + nickname + " qq=" + qq + " admin=" + isAdmin);
                    runPrivateTask(ctx, task, h, isAdmin, nickname);
                    return;
                }
                svc.verifyAdminBySearch(admin, task.contact, isAdmin -> {
                    Log.d(TAG, "cmd search admin=" + isAdmin);
                    runPrivateTask(ctx, task, h, isAdmin, task.contact);
                });
            });
        } else if (isConfiguredAdmin) {
            finish(ctx, task.contact, task.uin, task.group, history, true, admin, task.contact, task.done);
        } else {
            finish(ctx, task.contact, task.uin, task.group, history, false, "", task.contact, task.done);
        }
    }

    private boolean isCommandText(String text) {
        String t = text == null ? "" : text.trim();
        if (t.startsWith("/")) t = t.substring(1).trim();
        return t.equals("帮助") || t.equals("命令") || t.equals("菜单")
                || t.startsWith("同意") || t.startsWith("通过")
                || t.startsWith("移除") || t.startsWith("删除白名单")
                || t.startsWith("移出白名单") || t.startsWith("白名单")
                || t.startsWith("添加白名单");
    }

    private void runPrivateTask(Context ctx, Task task, JSONArray history,
                                boolean isAdmin, String senderName) {
        String admin = Config.adminUin(ctx);
        new Thread(() -> {
            if (isAdmin) {
                String cmd = handleAdminCommand(ctx, task.text);
                if (cmd != null) {
                    Log.d(TAG, "admin cmd: " + cmd);
                    QqAccessibilityService svc = QqAccessibilityService.get();
                    if (svc != null) svc.sendReply(task.contact, task.uin, cmd, false);
                    try { Thread.sleep(4000); } catch (InterruptedException ignored) {}
                    task.done.countDown();
                    return;
                }
            }
            finish(ctx, task.contact, task.uin, task.group, history, isAdmin,
                    isAdmin ? admin : "", senderName, task.done);
        }).start();
    }

    private void finish(Context ctx, String contact, String uin, boolean group, JSONArray history,
                        boolean admin, String senderQq, String senderName, CountDownLatch done) {
        finish(ctx, contact, uin, group, history, admin, senderQq, senderName, done, "", "");
    }

    private void finish(Context ctx, String contact, String uin, boolean group, JSONArray history,
                        boolean admin, String senderQq, String senderName, CountDownLatch done,
                        String imageBase64, String imageMime) {
        try {
        AppLog.add("请求 DSH " + contact);
        String reply = BridgeClient.chat(ctx, contact, history, admin, senderQq, senderName,
                imageBase64, imageMime);
        AppLog.add("DSH 回复 " + (reply == null ? "空" : reply.length() + " 字"));
        if (reply == null) {
            Log.w(TAG, "bridge empty");
            return;
        }
        Log.d(TAG, "reply: " + reply);
        try {
            JSONObject bot = new JSONObject();
            bot.put("role", "bot");
            bot.put("text", reply);
            history.put(bot);
            trim(history, Config.maxContext(ctx));
        } catch (Exception e) {
            Log.e(TAG, "build reply history", e);
        }
        saveHistory(ctx, contact, history);

        QqAccessibilityService svc = QqAccessibilityService.get();
        if (svc == null) {
            Log.w(TAG, "accessibility not connected");
            AppLog.add("无障碍未连接，无法发送");
            return;
        }
        svc.sendReply(contact, uin, reply, group, chatIntents.get(contact));
        try {
            Thread.sleep(12000);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        } finally {
            done.countDown();
        }
    }

    private void remember(Context ctx, String contact, String sender, String text) {
        JSONArray history = loadHistory(ctx, contact);
        try {
            JSONObject user = new JSONObject();
            user.put("role", "user");
            user.put("name", sender);
            user.put("text", text);
            history.put(user);
            trim(history, Config.maxContext(ctx));
        } catch (Exception e) {
            Log.e(TAG, "remember", e);
        }
        saveHistory(ctx, contact, history);
    }

    private JSONArray loadHistory(Context ctx, String contact) {
        SharedPreferences sp = ctx.getSharedPreferences("qqbridge", Context.MODE_PRIVATE);
        String raw = sp.getString("hist_" + contact, "[]");
        try { return new JSONArray(raw); } catch (Exception e) { return new JSONArray(); }
    }

    private void saveHistory(Context ctx, String contact, JSONArray history) {
        ctx.getSharedPreferences("qqbridge", Context.MODE_PRIVATE)
                .edit().putString("hist_" + contact, history.toString()).apply();
    }

    private void trim(JSONArray a, int max) {
        while (a.length() > max) a.remove(0);
    }

    private String clean(String s) {
        return s.replaceAll("\\(\\d+条新消息\\)", "").replaceAll("\\[\\d+条\\]", "").trim();
    }
}
