package com.example.qqbridge;

import android.app.Notification;
import android.app.PendingIntent;
import android.content.Context;
import android.os.Bundle;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** 只做两件事：私聊/群聊收消息 → 请求手机桥 → 分段发送。 */
public class QqNotificationService extends NotificationListenerService {
    private static final String TAG = "QQBridge";
    private static final String QQ = "com.tencent.mobileqq";
    private static final Pattern SENDER_RE = Pattern.compile("^([^:：\\n]{1,24})[:：]\\s*(.+)$");

    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final ArrayDeque<Task> queue = new ArrayDeque<>();
    private boolean running = false;
    private final Map<String, Long> recent = new HashMap<>();
    private final Map<String, String> lastSent = new HashMap<>();
    private static final Map<String, PendingIntent> INTENTS = new HashMap<>();

    public static PendingIntent lastIntent(String contact) {
        if (contact == null) return null;
        synchronized (INTENTS) { return INTENTS.get(contact); }
    }

    private static class Task {
        final String contact, uin, text, sender;
        final boolean group;
        final CountDownLatch done = new CountDownLatch(1);
        Task(String contact, String uin, String text, String sender, boolean group) {
            this.contact = contact; this.uin = uin; this.text = text;
            this.sender = sender; this.group = group;
        }
    }

    @Override public void onListenerConnected() {
        AppLog.add("通知监听已连接");
    }

    @Override public void onNotificationPosted(StatusBarNotification sbn) {
        if (sbn == null || !QQ.equals(sbn.getPackageName())) return;
        Bundle extras = sbn.getNotification().extras;
        if (extras == null) return;
        String title = clean(String.valueOf(extras.getCharSequence(Notification.EXTRA_TITLE, "")));
        String text = String.valueOf(extras.getCharSequence(Notification.EXTRA_TEXT, "")).trim();
        CharSequence big = extras.getCharSequence(Notification.EXTRA_BIG_TEXT);
        if (text.isEmpty() && big != null) text = big.toString().trim();
        if (title.isEmpty() || text.isEmpty()) return;

        Context ctx = getApplicationContext();
        Config.Target target = null;
        for (Config.Target t : Config.targets(ctx)) {
            if (title.equals(t.name) || title.contains(t.name)) {
                if (target == null || t.name.length() > target.name.length()) target = t;
            }
        }
        if (target == null) return;

        String contact = target.name;
        String uin = target.uin;
        boolean group = target.group;
        String sender = contact;
        if (group) {
            Matcher m = SENDER_RE.matcher(text);
            if (m.matches()) { sender = m.group(1).trim(); text = m.group(2).trim(); }
            MemoryStore.appendGroup(ctx, contact, sender, text, Config.groupCache(ctx));
        } else if (!Config.adminUin(ctx).isEmpty() && Config.adminUin(ctx).equals(uin)) {
            MemoryStore.appendAdmin(ctx, contact, sender, text);
        }
        MemoryStore.observe(ctx, contact, uin, group, title);

        if (group && !isAtMe(ctx, text)) {
            AppLog.add("群缓存 " + sender + "（未 @ " + Config.botName(ctx) + "）");
            return;
        }

        synchronized (lastSent) {
            String sent = lastSent.get(contact);
            if (sent != null && sent.equals(text)) {
                AppLog.add("忽略自己发出的消息 " + contact);
                return;
            }
        }
        String key = title + "|" + sender + "|" + text;
        long now = System.currentTimeMillis();
        synchronized (recent) {
            Long last = recent.get(key);
            if (last != null && now - last < 120000) return;
            recent.put(key, now);
            if (recent.size() > 200) recent.clear();
        }

        AppLog.add("收到 " + title + " / " + sender + ": " + text);
        QqAccessibilityService svc = QqAccessibilityService.get();
        PendingIntent ci = sbn.getNotification().contentIntent;
        if (ci != null) {
            synchronized (INTENTS) { INTENTS.put(contact, ci); }
        }
        if (svc != null) {
            svc.jumpToChat(contact, uin, group, group ? null : ci,
                    () -> AppLog.add("已跳转 " + contact));
        }
        enqueue(new Task(contact, uin, text, sender, group));
    }

    private boolean isAtMe(Context c, String text) {
        String bot = Config.botName(c);
        if (bot.isEmpty()) bot = Config.DEFAULT_BOT_NAME;
        return text.contains("@" + bot)
                || (text.contains("@") && text.contains(bot))
                || text.contains("有人@我") || text.contains("@我");
    }

    private void enqueue(Task task) {
        synchronized (queue) {
            if (queue.size() >= 50) queue.removeFirst();
            queue.addLast(task);
            if (running) return;
            running = true;
        }
        worker.execute(() -> {
            while (true) {
                Task t;
                synchronized (queue) {
                    t = queue.pollFirst();
                    if (t == null) { running = false; return; }
                }
                try { process(t); } catch (Exception e) { Log.e(TAG, "process", e); }
                finally { t.done.countDown(); }
            }
        });
    }

    private void process(Task task) {
        Context ctx = getApplicationContext();
        JSONArray history = loadHistory(ctx, task.contact);
        try {
            JSONObject user = new JSONObject();
            user.put("role", "user");
            user.put("name", task.sender);
            user.put("text", task.text);
            history.put(user);
            trim(history, Config.maxContext(ctx));
        } catch (Exception ignored) {}
        saveHistory(ctx, task.contact, history);

        JSONArray payload;
        boolean admin = !task.group && !Config.adminUin(ctx).isEmpty()
                && Config.adminUin(ctx).equals(task.uin);
        if (task.group) payload = MemoryStore.groupPayload(ctx, task.contact, history);
        else if (admin) payload = MemoryStore.adminPayload(ctx, task.contact, history);
        else payload = history;

        AppLog.add("请求 DSH " + task.contact);
        String reply = BridgeClient.chat(ctx, task.contact, payload, admin,
                admin ? Config.adminUin(ctx) : "", task.sender, "", "");
        if (reply == null || reply.trim().isEmpty()) {
            AppLog.add("桥没有回复，放弃");
            return;
        }
        JSONObject bot = new JSONObject();
        try {
            bot.put("role", "bot");
            bot.put("text", reply);
            history.put(bot);
            trim(history, Config.maxContext(ctx));
            saveHistory(ctx, task.contact, history);
        } catch (Exception ignored) {}

        QqAccessibilityService svc = QqAccessibilityService.get();
        if (svc == null) { AppLog.add("无障碍未连接，无法发送"); return; }

        List<String> parts = splitReply(reply);
        AppLog.add("回复分 " + parts.size() + " 条发送");
        synchronized (lastSent) {
            for (String part : parts) lastSent.put(task.contact, part);
        }
        // 交给无障碍服务串行发送，上一条点完发送再发下一条。
        svc.sendParts(task.contact, task.uin, task.group, parts);
        MemoryStore.markSent(ctx, task.contact);
    }

    private List<String> splitReply(String reply) {
        List<String> out = new ArrayList<>();
        for (String line : reply.split("\\n+")) {
            String t = line.trim();
            if (!t.isEmpty()) out.add(t);
        }
        if (out.isEmpty()) out.add(reply.trim());
        return out;
    }

    private JSONArray loadHistory(Context c, String contact) {
        String raw = c.getSharedPreferences("qqbridge", Context.MODE_PRIVATE)
                .getString("hist_" + contact, "[]");
        try { return new JSONArray(raw); } catch (Exception e) { return new JSONArray(); }
    }

    private void saveHistory(Context c, String contact, JSONArray a) {
        c.getSharedPreferences("qqbridge", Context.MODE_PRIVATE).edit()
                .putString("hist_" + contact, a.toString()).apply();
    }

    private void trim(JSONArray a, int max) {
        while (a.length() > max) a.remove(0);
    }

    private String clean(String s) {
        return s.replaceAll("\\(\\d+条新消息\\)", "").replaceAll("\\[\\d+条\\]", "").trim();
    }
}
