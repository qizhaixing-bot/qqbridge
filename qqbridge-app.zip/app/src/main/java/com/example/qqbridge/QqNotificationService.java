package com.example.qqbridge;

import android.app.Notification;
import android.content.Context;
import android.os.Bundle;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.util.Log;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class QqNotificationService extends NotificationListenerService {
    private static final String TAG = "QQBridge";
    private static final String QQ = "com.tencent.mobileqq";
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Map<String, Long> recent = new HashMap<>();

    @Override
    public void onListenerConnected() {
        super.onListenerConnected();
        Log.d(TAG, "notification listener connected");
    }

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        if (sbn == null || !QQ.equals(sbn.getPackageName())) return;
        Bundle extras = sbn.getNotification().extras;
        if (extras == null) return;
        CharSequence titleCs = extras.getCharSequence(Notification.EXTRA_TITLE);
        CharSequence textCs = extras.getCharSequence(Notification.EXTRA_TEXT);
        String title = clean(titleCs == null ? "" : titleCs.toString());
        String text = textCs == null ? "" : textCs.toString().trim();
        if (title.isEmpty() || text.isEmpty()) return;

        Context ctx = getApplicationContext();
        String contact = Config.contact(ctx);
        if (!title.contains(contact)) return;

        String key = title + "|" + text;
        long now = System.currentTimeMillis();
        synchronized (recent) {
            Long last = recent.get(key);
            if (last != null && now - last < 120000) return;
            recent.put(key, now);
        }

        Log.d(TAG, "recv " + title + ": " + text);
        executor.execute(() -> {
            String reply = BridgeClient.chat(ctx, contact, text);
            if (reply == null) {
                Log.w(TAG, "bridge empty");
                return;
            }
            Log.d(TAG, "reply: " + reply);
            QqAccessibilityService svc = QqAccessibilityService.get();
            if (svc == null) {
                Log.w(TAG, "accessibility not connected");
                return;
            }
            svc.sendReply(contact, Config.uin(ctx), reply);
        });
    }

    private String clean(String s) {
        return s.replaceAll("\\(\\d+条新消息\\)", "").replaceAll("\\[\\d+条\\]", "").trim();
    }
}
